-- ============================================================
-- Migration 014 — Complaints (Step 5d)
-- Run after 013_cards.sql
-- ============================================================

-- ------------------------------------------------------------
-- complaints
-- One record per complaint. Filed by student, helpline, or AI.
-- Scoped to centre (TCC) or site (TSC/TSA) on creation.
-- ------------------------------------------------------------
CREATE TABLE complaints (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),

  -- Who filed it
  filed_by        UUID NOT NULL REFERENCES users(id),
  filed_via       TEXT NOT NULL
                  CHECK (filed_via IN ('student_portal','helpline_agent','agentic_ai','phone','whatsapp','chat')),

  -- Subject of the complaint (optional — may be anonymous context)
  student_id      UUID REFERENCES users(id),

  -- Scope determines routing (§3.6)
  scope           TEXT NOT NULL CHECK (scope IN ('centre','site')),
  site_id         UUID REFERENCES sites(id),   -- set when scope = 'site'

  -- Assigned owner (TCC for centre, TSC/TSA for site)
  assigned_to     UUID REFERENCES users(id),
  assigned_at     TIMESTAMPTZ,

  -- Description
  description     TEXT NOT NULL,
  category        TEXT,   -- free-form tag: e.g. 'scheduling','instructor_conduct','billing'

  -- Status lifecycle
  status          TEXT NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open','acknowledged','in_progress','escalated','resolved','closed')),

  -- Response target timestamps (§18.1: ack ≤2 working days, resolve ≤10)
  acknowledged_at TIMESTAMPTZ,
  acknowledged_by UUID REFERENCES users(id),
  resolved_at     TIMESTAMPTZ,
  resolved_by     UUID REFERENCES users(id),
  resolution_note TEXT,

  -- Escalation
  escalated_at    TIMESTAMPTZ,
  escalated_by    UUID REFERENCES users(id),
  escalated_to    UUID REFERENCES users(id),

  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;
CREATE POLICY complaints_tenant ON complaints
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- complaint_status_history
-- Full audit trail of every status transition (§3.6 — tracked to closure).
-- Student sees this in their portal.
-- ------------------------------------------------------------
CREATE TABLE complaint_status_history (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint_id  UUID NOT NULL REFERENCES complaints(id),
  from_status   TEXT,
  to_status     TEXT NOT NULL,
  changed_by    UUID NOT NULL REFERENCES users(id),
  note          TEXT,
  changed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE complaint_status_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY complaint_history_tenant ON complaint_status_history
  USING (
    complaint_id IN (
      SELECT id FROM complaints
      WHERE tenant_id = current_setting('app.tenant_id')::UUID
    )
  );

-- ------------------------------------------------------------
-- complaint_comments
-- Internal notes by assigned owner / admin during investigation.
-- ------------------------------------------------------------
CREATE TABLE complaint_comments (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint_id UUID NOT NULL REFERENCES complaints(id),
  author_id    UUID NOT NULL REFERENCES users(id),
  body         TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE complaint_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY complaint_comments_tenant ON complaint_comments
  USING (
    complaint_id IN (
      SELECT id FROM complaints
      WHERE tenant_id = current_setting('app.tenant_id')::UUID
    )
  );

-- Indexes
CREATE INDEX idx_complaints_tenant_status
  ON complaints (tenant_id, status, created_at);
CREATE INDEX idx_complaints_assigned
  ON complaints (assigned_to, status);
CREATE INDEX idx_complaints_student
  ON complaints (student_id);
CREATE INDEX idx_complaint_history_complaint
  ON complaint_status_history (complaint_id, changed_at);
