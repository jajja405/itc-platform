-- ============================================================
-- Slice 1 additions: idempotency support on enrolments
-- Spec 11.2 — all mutating endpoints accept an idempotency key
-- ============================================================

ALTER TABLE enrolments ADD COLUMN idempotency_key TEXT;
CREATE UNIQUE INDEX idx_enrolments_idempotency
  ON enrolments(idempotency_key) WHERE idempotency_key IS NOT NULL;

COMMENT ON COLUMN enrolments.idempotency_key IS
  'Client-supplied key. A retried booking returns the original result rather than double-booking.';

-- Seat-count helper view for the public calendar
CREATE VIEW class_availability AS
SELECT
  c.id                AS class_id,
  c.tenant_id,
  c.course_id,
  c.starts_at,
  c.status,
  c.capacity,
  COUNT(*) FILTER (WHERE e.status IN ('enrolled','attended')) AS seats_taken,
  c.capacity - COUNT(*) FILTER (WHERE e.status IN ('enrolled','attended')) AS seats_available,
  COUNT(*) FILTER (WHERE e.status = 'waitlisted') AS waitlist_length
FROM classes c
LEFT JOIN enrolments e ON e.class_id = c.id
GROUP BY c.id;

COMMENT ON VIEW class_availability IS 'Seat availability for the public calendar. Waitlisted rows do not hold a seat.';
