-- ============================================================
-- Migration 018 — Helpline console + Agentic AI (Step 8)
-- Run after 017_notifications.sql
-- ============================================================

-- ------------------------------------------------------------
-- helpline_interactions
-- Every contact — voice, WhatsApp, chat — by human or AI agent.
-- Handler identity, channel, timestamp, outcome all recorded (§2.5).
-- ------------------------------------------------------------
CREATE TABLE helpline_interactions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id),   -- NULL = platform-level contact
  handler_id      UUID NOT NULL REFERENCES users(id),  -- helpline_agent or agentic_ai account
  handler_type    TEXT NOT NULL CHECK (handler_type IN ('human','ai')),
  channel         TEXT NOT NULL CHECK (channel IN ('voice','whatsapp','chat','email')),
  caller_id       UUID REFERENCES users(id),   -- NULL if unidentified
  identity_verified BOOLEAN NOT NULL DEFAULT false,
  started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at        TIMESTAMPTZ,
  outcome         TEXT CHECK (outcome IN ('resolved','handed_off','callback_queued','abandoned')),
  handoff_reason  TEXT,    -- populated when outcome = 'handed_off'
  session_data    JSONB,   -- per-session scope only (§10.4 — no cross-caller memory)
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE helpline_interactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY helpline_interactions_tenant ON helpline_interactions
  USING (tenant_id = current_setting('app.tenant_id')::UUID OR tenant_id IS NULL);

-- ------------------------------------------------------------
-- ai_interaction_log
-- Every AI action, decision basis, and transcript entry (§10.5).
-- Feeds into audit log and quality review.
-- ------------------------------------------------------------
CREATE TABLE ai_interaction_log (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  interaction_id   UUID NOT NULL REFERENCES helpline_interactions(id),
  turn_index       INTEGER NOT NULL,   -- 0-based turn within the conversation
  role             TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  content          TEXT NOT NULL,      -- transcript text
  action_taken     TEXT,               -- e.g. 'booked_class', 'rescheduled', 'logged_complaint'
  action_params    JSONB,              -- parameters of the action
  boundary_check   TEXT,               -- 'permitted'|'blocked'|'prompt_injection_attempt'
  decision_basis   TEXT,               -- brief rationale logged for quality review
  logged_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_log_interaction ON ai_interaction_log (interaction_id, turn_index);

-- ------------------------------------------------------------
-- ai_kill_switch  (§10.4)
-- Admin can route all traffic to humans instantly.
-- ------------------------------------------------------------
CREATE TABLE ai_kill_switch (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID REFERENCES tenants(id),  -- NULL = platform-wide
  active       BOOLEAN NOT NULL DEFAULT false,
  activated_by UUID REFERENCES users(id),
  activated_at TIMESTAMPTZ,
  reason       TEXT,
  deactivated_by UUID REFERENCES users(id),
  deactivated_at TIMESTAMPTZ
);

-- One row per tenant (plus one platform-wide row)
CREATE UNIQUE INDEX idx_kill_switch_tenant ON ai_kill_switch (COALESCE(tenant_id, '00000000-0000-0000-0000-000000000000'::UUID));

-- ------------------------------------------------------------
-- callback_queue  (§10.3 — no human available → callback commitment)
-- ------------------------------------------------------------
CREATE TABLE callback_queue (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID REFERENCES tenants(id),
  caller_id       UUID REFERENCES users(id),
  caller_contact  TEXT NOT NULL,   -- phone or WhatsApp number
  interaction_id  UUID REFERENCES helpline_interactions(id),
  reason          TEXT,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','assigned','completed','cancelled')),
  assigned_to     UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at     TIMESTAMPTZ
);

ALTER TABLE callback_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY callback_queue_tenant ON callback_queue
  USING (tenant_id = current_setting('app.tenant_id')::UUID OR tenant_id IS NULL);

-- ------------------------------------------------------------
-- ai_quality_reviews  (§10.5 — weekly sample review)
-- ------------------------------------------------------------
CREATE TABLE ai_quality_reviews (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  interaction_id UUID NOT NULL REFERENCES helpline_interactions(id),
  reviewer_id    UUID NOT NULL REFERENCES users(id),
  week_of        DATE NOT NULL,
  accuracy       INTEGER CHECK (accuracy BETWEEN 1 AND 5),
  boundary_compliance INTEGER CHECK (boundary_compliance BETWEEN 1 AND 5),
  handoff_correctness INTEGER CHECK (handoff_correctness BETWEEN 1 AND 5),
  tone           INTEGER CHECK (tone BETWEEN 1 AND 5),
  notes          TEXT,
  reviewed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_quality_week ON ai_quality_reviews (week_of);

-- Indexes
CREATE INDEX idx_helpline_tenant    ON helpline_interactions (tenant_id, started_at DESC);
CREATE INDEX idx_helpline_handler   ON helpline_interactions (handler_id, handler_type);
CREATE INDEX idx_callback_pending   ON callback_queue (status, created_at) WHERE status = 'pending';
