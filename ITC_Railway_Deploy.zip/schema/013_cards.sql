-- ============================================================
-- Migration 013 — Card inventory & issuance (Step 5c)
-- Run after 012_checklists.sql
-- ============================================================

-- ------------------------------------------------------------
-- card_stock_batches
-- TCC records stock received from AHA (§15.1 Intake).
-- ------------------------------------------------------------
CREATE TABLE card_stock_batches (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  course_type_id  UUID NOT NULL REFERENCES course_types(id),
  stock_type      TEXT NOT NULL CHECK (stock_type IN ('physical','ecard')),
  batch_reference TEXT NOT NULL,          -- AHA batch/order reference
  quantity        INTEGER NOT NULL CHECK (quantity > 0),
  received_date   DATE NOT NULL,
  received_by     UUID NOT NULL REFERENCES users(id),  -- must be TCC
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE card_stock_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY card_stock_batches_tenant ON card_stock_batches
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- card_allocations
-- TCC/TCA allocates stock to a site or named instructor (§15.1 Allocation).
-- Transfers custody — audit trail required.
-- ------------------------------------------------------------
CREATE TABLE card_allocations (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id),
  batch_id         UUID NOT NULL REFERENCES card_stock_batches(id),
  allocated_to_user UUID REFERENCES users(id),   -- named instructor allocation
  allocated_to_site UUID REFERENCES sites(id),    -- site-level allocation
  quantity         INTEGER NOT NULL CHECK (quantity > 0),
  allocated_by     UUID NOT NULL REFERENCES users(id),
  allocated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT must_have_recipient CHECK (
    allocated_to_user IS NOT NULL OR allocated_to_site IS NOT NULL
  )
);

ALTER TABLE card_allocations ENABLE ROW LEVEL SECURITY;
CREATE POLICY card_allocations_tenant ON card_allocations
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- card_low_stock_thresholds
-- Per course_type configurable threshold; alert fires below it (§15.1).
-- ------------------------------------------------------------
CREATE TABLE card_low_stock_thresholds (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  course_type_id  UUID NOT NULL REFERENCES course_types(id),
  stock_type      TEXT NOT NULL CHECK (stock_type IN ('physical','ecard')),
  threshold       INTEGER NOT NULL DEFAULT 10,
  UNIQUE (tenant_id, course_type_id, stock_type)
);

ALTER TABLE card_low_stock_thresholds ENABLE ROW LEVEL SECURITY;
CREATE POLICY card_low_stock_thresholds_tenant ON card_low_stock_thresholds
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- issued_cards
-- The primary card record — one per student per course completion.
-- Linked to student, course, and completion record (§15.1 Issuance).
-- ------------------------------------------------------------
CREATE TABLE issued_cards (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id),
  student_id          UUID NOT NULL REFERENCES users(id),
  class_id            UUID NOT NULL REFERENCES classes(id),
  course_type_id      UUID NOT NULL REFERENCES course_types(id),
  checklist_pdf_id    UUID REFERENCES checklist_pdfs(id),  -- completion record link
  stock_type          TEXT NOT NULL CHECK (stock_type IN ('physical','ecard')),
  batch_id            UUID REFERENCES card_stock_batches(id),
  allocation_id       UUID REFERENCES card_allocations(id),
  issued_by           UUID NOT NULL REFERENCES users(id),
  issued_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  expiry_date         DATE NOT NULL,
  -- Verification (§2.9)
  verification_code   TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(12), 'hex'),
  -- Status
  status              TEXT NOT NULL DEFAULT 'valid'
                      CHECK (status IN ('valid','revoked','expired')),
  revoked_at          TIMESTAMPTZ,
  revoked_by          UUID REFERENCES users(id),
  revocation_reason   TEXT,
  -- Void/spoiled cards (§15.1)
  voided_at           TIMESTAMPTZ,
  voided_by           UUID REFERENCES users(id),
  void_reason         TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE issued_cards ENABLE ROW LEVEL SECURITY;
CREATE POLICY issued_cards_tenant ON issued_cards
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- card_verification_log
-- Every public lookup is logged (§2.9 "every verification lookup is logged").
-- No auth required to look up, but every hit is recorded.
-- ------------------------------------------------------------
CREATE TABLE card_verification_log (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  verification_code TEXT NOT NULL,
  looked_up_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  requester_ip      TEXT,
  result            TEXT NOT NULL CHECK (result IN ('valid','revoked','expired','not_found'))
);
-- No RLS — public table, no tenant context on lookup
-- No tenant data exposed (§2.9: only name/course/dates/issuer/validity)

-- ------------------------------------------------------------
-- Indexes
-- ------------------------------------------------------------
CREATE INDEX idx_card_batches_tenant_course
  ON card_stock_batches (tenant_id, course_type_id, stock_type);

CREATE INDEX idx_card_allocs_user
  ON card_allocations (allocated_to_user, batch_id);

CREATE INDEX idx_issued_cards_student
  ON issued_cards (student_id);

CREATE INDEX idx_issued_cards_class
  ON issued_cards (class_id);

CREATE INDEX idx_issued_cards_verification
  ON issued_cards (verification_code);

CREATE INDEX idx_issued_cards_expiry
  ON issued_cards (expiry_date, status);

CREATE INDEX idx_card_verif_log_code
  ON card_verification_log (verification_code, looked_up_at);
