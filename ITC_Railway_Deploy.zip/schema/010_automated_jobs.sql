-- ============================================================
-- AUTOMATED LIFECYCLE JOBS — triggers and scheduled functions
-- Implements auto-suspension rules from sections 6.4, 14.3, 15.1
-- ============================================================

-- 1. Auto-suspend instructor teach-and-test when card expires or alignment lapses
CREATE OR REPLACE FUNCTION suspend_lapsed_instructors() RETURNS void AS $$
BEGIN
  UPDATE instructors
  SET
    alignment_status   = 'suspended',
    teach_suspended_at = NOW()
  WHERE
    alignment_status = 'aligned'
    AND (card_expiry < CURRENT_DATE OR alignment_status = 'lapsed')
    AND teach_suspended_at IS NULL;

  -- Log each suspension to audit log
  INSERT INTO audit_log (actor_id, actor_role, action, entity_type, entity_id, reason, row_hash)
  SELECT
    NULL, 'system', 'instructor.auto_suspended', 'instructors', id,
    'Card expired or alignment lapsed per section 6.4',
    encode(sha256(id::text::bytea), 'hex')
  FROM instructors
  WHERE teach_suspended_at::date = CURRENT_DATE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Flag dormant accounts (90 days unused → flagged; 180 days → auto-suspend) per 6.4
CREATE OR REPLACE FUNCTION flag_dormant_accounts() RETURNS void AS $$
BEGIN
  -- Flag at 90 days
  UPDATE users
  SET status = 'dormant_flagged', dormant_flagged_at = NOW()
  WHERE
    role <> 'student'
    AND status = 'active'
    AND (last_login_at < NOW() - INTERVAL '90 days' OR last_login_at IS NULL)
    AND created_at < NOW() - INTERVAL '90 days';

  -- Auto-suspend at 180 days
  UPDATE users
  SET status = 'suspended'
  WHERE
    status = 'dormant_flagged'
    AND dormant_flagged_at < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Expire delegation grants automatically per section 5.1
CREATE OR REPLACE FUNCTION expire_delegations() RETURNS void AS $$
BEGIN
  UPDATE delegations
  SET status = 'expired'
  WHERE status = 'active' AND ends_at < NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Alert when active checklist has no successor after retirement per 14.3
CREATE OR REPLACE FUNCTION alert_retired_checklists() RETURNS void AS $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT c.tenant_id, c.course_id, c.id
    FROM checklists c
    WHERE c.status = 'retired'
    AND NOT EXISTS (
      SELECT 1 FROM checklists c2
      WHERE c2.tenant_id = c.tenant_id
        AND c2.course_id = c.course_id
        AND c2.status = 'active'
    )
  LOOP
    INSERT INTO notifications (tenant_id, event_type, channel, payload)
    SELECT
      r.tenant_id,
      'checklist.retired_no_successor',
      'email',
      jsonb_build_object('course_id', r.course_id, 'checklist_id', r.id);
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Alert low card stock per section 15.1
CREATE OR REPLACE FUNCTION alert_low_card_stock() RETURNS void AS $$
BEGIN
  INSERT INTO notifications (tenant_id, event_type, channel, payload)
  SELECT
    tenant_id,
    'card_inventory.low_stock',
    'email',
    jsonb_build_object('inventory_id', id, 'quantity', quantity, 'threshold', low_stock_threshold)
  FROM card_inventory
  WHERE quantity <= low_stock_threshold
  AND NOT EXISTS (
    SELECT 1 FROM notifications n
    WHERE n.tenant_id = card_inventory.tenant_id
      AND n.event_type = 'card_inventory.low_stock'
      AND n.payload->>'inventory_id' = card_inventory.id::text
      AND n.created_at > NOW() - INTERVAL '24 hours'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- CARD ISSUANCE TRIGGER — decrement inventory atomically
-- ============================================================

CREATE OR REPLACE FUNCTION decrement_card_inventory() RETURNS TRIGGER AS $$
BEGIN
  UPDATE card_inventory
  SET quantity = quantity - 1
  WHERE id = NEW.inventory_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Card inventory record not found';
  END IF;

  IF (SELECT quantity FROM card_inventory WHERE id = NEW.inventory_id) < 0 THEN
    RAISE EXCEPTION 'Insufficient card inventory';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_card_issued
  AFTER INSERT ON cards
  FOR EACH ROW
  WHEN (NEW.inventory_id IS NOT NULL)
  EXECUTE FUNCTION decrement_card_inventory();

COMMENT ON FUNCTION suspend_lapsed_instructors IS 'Run daily. Auto-suspends per section 6.4';
COMMENT ON FUNCTION flag_dormant_accounts      IS 'Run daily. 90d flag, 180d suspend per section 6.4';
COMMENT ON FUNCTION expire_delegations         IS 'Run hourly. Expires grants per section 5.1';
COMMENT ON FUNCTION alert_retired_checklists   IS 'Run on checklist retirement. Per section 14.3';
COMMENT ON FUNCTION alert_low_card_stock       IS 'Run daily. Per section 15.1';

