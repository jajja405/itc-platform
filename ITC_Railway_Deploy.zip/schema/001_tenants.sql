-- ============================================================
-- ITC Training Management Platform
-- Step 2: PostgreSQL Schema with Row-Level Security
-- Generated from spec modules 06-iam.md + 07-tenancy.md
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- PLATFORM LAYER (no tenant_id — platform-wide tables)
-- ============================================================

CREATE TABLE tenants (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  subdomain       TEXT NOT NULL UNIQUE,
  status          TEXT NOT NULL DEFAULT 'onboarding'
                    CHECK (status IN ('onboarding','active','suspended','offboarding','deleted')),
  plan_tier       TEXT NOT NULL DEFAULT 'standard'
                    CHECK (plan_tier IN ('standard','premium','database-per-tenant')),
  branding        JSONB NOT NULL DEFAULT '{}',
  quotas          JSONB NOT NULL DEFAULT '{}',
  trial_ends_at   TIMESTAMPTZ,
  suspended_at    TIMESTAMPTZ,
  offboarded_at   TIMESTAMPTZ,
  deleted_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE tenants IS 'Platform-level. No RLS — accessible only by platform admin service account.';
COMMENT ON COLUMN tenants.status IS 'onboarding→active→suspended/offboarding→deleted per section 7.2';

