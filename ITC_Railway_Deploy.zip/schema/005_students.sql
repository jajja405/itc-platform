-- ============================================================
-- STUDENTS — self-service account class per section 2.8
-- ============================================================

CREATE TABLE students (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id),
  user_id             UUID REFERENCES users(id),    -- links to users table when self-registered
  name                TEXT NOT NULL,
  email               TEXT,
  phone               TEXT,
  dob                 DATE,
  is_minor            BOOLEAN GENERATED ALWAYS AS (
                        dob IS NOT NULL AND dob > CURRENT_DATE - INTERVAL '18 years'
                      ) STORED,
  guardian_name       TEXT,
  guardian_contact    TEXT,
  guardian_consent    BOOLEAN NOT NULL DEFAULT FALSE,
  consent_captured_at TIMESTAMPTZ,
  notification_prefs  JSONB NOT NULL DEFAULT '{}',  -- channel preferences per 17.4
  marketing_consent   BOOLEAN NOT NULL DEFAULT FALSE,
  status              TEXT NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active','suspended','deletion_requested','deleted')),
  deletion_requested_at TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT minor_needs_guardian CHECK (
    NOT is_minor OR (guardian_name IS NOT NULL AND guardian_contact IS NOT NULL)
  )
);

CREATE INDEX idx_students_tenant  ON students(tenant_id);
CREATE INDEX idx_students_user    ON students(user_id);
CREATE INDEX idx_students_email   ON students(tenant_id, email);

COMMENT ON COLUMN students.is_minor          IS 'Computed. Drives guardian consent requirement per 9.3';
COMMENT ON COLUMN students.guardian_consent  IS 'Required for is_minor=TRUE per section 9.3';
COMMENT ON COLUMN students.marketing_consent IS 'Separate from service consent. Withdrawal takes effect immediately per 9.4';

