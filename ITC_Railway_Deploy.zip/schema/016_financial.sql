-- ============================================================
-- Migration 016 — Financial operations (Step 6)
-- Run after 015_hierarchy_delegation_audit.sql
-- ============================================================

-- ------------------------------------------------------------
-- gateway_transactions
-- Every payment attempt through any gateway connector.
-- Raw card/bank credentials never stored — gateway tokens only (§8.2).
-- ------------------------------------------------------------
CREATE TABLE gateway_transactions (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id),
  gateway          TEXT NOT NULL     -- 'jazzcash'|'easypaisa'|'payfast'|'ibft'|'stripe'|'paypal'
                   CHECK (gateway IN ('jazzcash','easypaisa','payfast','ibft','stripe','paypal')),
  gateway_ref      TEXT NOT NULL,    -- gateway's own transaction ID (token)
  direction        TEXT NOT NULL CHECK (direction IN ('charge','refund','dispute_reversal')),
  amount           NUMERIC(12,2) NOT NULL,
  currency         TEXT NOT NULL DEFAULT 'PKR',
  exchange_rate    NUMERIC(14,6),    -- set for non-PKR settlements
  status           TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','succeeded','failed','disputed','refunded')),
  payer_id         UUID REFERENCES users(id),
  idempotency_key  TEXT UNIQUE,      -- prevents double-execution on retry (§11.2)
  raw_response     JSONB,            -- gateway response (no credentials)
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE gateway_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY gateway_transactions_tenant ON gateway_transactions
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- course_fee_ledger  (§13.2 — tenant-owned, separate from subscription)
-- ------------------------------------------------------------
CREATE TABLE course_fee_ledger (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id),
  entry_type       TEXT NOT NULL
                   CHECK (entry_type IN ('charge','refund','credit_note','dispute_debit','dispute_credit','fx_gain','fx_loss','writeoff')),
  student_id       UUID REFERENCES users(id),
  enrolment_id     UUID,             -- FK to enrolments (set when linked)
  transaction_id   UUID REFERENCES gateway_transactions(id),
  amount           NUMERIC(12,2) NOT NULL,  -- positive = owed/received, negative = refunded
  currency         TEXT NOT NULL DEFAULT 'PKR',
  tax_amount       NUMERIC(12,2) NOT NULL DEFAULT 0,
  tax_rate         NUMERIC(5,4),
  description      TEXT NOT NULL,
  recorded_by      UUID REFERENCES users(id),
  recorded_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- FBR sequential invoice number (§12.4)
  invoice_number   TEXT UNIQUE,
  reconciled       BOOLEAN NOT NULL DEFAULT false,
  reconciled_at    TIMESTAMPTZ
);

ALTER TABLE course_fee_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY course_fee_ledger_tenant ON course_fee_ledger
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- subscription_ledger  (§13.2 — platform revenue, managed by Admin/Super Admin)
-- ------------------------------------------------------------
CREATE TABLE subscription_ledger (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id),
  entry_type       TEXT NOT NULL
                   CHECK (entry_type IN ('subscription_charge','subscription_refund','trial_credit','rate_override','credit')),
  amount           NUMERIC(12,2) NOT NULL,
  currency         TEXT NOT NULL DEFAULT 'PKR',
  billing_cycle    TEXT,             -- e.g. '2025-08'
  transaction_id   UUID REFERENCES gateway_transactions(id),
  override_reason  TEXT,             -- set when entry_type = 'rate_override'
  recorded_by      UUID REFERENCES users(id),
  recorded_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  invoice_number   TEXT UNIQUE,
  reconciled       BOOLEAN NOT NULL DEFAULT false
);

-- No tenant RLS — subscription ledger visible to Admin/Super Admin only
ALTER TABLE subscription_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY subscription_ledger_admin ON subscription_ledger
  USING (current_setting('app.user_role') IN ('super_admin','admin','accountant'));

-- ------------------------------------------------------------
-- refunds
-- Every refund request, approval trail, and gateway outcome.
-- ------------------------------------------------------------
CREATE TABLE refunds (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id          UUID NOT NULL REFERENCES tenants(id),
  original_txn_id    UUID NOT NULL REFERENCES gateway_transactions(id),
  ledger_entry_id    UUID REFERENCES course_fee_ledger(id),
  amount             NUMERIC(12,2) NOT NULL,
  currency           TEXT NOT NULL DEFAULT 'PKR',
  refund_type        TEXT NOT NULL CHECK (refund_type IN ('full','partial','credit_note')),
  within_policy      BOOLEAN NOT NULL,
  initiated_by       UUID NOT NULL REFERENCES users(id),  -- TCC or TCA
  approved_by        UUID REFERENCES users(id),           -- TCC approval for out-of-policy
  approval_reason    TEXT,
  gateway_ref        TEXT,           -- gateway refund transaction ID
  status             TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','approved','processed','failed','cash_alternative')),
  cash_alt_signed_off_by UUID REFERENCES users(id),   -- Accountant sign-off §12.1
  reason             TEXT NOT NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at       TIMESTAMPTZ
);

ALTER TABLE refunds ENABLE ROW LEVEL SECURITY;
CREATE POLICY refunds_tenant ON refunds
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- disputes
-- Opened automatically by gateway webhook (§12.2).
-- ------------------------------------------------------------
CREATE TABLE disputes (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         UUID NOT NULL REFERENCES tenants(id),
  transaction_id    UUID NOT NULL REFERENCES gateway_transactions(id),
  gateway_dispute_id TEXT NOT NULL,
  gateway           TEXT NOT NULL,
  amount            NUMERIC(12,2) NOT NULL,
  currency          TEXT NOT NULL DEFAULT 'PKR',
  reason_code       TEXT,
  deadline          TIMESTAMPTZ,    -- gateway evidence submission deadline
  status            TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open','evidence_submitted','won','lost','withdrawn')),
  assigned_to       UUID REFERENCES users(id),   -- Accountant owns response
  evidence_pack     JSONB,          -- assembled evidence references
  outcome_note      TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at       TIMESTAMPTZ
);

ALTER TABLE disputes ENABLE ROW LEVEL SECURITY;
CREATE POLICY disputes_tenant ON disputes
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- dunning_events  (§12.3 — subscription payment failure sequence)
-- ------------------------------------------------------------
CREATE TABLE dunning_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  day_offset      INTEGER NOT NULL,  -- 0, 3, 7, 14
  event_type      TEXT NOT NULL
                  CHECK (event_type IN ('charge_failed','retry','warning','suspended','reactivated')),
  transaction_id  UUID REFERENCES gateway_transactions(id),
  note            TEXT,
  occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE dunning_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY dunning_events_tenant ON dunning_events
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- reconciliation_exceptions  (§12.5)
-- ------------------------------------------------------------
CREATE TABLE reconciliation_exceptions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  exception_type  TEXT NOT NULL
                  CHECK (exception_type IN ('payment_no_enrolment','enrolment_no_payment','amount_mismatch','settlement_gap')),
  transaction_id  UUID REFERENCES gateway_transactions(id),
  enrolment_id    UUID,
  ledger_entry_id UUID REFERENCES course_fee_ledger(id),
  amount_expected NUMERIC(12,2),
  amount_actual   NUMERIC(12,2),
  opened_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  assigned_to     UUID REFERENCES users(id),   -- Accountant
  resolved_at     TIMESTAMPTZ,
  resolved_by     UUID REFERENCES users(id),
  resolution_note TEXT
);

ALTER TABLE reconciliation_exceptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY recon_exceptions_tenant ON reconciliation_exceptions
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- tenant_subscriptions  (§13.1 — trial, rate, cycle, status)
-- ------------------------------------------------------------
CREATE TABLE tenant_subscriptions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL UNIQUE REFERENCES tenants(id),
  status          TEXT NOT NULL DEFAULT 'trial'
                  CHECK (status IN ('trial','active','suspended','cancelled')),
  trial_ends_at   TIMESTAMPTZ,
  billing_cycle   TEXT NOT NULL DEFAULT 'monthly' CHECK (billing_cycle IN ('monthly','annual')),
  rate_pkr        NUMERIC(12,2) NOT NULL DEFAULT 0,
  rate_override   BOOLEAN NOT NULL DEFAULT false,
  override_reason TEXT,
  next_charge_at  TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_gtxn_tenant      ON gateway_transactions (tenant_id, status, created_at);
CREATE INDEX idx_gtxn_idem        ON gateway_transactions (idempotency_key);
CREATE INDEX idx_cfl_tenant       ON course_fee_ledger (tenant_id, recorded_at);
CREATE INDEX idx_cfl_student      ON course_fee_ledger (student_id);
CREATE INDEX idx_cfl_recon        ON course_fee_ledger (reconciled, tenant_id);
CREATE INDEX idx_refunds_tenant   ON refunds (tenant_id, status);
CREATE INDEX idx_disputes_tenant  ON disputes (tenant_id, status, deadline);
CREATE INDEX idx_dunning_tenant   ON dunning_events (tenant_id, occurred_at);
CREATE INDEX idx_recon_exc_tenant ON reconciliation_exceptions (tenant_id, resolved_at);
CREATE INDEX idx_recon_exc_age    ON reconciliation_exceptions (opened_at) WHERE resolved_at IS NULL;
