-- ============================================================
-- CHECKLISTS, CHECKLIST RECORDS, CARDS, CARD INVENTORY
-- ============================================================

CREATE TABLE checklists (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  course_id       UUID NOT NULL REFERENCES courses(id),
  version_label   TEXT NOT NULL,
  effective_date  DATE NOT NULL,
  status          TEXT NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','retired')),
  field_map       JSONB NOT NULL DEFAULT '{}',  -- mapped checkbox/field positions per 14.2
  file_path       TEXT NOT NULL,
  uploaded_by     UUID NOT NULL REFERENCES users(id),
  retired_at      TIMESTAMPTZ,
  retired_by      UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- One active checklist per course per tenant at any time
  EXCLUDE USING btree (tenant_id WITH =, course_id WITH =)
    WHERE (status = 'active')
);

CREATE INDEX idx_checklists_tenant_course ON checklists(tenant_id, course_id);
CREATE INDEX idx_checklists_status        ON checklists(status);

COMMENT ON TABLE checklists IS 'One active version per course. Retirement triggers alert to upload roles per 14.3';
COMMENT ON COLUMN checklists.field_map IS 'JSON mapping of checkbox IDs to page/x/y positions on the sheet image';

CREATE TABLE checklist_records (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  enrolment_id    UUID NOT NULL REFERENCES enrolments(id),
  checklist_id    UUID NOT NULL REFERENCES checklists(id),
  marked_by       UUID NOT NULL REFERENCES users(id),
  record_type     TEXT NOT NULL
                    CHECK (record_type IN ('student_test','irf_monitoring')),
  marks           JSONB NOT NULL DEFAULT '{}',    -- {field_id: boolean|value}
  passed          BOOLEAN,
  signature_data  TEXT,                           -- base64 drawn signature
  pdf_path        TEXT,                           -- immutable archived PDF per 14.4
  completed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
  -- No UPDATE or DELETE — records are immutable. Amendments = new record with amendment_of FK
);

ALTER TABLE checklist_records ADD COLUMN amendment_of UUID REFERENCES checklist_records(id);

CREATE INDEX idx_checklist_records_enrolment ON checklist_records(enrolment_id);
CREATE INDEX idx_checklist_records_tenant    ON checklist_records(tenant_id);

COMMENT ON COLUMN checklist_records.record_type    IS 'student_test = skills test; irf_monitoring = IRF evaluating the instructor per 2.6';
COMMENT ON COLUMN checklist_records.pdf_path       IS 'Immutable. Corrections via new record with amendment_of set per 14.5';
COMMENT ON COLUMN checklist_records.amendment_of   IS 'Linked original record. Both retained in file per 14.5';

-- ============================================================
-- CARD INVENTORY per section 15
-- ============================================================

CREATE TABLE card_inventory (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id),
  discipline          TEXT NOT NULL,
  card_type           TEXT NOT NULL CHECK (card_type IN ('physical','ecard')),
  quantity            INT NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  low_stock_threshold INT NOT NULL DEFAULT 10,
  allocated_to        UUID REFERENCES users(id),   -- NULL = unallocated pool
  batch_ref           TEXT,
  received_at         DATE,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_card_inventory_tenant ON card_inventory(tenant_id);
CREATE INDEX idx_card_inventory_alloc  ON card_inventory(allocated_to);

-- ============================================================
-- CARDS per section 2.9 and 15
-- ============================================================

CREATE TABLE cards (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id),
  student_id          UUID NOT NULL REFERENCES students(id),
  enrolment_id        UUID NOT NULL REFERENCES enrolments(id),
  inventory_id        UUID REFERENCES card_inventory(id),
  discipline          TEXT NOT NULL,
  verification_code   TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(12), 'hex'),
  card_type           TEXT NOT NULL CHECK (card_type IN ('physical','ecard')),
  issued_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at          DATE NOT NULL,
  status              TEXT NOT NULL DEFAULT 'valid'
                        CHECK (status IN ('valid','expired','revoked','voided')),
  issued_by           UUID NOT NULL REFERENCES users(id),
  revoked_at          TIMESTAMPTZ,
  revoked_by          UUID REFERENCES users(id),
  revocation_reason   TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cards_tenant            ON cards(tenant_id);
CREATE INDEX idx_cards_student           ON cards(student_id);
CREATE INDEX idx_cards_verification_code ON cards(verification_code);
CREATE INDEX idx_cards_status            ON cards(status);

COMMENT ON COLUMN cards.verification_code IS 'Public verification link. Revoked/expired cards show status honestly per 2.9';

