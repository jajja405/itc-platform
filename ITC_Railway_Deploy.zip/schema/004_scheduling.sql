-- ============================================================
-- COURSES, SITES, CLASSES, ENROLMENTS — scheduling layer
-- ============================================================

CREATE TABLE courses (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id         UUID NOT NULL REFERENCES tenants(id),
  title             TEXT NOT NULL,
  discipline        TEXT NOT NULL,
  level             TEXT NOT NULL CHECK (level IN ('provider','advanced','instructor')),
  requires_director BOOLEAN NOT NULL DEFAULT FALSE,  -- ACLS/PALS/PEARS require Course Director
  max_students      INT NOT NULL DEFAULT 12,
  instructor_ratio  INT NOT NULL DEFAULT 6,          -- max students per instructor
  manikin_ratio     INT NOT NULL DEFAULT 2,
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_courses_tenant ON courses(tenant_id);

CREATE TABLE sites (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id),
  name        TEXT NOT NULL,
  address     JSONB NOT NULL DEFAULT '{}',
  timezone    TEXT NOT NULL DEFAULT 'Asia/Karachi',
  tsc_id      UUID REFERENCES users(id),
  status      TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sites_tenant ON sites(tenant_id);
CREATE INDEX idx_sites_tsc    ON sites(tsc_id);

CREATE TABLE classes (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id           UUID NOT NULL REFERENCES tenants(id),
  course_id           UUID NOT NULL REFERENCES courses(id),
  site_id             UUID REFERENCES sites(id),
  lead_instructor_id  UUID REFERENCES users(id),
  course_director_id  UUID REFERENCES users(id),   -- required when course.requires_director
  starts_at           TIMESTAMPTZ NOT NULL,
  ends_at             TIMESTAMPTZ NOT NULL,
  timezone            TEXT NOT NULL DEFAULT 'Asia/Karachi',
  capacity            INT NOT NULL,
  status              TEXT NOT NULL DEFAULT 'scheduled'
                        CHECK (status IN ('scheduled','published','in_progress','completed','cancelled')),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT class_time_valid CHECK (ends_at > starts_at)
);

CREATE INDEX idx_classes_tenant      ON classes(tenant_id);
CREATE INDEX idx_classes_course      ON classes(course_id);
CREATE INDEX idx_classes_starts_at   ON classes(starts_at);
CREATE INDEX idx_classes_instructor  ON classes(lead_instructor_id);
CREATE INDEX idx_classes_director    ON classes(course_director_id);

-- Prevent instructor double-booking across overlapping classes
CREATE UNIQUE INDEX idx_classes_no_instructor_overlap
  ON classes(lead_instructor_id, starts_at, ends_at)
  WHERE lead_instructor_id IS NOT NULL AND status <> 'cancelled';

COMMENT ON COLUMN classes.timezone IS 'Display timezone. All timestamps stored UTC per 16.4';

CREATE TABLE enrolments (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id         UUID NOT NULL REFERENCES tenants(id),
  student_id        UUID NOT NULL REFERENCES students(id),
  class_id          UUID NOT NULL REFERENCES classes(id),
  status            TEXT NOT NULL DEFAULT 'enrolled'
                      CHECK (status IN ('waitlisted','enrolled','attended','no_show','cancelled')),
  waitlist_position INT,
  enrolled_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  attended_at       TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,
  cancelled_by      UUID REFERENCES users(id),
  UNIQUE (student_id, class_id)
);

CREATE INDEX idx_enrolments_tenant  ON enrolments(tenant_id);
CREATE INDEX idx_enrolments_class   ON enrolments(class_id);
CREATE INDEX idx_enrolments_student ON enrolments(student_id);

