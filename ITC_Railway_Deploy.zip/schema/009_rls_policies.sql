-- ============================================================
-- ROW-LEVEL SECURITY POLICIES — section 7.1
--
-- Strategy: all tenant-scoped tables enable RLS.
-- App service account sets session variable:
--   SET LOCAL app.current_tenant_id = '<uuid>';
--   SET LOCAL app.current_user_id   = '<uuid>';
--   SET LOCAL app.current_role      = '<role>';
-- Platform admin service account bypasses RLS via BYPASSRLS.
-- ============================================================

-- Helper function: resolve current tenant from session variable
CREATE OR REPLACE FUNCTION current_tenant_id() RETURNS UUID AS $$
  SELECT NULLIF(current_setting('app.current_tenant_id', TRUE), '')::UUID;
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION current_user_id() RETURNS UUID AS $$
  SELECT NULLIF(current_setting('app.current_user_id', TRUE), '')::UUID;
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION current_app_role() RETURNS TEXT AS $$
  SELECT NULLIF(current_setting('app.current_role', TRUE), '');
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION is_platform_admin() RETURNS BOOLEAN AS $$
  SELECT current_app_role() IN ('super_admin', 'admin');
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- ============================================================
-- Enable RLS on all tenant-scoped tables
-- ============================================================

ALTER TABLE users              ENABLE ROW LEVEL SECURITY;
ALTER TABLE instructors        ENABLE ROW LEVEL SECURITY;
ALTER TABLE irf_permissions    ENABLE ROW LEVEL SECURITY;
ALTER TABLE delegations        ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses            ENABLE ROW LEVEL SECURITY;
ALTER TABLE sites              ENABLE ROW LEVEL SECURITY;
ALTER TABLE classes            ENABLE ROW LEVEL SECURITY;
ALTER TABLE students           ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrolments         ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklists         ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklist_records  ENABLE ROW LEVEL SECURITY;
ALTER TABLE card_inventory     ENABLE ROW LEVEL SECURITY;
ALTER TABLE cards              ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments           ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_ledger      ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE complaints         ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications      ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log          ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- POLICIES — tenant isolation
-- Platform admins see all rows. Tenant sessions see own tenant only.
-- ============================================================

-- USERS
CREATE POLICY users_tenant_isolation ON users
  USING (
    is_platform_admin()
    OR tenant_id = current_tenant_id()
    OR tenant_id IS NULL  -- platform-level accounts visible to platform admin only (guarded above)
  );

-- INSTRUCTORS
CREATE POLICY instructors_tenant_isolation ON instructors
  USING (
    is_platform_admin()
    OR tenant_id = current_tenant_id()
  );

-- IRF PERMISSIONS — platform admin + the user themselves
CREATE POLICY irf_isolation ON irf_permissions
  USING (
    is_platform_admin()
    OR user_id = current_user_id()
  );

-- DELEGATIONS
CREATE POLICY delegations_tenant_isolation ON delegations
  USING (
    is_platform_admin()
    OR tenant_id = current_tenant_id()
    OR tenant_id IS NULL AND is_platform_admin()
  );

-- COURSES
CREATE POLICY courses_tenant_isolation ON courses
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- SITES
CREATE POLICY sites_tenant_isolation ON sites
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- CLASSES
CREATE POLICY classes_tenant_isolation ON classes
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- STUDENTS
CREATE POLICY students_tenant_isolation ON students
  USING (
    is_platform_admin()
    OR tenant_id = current_tenant_id()
  );

-- Student self-service: students see only their own record
CREATE POLICY students_self_view ON students
  AS PERMISSIVE FOR SELECT
  USING (
    current_app_role() = 'student'
    AND user_id = current_user_id()
  );

-- ENROLMENTS
CREATE POLICY enrolments_tenant_isolation ON enrolments
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- CHECKLISTS
CREATE POLICY checklists_tenant_isolation ON checklists
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- CHECKLIST RECORDS
CREATE POLICY checklist_records_tenant_isolation ON checklist_records
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- CARD INVENTORY
CREATE POLICY card_inventory_tenant_isolation ON card_inventory
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- CARDS — public verification endpoint bypasses RLS via dedicated function
CREATE POLICY cards_tenant_isolation ON cards
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- PAYMENTS
CREATE POLICY payments_tenant_isolation ON payments
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- COURSE LEDGER
CREATE POLICY course_ledger_tenant_isolation ON course_ledger
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- SUBSCRIPTION LEDGER — tenant sees own; platform admin sees all
CREATE POLICY subscription_ledger_isolation ON subscription_ledger
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- COMPLAINTS
CREATE POLICY complaints_tenant_isolation ON complaints
  USING (is_platform_admin() OR tenant_id = current_tenant_id());

-- NOTIFICATIONS
CREATE POLICY notifications_isolation ON notifications
  USING (
    is_platform_admin()
    OR tenant_id = current_tenant_id()
    OR recipient_id = current_user_id()
  );

-- AUDIT LOG
-- Tenant sees own entries + the operator access transparency subset per 7.5
CREATE POLICY audit_log_tenant_view ON audit_log
  USING (
    is_platform_admin()
    OR tenant_id = current_tenant_id()
  );

-- ============================================================
-- SERVICE ROLES
-- ============================================================

-- App service role: used by the API server
CREATE ROLE itc_app NOLOGIN;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO itc_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO itc_app;
-- Audit log: INSERT only (no UPDATE/DELETE enforced by rules above)
REVOKE UPDATE, DELETE ON audit_log FROM itc_app;

-- Platform admin service role: BYPASSRLS for cross-tenant operations
-- Only used by the platform admin module; API key scoped per 6.3
CREATE ROLE itc_platform_admin NOLOGIN BYPASSRLS;
GRANT ALL ON ALL TABLES IN SCHEMA public TO itc_platform_admin;

-- Read-only reporting replica role
CREATE ROLE itc_reporting NOLOGIN;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO itc_reporting;

COMMENT ON ROLE itc_app            IS 'API server service account. Scoped to single integration per 6.3';
COMMENT ON ROLE itc_platform_admin IS 'BYPASSRLS. Used only for cross-tenant admin operations. Every use logged per 7.5';
COMMENT ON ROLE itc_reporting      IS 'Read-only replica access for reporting queries per 18.3';

