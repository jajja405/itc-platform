-- ============================================================
-- PAYMENTS, COURSE LEDGER, SUBSCRIPTION LEDGER, COMPLAINTS
-- ============================================================

CREATE TABLE payments (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  student_id      UUID REFERENCES students(id),
  enrolment_id    UUID REFERENCES enrolments(id),
  gateway         TEXT NOT NULL
                    CHECK (gateway IN ('jazzcash','easypaisa','payfast','ibft','stripe','paypal')),
  gateway_token   TEXT NOT NULL,      -- tokenised reference; raw credentials never stored
  currency        TEXT NOT NULL DEFAULT 'PKR',
  amount          NUMERIC(12,2) NOT NULL,
  exchange_rate   NUMERIC(12,6),      -- non-null for foreign currency settlements
  status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','completed','failed','refunded','disputed')),
  refund_of       UUID REFERENCES payments(id),
  initiated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at    TIMESTAMPTZ
);

CREATE INDEX idx_payments_tenant      ON payments(tenant_id);
CREATE INDEX idx_payments_enrolment   ON payments(enrolment_id);
CREATE INDEX idx_payments_gateway_tok ON payments(gateway_token);

COMMENT ON COLUMN payments.gateway_token IS 'PCI-DSS: only tokens stored. Raw card/bank data never touches this DB per 8.2';
COMMENT ON COLUMN payments.exchange_rate IS 'Rate at transaction date for PKR conversion per 12.4';

CREATE TABLE course_ledger (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  payment_id      UUID REFERENCES payments(id),
  enrolment_id    UUID REFERENCES enrolments(id),
  entry_type      TEXT NOT NULL
                    CHECK (entry_type IN ('fee','refund','adjustment','writeoff')),
  amount          NUMERIC(12,2) NOT NULL,
  description     TEXT,
  created_by      UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_course_ledger_tenant ON course_ledger(tenant_id);

COMMENT ON TABLE course_ledger IS 'Tenant course fee ledger. Separate from subscription ledger per section 13.2';

-- Encrypted per-tenant financial data: tenant financial ledgers use per-tenant
-- data keys under platform master key per section 7.1 / 8.1.
-- Encryption is applied at the application layer using the tenant's data key.
-- The column stores the AES-256-GCM ciphertext envelope.

CREATE TABLE subscription_ledger (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  amount          NUMERIC(12,2) NOT NULL,
  currency        TEXT NOT NULL DEFAULT 'PKR',
  status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','paid','failed','waived')),
  gateway         TEXT CHECK (gateway IN ('jazzcash','easypaisa','payfast','ibft','stripe','paypal')),
  gateway_token   TEXT,
  billing_date    DATE NOT NULL,
  due_date        DATE NOT NULL,
  paid_at         TIMESTAMPTZ,
  dunning_stage   INT NOT NULL DEFAULT 0
                    CHECK (dunning_stage BETWEEN 0 AND 4),  -- 0=none,1=day0,2=day3,3=day7,4=day14
  next_retry_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sub_ledger_tenant       ON subscription_ledger(tenant_id);
CREATE INDEX idx_sub_ledger_billing_date ON subscription_ledger(billing_date);
CREATE INDEX idx_sub_ledger_dunning      ON subscription_ledger(dunning_stage, next_retry_at)
  WHERE status = 'pending';

COMMENT ON COLUMN subscription_ledger.dunning_stage IS '0-4 stages per section 12.3: day 0,3,7,14';

-- ============================================================
-- COMPLAINTS per section 3.6
-- ============================================================

CREATE TABLE complaints (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  filed_by        UUID REFERENCES users(id),        -- NULL if filed by student directly
  student_id      UUID REFERENCES students(id),     -- set when student files directly
  assigned_to     UUID REFERENCES users(id),
  channel         TEXT NOT NULL
                    CHECK (channel IN ('portal','helpline','whatsapp','phone','chat')),
  scope           TEXT NOT NULL CHECK (scope IN ('centre','site')),
  status          TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open','acknowledged','investigating','resolved','closed')),
  description     TEXT NOT NULL,
  resolution      TEXT,
  filed_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  acknowledged_at TIMESTAMPTZ,   -- target: 2 working days per 18.1
  resolved_at     TIMESTAMPTZ,   -- target: 10 working days per 18.1
  closed_at       TIMESTAMPTZ
);

CREATE INDEX idx_complaints_tenant      ON complaints(tenant_id);
CREATE INDEX idx_complaints_assigned    ON complaints(assigned_to, status);
CREATE INDEX idx_complaints_student     ON complaints(student_id);

