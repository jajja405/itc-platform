-- ============================================================
-- USERS, SESSIONS, MFA — IAM section 6.1 / 6.2
-- ============================================================

CREATE TABLE users (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id           UUID REFERENCES tenants(id) ON DELETE RESTRICT,
  -- NULL tenant_id = platform-level account (Super Admin / Admin)
  email               TEXT NOT NULL,
  phone               TEXT,
  password_hash       TEXT,
  -- NULL when SSO-only account
  role                TEXT NOT NULL
                        CHECK (role IN (
                          'super_admin','admin',
                          'tcc','tca','tcf','instructor',
                          'tsc','tsa',
                          'helpline_agent','agentic_ai','accountant',
                          'student'
                        )),
  status              TEXT NOT NULL DEFAULT 'active'
                        CHECK (status IN ('active','suspended','deactivated','dormant_flagged')),
  mfa_enabled         BOOLEAN NOT NULL DEFAULT FALSE,
  mfa_secret          TEXT,                          -- encrypted TOTP secret
  mfa_backup_codes    TEXT[],                        -- bcrypt-hashed backup codes
  sso_provider        TEXT,                          -- 'oidc' | 'saml' | NULL
  sso_subject         TEXT,                          -- external identity subject
  failed_login_count  INT NOT NULL DEFAULT 0,
  locked_until        TIMESTAMPTZ,
  owner_id            UUID REFERENCES users(id),     -- named account owner per 6.4
  last_login_at       TIMESTAMPTZ,
  dormant_flagged_at  TIMESTAMPTZ,
  deactivated_at      TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, email),
  CONSTRAINT platform_accounts_no_tenant
    CHECK (role NOT IN ('super_admin','admin') OR tenant_id IS NULL)
);

CREATE INDEX idx_users_tenant     ON users(tenant_id);
CREATE INDEX idx_users_role       ON users(role);
CREATE INDEX idx_users_status     ON users(status);
CREATE INDEX idx_users_sso        ON users(sso_provider, sso_subject) WHERE sso_provider IS NOT NULL;

COMMENT ON COLUMN users.tenant_id       IS 'NULL for Super Admin and Admin — platform-level accounts';
COMMENT ON COLUMN users.password_hash   IS 'bcrypt. NULL for SSO-only accounts';
COMMENT ON COLUMN users.mfa_secret      IS 'AES-256 encrypted. Mandatory for admin/tcc/tca/accountant per 6.1';
COMMENT ON COLUMN users.owner_id        IS 'Named owner responsible for account recertification per 6.4';

-- ============================================================
-- SESSIONS — section 6.2
-- ============================================================

CREATE TABLE sessions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tenant_id       UUID REFERENCES tenants(id),
  token_hash      TEXT NOT NULL UNIQUE,             -- SHA-256 of bearer token
  device_info     JSONB NOT NULL DEFAULT '{}',      -- UA, IP, device fingerprint
  is_step_up      BOOLEAN NOT NULL DEFAULT FALSE,   -- elevated for high-impact action
  idle_timeout_s  INT NOT NULL DEFAULT 1800,        -- 1800=admin, 28800=staff, 2592000=student
  expires_at      TIMESTAMPTZ NOT NULL,
  last_active_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  revoked_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_user       ON sessions(user_id) WHERE revoked_at IS NULL;
CREATE INDEX idx_sessions_token_hash ON sessions(token_hash);

COMMENT ON COLUMN sessions.idle_timeout_s  IS '30min admin/tcc/tca/accountant, 8hr staff, 30d student per 6.2';
COMMENT ON COLUMN sessions.is_step_up      IS 'Set after re-auth for payment settings, bulk export, delegation changes';

-- ============================================================
-- MFA EVENTS — lockout audit trail per 6.1
-- ============================================================

CREATE TABLE auth_events (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id),
  event_type  TEXT NOT NULL
                CHECK (event_type IN (
                  'login_success','login_failure','lockout',
                  'mfa_success','mfa_failure','mfa_setup',
                  'password_reset','session_revoked','step_up',
                  'break_glass_used'
                )),
  ip_address  INET,
  device_info JSONB,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_auth_events_user ON auth_events(user_id, occurred_at DESC);

COMMENT ON TABLE auth_events IS 'Append-only lockout and auth trail. Feeds audit log per 8.3';

