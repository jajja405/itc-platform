-- ITC Training Management Platform — run all migrations in order
-- Run from psql: \i 000_run_all.sql

\i 001_tenants.sql
\i 002_users_auth.sql
\i 003_roles_permissions.sql
\i 004_scheduling.sql
\i 005_students.sql
\i 006_checklists_cards.sql
\i 007_financial.sql
\i 008_notifications_audit.sql
\i 009_rls_policies.sql
\i 010_automated_jobs.sql
\i 011_slice1_additions.sql
\i 012_checklists.sql
\i 013_cards.sql
\i 014_complaints.sql
\i 015_hierarchy_delegation_audit.sql
\i 016_financial.sql
\i 017_notifications.sql
\i 018_helpline.sql
