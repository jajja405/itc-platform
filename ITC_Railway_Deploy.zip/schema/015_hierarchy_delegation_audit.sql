-- ============================================================
-- Migration 015 — Hierarchy, delegation, audit log (Step 5e)
-- Run after 014_complaints.sql
-- ============================================================

-- ------------------------------------------------------------
-- delegations
-- Immutable grant records (§5.1 Renewal: "Existing grants are
-- immutable records"). Status is updated but the record is never deleted.
-- ------------------------------------------------------------
CREATE TABLE delegations (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID NOT NULL REFERENCES tenants(id),
  grantor_id   UUID NOT NULL REFERENCES users(id),  -- Admin or Super Admin
  recipient_id UUID NOT NULL REFERENCES users(id),
  permission   TEXT NOT NULL,        -- single named permission, e.g. 'card:issue'
  starts_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at   TIMESTAMPTZ NOT NULL,
  status       TEXT NOT NULL DEFAULT 'active'
               CHECK (status IN ('active','expired','revoked_early','blocked_redundant')),
  revoked_at   TIMESTAMPTZ,
  revoked_by   UUID REFERENCES users(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE delegations ENABLE ROW LEVEL SECURITY;
CREATE POLICY delegations_tenant ON delegations
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- No DELETE ever; status transitions only
CREATE RULE no_delete_delegations AS ON DELETE TO delegations DO INSTEAD NOTHING;

-- Unique active grant per recipient+permission (enforces overlap block §5.1)
CREATE UNIQUE INDEX idx_delegations_active_unique
  ON delegations (tenant_id, recipient_id, permission)
  WHERE status = 'active';

CREATE INDEX idx_delegations_recipient
  ON delegations (recipient_id, status, expires_at);
CREATE INDEX idx_delegations_expires
  ON delegations (expires_at, status);

-- ------------------------------------------------------------
-- account_recertifications
-- Quarterly TCC review / semi-annual Super Admin review (§6.4).
-- ------------------------------------------------------------
CREATE TABLE account_recertifications (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL REFERENCES tenants(id),
  reviewer_id     UUID NOT NULL REFERENCES users(id),
  reviewed_user_id UUID NOT NULL REFERENCES users(id),
  period          TEXT NOT NULL,      -- e.g. '2025-Q3'
  confirmed       BOOLEAN NOT NULL,
  note            TEXT,
  reviewed_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE account_recertifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY account_recertifications_tenant ON account_recertifications
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- ------------------------------------------------------------
-- audit_log (authoritative platform-wide log §8.3)
-- Append-only, hash-chained, tamper-evident.
-- No role — including Super Admin — may edit or purge entries.
-- ------------------------------------------------------------
CREATE TABLE audit_log (
  id            BIGSERIAL PRIMARY KEY,
  tenant_id     UUID REFERENCES tenants(id),   -- NULL for platform-level events
  actor_id      UUID REFERENCES users(id),
  action        TEXT NOT NULL,
  entity_type   TEXT,
  entity_id     UUID,
  meta          JSONB,
  occurred_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- Hash chain: each entry hashes its own content + previous entry's hash
  entry_hash    TEXT NOT NULL,        -- SHA-256 of (id‖action‖meta‖prev_hash)
  prev_hash     TEXT                  -- NULL for the first entry
);

-- Immutability: no UPDATE or DELETE on audit_log by anyone
CREATE RULE no_update_audit_log AS ON UPDATE TO audit_log DO INSTEAD NOTHING;
CREATE RULE no_delete_audit_log AS ON DELETE TO audit_log DO INSTEAD NOTHING;

-- RLS: tenants see only their own rows; platform rows (tenant_id IS NULL) visible to admins only
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY audit_log_tenant ON audit_log
  USING (
    tenant_id = current_setting('app.tenant_id')::UUID
    OR tenant_id IS NULL
  );

-- Retention: entries must survive at least 3 years (enforced at application layer)
CREATE INDEX idx_audit_log_tenant_time   ON audit_log (tenant_id, occurred_at DESC);
CREATE INDEX idx_audit_log_actor         ON audit_log (actor_id, occurred_at DESC);
CREATE INDEX idx_audit_log_entity        ON audit_log (entity_type, entity_id);
CREATE INDEX idx_audit_log_action        ON audit_log (action, occurred_at DESC);

-- ------------------------------------------------------------
-- sessions  (§6.2 — active session tracking)
-- ------------------------------------------------------------
CREATE TABLE user_sessions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id),
  tenant_id    UUID REFERENCES tenants(id),
  device_label TEXT,
  ip_address   TEXT,
  user_agent   TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at   TIMESTAMPTZ NOT NULL,
  revoked_at   TIMESTAMPTZ,
  revoked_by   UUID REFERENCES users(id),
  revoke_reason TEXT   -- 'user_logout','password_change','mfa_change','role_change','deactivation','admin_revoke'
);

ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY user_sessions_own ON user_sessions
  USING (
    user_id = current_setting('app.user_id')::UUID
    OR current_setting('app.user_role') IN ('super_admin','admin')
  );

CREATE INDEX idx_sessions_user    ON user_sessions (user_id, revoked_at);
CREATE INDEX idx_sessions_expires ON user_sessions (expires_at, revoked_at);
