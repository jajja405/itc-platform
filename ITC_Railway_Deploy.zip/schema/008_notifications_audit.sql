-- ============================================================
-- NOTIFICATIONS and AUDIT LOG
-- ============================================================

CREATE TABLE notifications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID REFERENCES tenants(id),      -- NULL = platform notification
  recipient_id    UUID REFERENCES users(id),
  student_id      UUID REFERENCES students(id),     -- when sent to a student account
  event_type      TEXT NOT NULL,                    -- 'booking_confirmed','card_issued', etc.
  channel         TEXT NOT NULL
                    CHECK (channel IN ('email','sms','whatsapp','push','in_app')),
  template_id     TEXT,
  payload         JSONB NOT NULL DEFAULT '{}',
  status          TEXT NOT NULL DEFAULT 'queued'
                    CHECK (status IN ('queued','sent','delivered','failed')),
  sent_at         TIMESTAMPTZ,
  delivered_at    TIMESTAMPTZ,
  failed_at       TIMESTAMPTZ,
  failure_reason  TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_tenant    ON notifications(tenant_id);
CREATE INDEX idx_notifications_recipient ON notifications(recipient_id);
CREATE INDEX idx_notifications_status    ON notifications(status, created_at);

-- ============================================================
-- PLATFORM-WIDE AUDIT LOG — section 8.3
-- Append-only. Hash-chained for tamper evidence.
-- No role including Super Admin may UPDATE or DELETE rows.
-- ============================================================

CREATE TABLE audit_log (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  seq             BIGSERIAL UNIQUE NOT NULL,         -- monotonic sequence for chain integrity
  tenant_id       UUID REFERENCES tenants(id),       -- NULL = platform-level event
  actor_id        UUID REFERENCES users(id),
  actor_role      TEXT NOT NULL,                     -- snapshot at time of action
  action          TEXT NOT NULL,                     -- e.g. 'card.issued','delegation.granted'
  entity_type     TEXT,                              -- e.g. 'cards','users'
  entity_id       UUID,
  reason          TEXT,                              -- required for admin access to tenant data
  ticket_ref      TEXT,                              -- support ticket ref per 7.5
  diff            JSONB,                             -- before/after snapshot
  prev_hash       TEXT,                              -- SHA-256 of previous row for chain
  row_hash        TEXT NOT NULL,                     -- SHA-256 of this row's content
  occurred_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ip_address      INET,
  session_id      UUID REFERENCES sessions(id)
);

CREATE INDEX idx_audit_tenant      ON audit_log(tenant_id, occurred_at DESC);
CREATE INDEX idx_audit_actor       ON audit_log(actor_id, occurred_at DESC);
CREATE INDEX idx_audit_entity      ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_action      ON audit_log(action, occurred_at DESC);

-- Prevent any modification after insert
CREATE RULE audit_no_update AS ON UPDATE TO audit_log DO INSTEAD NOTHING;
CREATE RULE audit_no_delete AS ON DELETE TO audit_log DO INSTEAD NOTHING;

COMMENT ON TABLE audit_log IS
  'Append-only, hash-chained, tamper-evident. Min 3yr retention per 8.3. '
  'Admin access to tenant data MUST include reason and ticket_ref per 7.5.';
COMMENT ON COLUMN audit_log.prev_hash IS 'SHA-256 of row (seq-1). Enables chain integrity verification.';
COMMENT ON COLUMN audit_log.ticket_ref IS 'Required when actor is super_admin or admin accessing a tenant record per 7.5';

