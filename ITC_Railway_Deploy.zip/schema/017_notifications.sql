-- ============================================================
-- Migration 017 — Notifications (Step 7)
-- Run after 016_financial.sql
-- ============================================================

-- ------------------------------------------------------------
-- notification_templates  (§17.3)
-- Per-tenant, per-event, per-locale. Variables validated at save time.
-- Platform-level compliance notices are not tenant-editable.
-- ------------------------------------------------------------
CREATE TABLE notification_templates (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID REFERENCES tenants(id),   -- NULL = platform-level (not editable by tenants)
  event_type   TEXT NOT NULL,
  channel      TEXT NOT NULL CHECK (channel IN ('email','sms','whatsapp','push','in_app')),
  locale       TEXT NOT NULL DEFAULT 'en' CHECK (locale IN ('en','ur')),
  subject      TEXT,               -- email only
  body         TEXT NOT NULL,      -- may contain {{variable}} placeholders
  variables    JSONB NOT NULL DEFAULT '[]',   -- list of expected variable names
  is_platform  BOOLEAN NOT NULL DEFAULT false,  -- true = not tenant-editable
  active       BOOLEAN NOT NULL DEFAULT true,
  created_by   UUID REFERENCES users(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, event_type, channel, locale)
);

ALTER TABLE notification_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY notif_templates_tenant ON notification_templates
  USING (
    tenant_id = current_setting('app.tenant_id')::UUID
    OR tenant_id IS NULL
  );

-- ------------------------------------------------------------
-- notification_preferences  (§17.4)
-- Per-user, per-category channel preferences.
-- Transactional notices cannot be fully disabled.
-- ------------------------------------------------------------
CREATE TABLE notification_preferences (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(id),
  category    TEXT NOT NULL,   -- 'booking','reminders','cards','payments','marketing','complaints'
  email       BOOLEAN NOT NULL DEFAULT true,
  sms         BOOLEAN NOT NULL DEFAULT true,
  whatsapp    BOOLEAN NOT NULL DEFAULT true,
  push        BOOLEAN NOT NULL DEFAULT true,
  in_app      BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (user_id, category)
);

-- ------------------------------------------------------------
-- notification_queue  (§17 — pending outbound notifications)
-- Populated by event-emitting services; consumed by dispatcher.
-- Replaces the ad-hoc notification_events table used in earlier steps.
-- ------------------------------------------------------------
CREATE TABLE notification_queue (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID REFERENCES tenants(id),
  recipient_id UUID NOT NULL REFERENCES users(id),
  event_type   TEXT NOT NULL,
  channel      TEXT NOT NULL CHECK (channel IN ('email','sms','whatsapp','push','in_app')),
  payload      JSONB NOT NULL DEFAULT '{}',
  scheduled_at TIMESTAMPTZ NOT NULL DEFAULT now(),  -- when to send
  priority     TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('critical','high','normal','low')),
  status       TEXT NOT NULL DEFAULT 'pending'
               CHECK (status IN ('pending','sent','failed','suppressed')),
  attempts     INTEGER NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE notification_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY notif_queue_tenant ON notification_queue
  USING (tenant_id = current_setting('app.tenant_id')::UUID OR tenant_id IS NULL);

CREATE INDEX idx_nq_pending    ON notification_queue (status, scheduled_at) WHERE status = 'pending';
CREATE INDEX idx_nq_recipient  ON notification_queue (recipient_id, created_at);

-- ------------------------------------------------------------
-- notification_log  (§17.4 — every send logged for dispute resolution)
-- ------------------------------------------------------------
CREATE TABLE notification_log (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  queue_entry_id  UUID REFERENCES notification_queue(id),
  tenant_id       UUID REFERENCES tenants(id),
  recipient_id    UUID NOT NULL REFERENCES users(id),
  event_type      TEXT NOT NULL,
  channel         TEXT NOT NULL,
  status          TEXT NOT NULL,  -- 'sent'|'failed'|'suppressed'
  provider_ref    TEXT,           -- provider message ID
  failure_reason  TEXT,
  sent_at         TIMESTAMPTZ,
  delivered_at    TIMESTAMPTZ,    -- set by delivery webhook from provider
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_nl_recipient ON notification_log (recipient_id, created_at DESC);
CREATE INDEX idx_nl_event     ON notification_log (event_type, sent_at DESC);

-- ------------------------------------------------------------
-- scheduled_notifications  (for time-offset events: reminders, expiry warnings)
-- Populated by services; consumed by the scheduler.
-- ------------------------------------------------------------
CREATE TABLE scheduled_notifications (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID REFERENCES tenants(id),
  send_at      TIMESTAMPTZ NOT NULL,
  event_type   TEXT NOT NULL,
  payload      JSONB NOT NULL DEFAULT '{}',
  fired        BOOLEAN NOT NULL DEFAULT false,
  fired_at     TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_sn_pending ON scheduled_notifications (send_at, fired) WHERE fired = false;
