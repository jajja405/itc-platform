-- ============================================================
-- INSTRUCTORS, IRF, DELEGATIONS — roles and authority layer
-- ============================================================

CREATE TABLE instructors (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  tenant_id           UUID NOT NULL REFERENCES tenants(id),
  discipline          TEXT NOT NULL,
  alignment_status    TEXT NOT NULL DEFAULT 'aligned'
                        CHECK (alignment_status IN ('aligned','lapsed','suspended','revoked')),
  card_expiry         DATE NOT NULL,
  last_taught_at      DATE,
  courses_led_2yr     INT NOT NULL DEFAULT 0,       -- auto-updated; gates TCF promotion
  is_tcf              BOOLEAN NOT NULL DEFAULT FALSE,
  tcf_appointed_at    DATE,
  tcf_expires_at      DATE,
  primary_tenant_id   UUID REFERENCES tenants(id),  -- AHA primary alignment
  teach_suspended_at  TIMESTAMPTZ,                  -- auto-set when card expires or alignment lapses
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, tenant_id, discipline)
);

CREATE INDEX idx_instructors_tenant      ON instructors(tenant_id);
CREATE INDEX idx_instructors_card_expiry ON instructors(card_expiry);
CREATE INDEX idx_instructors_alignment   ON instructors(alignment_status);

COMMENT ON COLUMN instructors.alignment_status   IS 'Drives auto-suspension of teach-and-test permission per 6.4';
COMMENT ON COLUMN instructors.courses_led_2yr    IS 'Rolling 2yr count. ≥8 + TCF programme → eligible for TCF per 2.3';
COMMENT ON COLUMN instructors.teach_suspended_at IS 'Set automatically by scheduled job when card_expiry passes or alignment lapses';

-- ============================================================
-- IRF PERMISSIONS — guest audit overlay per section 2.6
-- ============================================================

CREATE TABLE irf_permissions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id),
  granted_by_aha  TEXT NOT NULL,                    -- AHA reference / issuing body
  valid_from      DATE NOT NULL,
  valid_until     DATE NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT irf_no_home_audit CHECK (TRUE)         -- enforced at app layer: cannot audit own tenant
);

CREATE INDEX idx_irf_user    ON irf_permissions(user_id);
CREATE INDEX idx_irf_valid   ON irf_permissions(valid_until);

COMMENT ON TABLE irf_permissions IS 'IRF is a guest audit permission overlay on an existing user. Not a standing role. See 2.6';

-- ============================================================
-- DELEGATIONS — temporary authority per section 5
-- ============================================================

CREATE TABLE delegations (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id       UUID REFERENCES tenants(id),      -- NULL = platform-level delegation
  grantor_id      UUID NOT NULL REFERENCES users(id),
  recipient_id    UUID NOT NULL REFERENCES users(id),
  permission      TEXT NOT NULL,
  starts_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ends_at         TIMESTAMPTZ NOT NULL,
  status          TEXT NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','expired','revoked_early','blocked_redundant')),
  revoked_by      UUID REFERENCES users(id),
  revoked_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- Non-delegable permissions enforced at app layer; documented here as constraint comment
  CONSTRAINT delegation_has_end    CHECK (ends_at > starts_at),
  CONSTRAINT delegation_not_self   CHECK (grantor_id <> recipient_id)
);

CREATE INDEX idx_delegations_recipient ON delegations(recipient_id, status);
CREATE INDEX idx_delegations_tenant    ON delegations(tenant_id);
CREATE INDEX idx_delegations_ends      ON delegations(ends_at) WHERE status = 'active';

COMMENT ON COLUMN delegations.permission IS
  'Non-delegable list (enforced at API layer): create_admin, audit_log_config, ai_action_boundaries per 5.1';
COMMENT ON COLUMN delegations.status     IS 'Immutable records — status updated, never deleted';

