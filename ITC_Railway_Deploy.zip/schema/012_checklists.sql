-- ============================================================
-- Migration 012 — Checklist library (Step 5b)
-- Run after 011_*. Add to 000_run_all.sql.
-- ============================================================

-- checklist_versions
-- One active version per course_type per tenant at any time.
CREATE TABLE checklist_versions (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id),
  course_type_id   UUID NOT NULL REFERENCES course_types(id),
  version_label    TEXT NOT NULL,
  effective_date   DATE NOT NULL,
  status           TEXT NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active','retired')),
  sheet_image_path TEXT NOT NULL,
  retired_at       TIMESTAMPTZ,
  retired_by       UUID REFERENCES users(id),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by       UUID NOT NULL REFERENCES users(id),
  -- Only one active version per course_type per tenant
  CONSTRAINT one_active_per_course_type
    EXCLUDE USING btree (tenant_id WITH =, course_type_id WITH =)
    WHERE (status = 'active')
);

ALTER TABLE checklist_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_versions_tenant ON checklist_versions
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- checklist_field_maps
-- Pixel positions for every field on a sheet image.
-- Populated by admin upload flow (later slice) — seeded for Step 5b.
CREATE TABLE checklist_field_maps (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  checklist_version_id UUID NOT NULL REFERENCES checklist_versions(id),
  field_key            TEXT NOT NULL,
  field_type           TEXT NOT NULL
                       CHECK (field_type IN ('checkbox','text','date','signature')),
  x                    INTEGER NOT NULL,
  y                    INTEGER NOT NULL,
  width                INTEGER,
  height               INTEGER,
  UNIQUE (checklist_version_id, field_key)
);

ALTER TABLE checklist_field_maps ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_field_maps_tenant ON checklist_field_maps
  USING (
    checklist_version_id IN (
      SELECT id FROM checklist_versions
      WHERE tenant_id = current_setting('app.tenant_id')::UUID
    )
  );

-- checklist_sessions
-- One per student per class.
CREATE TABLE checklist_sessions (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id            UUID NOT NULL REFERENCES tenants(id),
  checklist_version_id UUID NOT NULL REFERENCES checklist_versions(id),
  class_id             UUID NOT NULL REFERENCES classes(id),
  student_id           UUID NOT NULL REFERENCES users(id),
  marker_id            UUID NOT NULL REFERENCES users(id),
  marker_role          TEXT NOT NULL
                       CHECK (marker_role IN ('instructor','faculty','irf')),
  status               TEXT NOT NULL DEFAULT 'in_progress'
                       CHECK (status IN ('in_progress','signed','archived')),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (class_id, student_id)
);

ALTER TABLE checklist_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_sessions_tenant ON checklist_sessions
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- checklist_marks
-- Individual field values within a session.
CREATE TABLE checklist_marks (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  checklist_session_id UUID NOT NULL REFERENCES checklist_sessions(id),
  field_key            TEXT NOT NULL,
  value                TEXT NOT NULL,
  marked_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (checklist_session_id, field_key)
);

ALTER TABLE checklist_marks ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_marks_tenant ON checklist_marks
  USING (
    checklist_session_id IN (
      SELECT id FROM checklist_sessions
      WHERE tenant_id = current_setting('app.tenant_id')::UUID
    )
  );

-- checklist_signatures
-- On-screen signature bound to a session.
CREATE TABLE checklist_signatures (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  checklist_session_id UUID NOT NULL UNIQUE REFERENCES checklist_sessions(id),
  instructor_id        UUID NOT NULL REFERENCES users(id),
  instructor_number    TEXT NOT NULL,
  signature_data       TEXT NOT NULL,   -- base64 PNG
  signed_at            TIMESTAMPTZ NOT NULL DEFAULT now()
  -- TODO §14.6: Confirm with legal whether drawn on-screen signature carries the
  -- same evidentiary weight as a cryptographic digital signature under Pakistan's
  -- Electronic Transactions Ordinance before treating as legally equivalent.
);

ALTER TABLE checklist_signatures ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_signatures_tenant ON checklist_signatures
  USING (
    checklist_session_id IN (
      SELECT id FROM checklist_sessions
      WHERE tenant_id = current_setting('app.tenant_id')::UUID
    )
  );

-- checklist_pdfs
-- Immutable archived PDF. No UPDATE or DELETE ever permitted.
CREATE TABLE checklist_pdfs (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id            UUID NOT NULL REFERENCES tenants(id),
  checklist_session_id UUID NOT NULL UNIQUE REFERENCES checklist_sessions(id),
  student_id           UUID NOT NULL REFERENCES users(id),
  class_id             UUID NOT NULL REFERENCES classes(id),
  pdf_path             TEXT NOT NULL,
  sha256_hash          TEXT NOT NULL,
  archived_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  retain_until         DATE NOT NULL,   -- archived_at + 3 years (§14.5)
  amends_pdf_id        UUID REFERENCES checklist_pdfs(id)
);

ALTER TABLE checklist_pdfs ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_pdfs_tenant ON checklist_pdfs
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- Immutability rules — mirror pattern from audit_log
CREATE RULE no_update_checklist_pdfs AS ON UPDATE TO checklist_pdfs DO INSTEAD NOTHING;
CREATE RULE no_delete_checklist_pdfs AS ON DELETE TO checklist_pdfs DO INSTEAD NOTHING;

-- checklist_retirement_alerts
-- Tracks open alerts when a version is retired with no replacement.
CREATE TABLE checklist_retirement_alerts (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id            UUID NOT NULL REFERENCES tenants(id),
  checklist_version_id UUID NOT NULL REFERENCES checklist_versions(id),
  course_type_id       UUID NOT NULL REFERENCES course_types(id),
  alerted_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at          TIMESTAMPTZ,
  resolved_by          UUID REFERENCES users(id)
);

ALTER TABLE checklist_retirement_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY checklist_retirement_alerts_tenant ON checklist_retirement_alerts
  USING (tenant_id = current_setting('app.tenant_id')::UUID);

-- Indexes
CREATE INDEX idx_cv_tenant_course_status
  ON checklist_versions (tenant_id, course_type_id, status);
CREATE INDEX idx_cs_class_student
  ON checklist_sessions (class_id, student_id);
CREATE INDEX idx_cm_session
  ON checklist_marks (checklist_session_id);
CREATE INDEX idx_cp_student
  ON checklist_pdfs (student_id);
CREATE INDEX idx_cp_class
  ON checklist_pdfs (class_id);
CREATE INDEX idx_cp_retain
  ON checklist_pdfs (retain_until);
