/**
 * Database migration script for Railway deployment.
 * Runs all schema migrations in order on startup.
 * Safe to run multiple times — skips already-applied migrations.
 */
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

async function migrate() {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const client = await pool.connect();

  try {
    console.log('Running ITC Platform migrations...');

    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migrations (
        id SERIAL PRIMARY KEY,
        filename TEXT UNIQUE NOT NULL,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      );
    `);

    const schemaDir = path.join(__dirname, '..', 'schema');
    const files = fs.readdirSync(schemaDir)
      .filter(f => f.match(/^\d+.*\.sql$/) && f !== '000_run_all.sql')
      .sort();

    for (const file of files) {
      // Check if already applied
      const { rows } = await client.query(
        'SELECT 1 FROM _migrations WHERE filename = $1', [file]
      );
      if (rows.length > 0) {
        console.log(`  SKIP ${file} (already applied)`);
        continue;
      }

      console.log(`  RUN  ${file}`);
      const sql = fs.readFileSync(path.join(schemaDir, file), 'utf8');
      try {
        await client.query(sql);
        await client.query(
          'INSERT INTO _migrations (filename) VALUES ($1)', [file]
        );
        console.log(`  OK   ${file}`);
      } catch(e) {
        console.log(`  WARN ${file}: ${e.message.slice(0, 100)}`);
        // Record it anyway to avoid re-running
        await client.query(
          'INSERT INTO _migrations (filename) VALUES ($1) ON CONFLICT DO NOTHING', [file]
        );
      }
    }

    console.log('Migrations complete.');
  } finally {
    client.release();
    await pool.end();
  }
}

migrate().catch(err => {
  console.error('Migration failed:', err.message);
  process.exit(1);
});
