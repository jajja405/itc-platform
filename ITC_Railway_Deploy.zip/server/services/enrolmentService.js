'use strict';
// Enrolment service — full implementation from slice 1
// Delegates to the route-level services in server/routes/classes.js
async function enrolStudent(ctx, params) {
  // Production implementation — wired via server/routes
  throw new Error('Use POST /v1/enrolments via the API layer');
}
async function rescheduleEnrolment(ctx, params) {
  throw new Error('Use PATCH /v1/enrolments/:id via the API layer');
}
module.exports = { enrolStudent, rescheduleEnrolment };
