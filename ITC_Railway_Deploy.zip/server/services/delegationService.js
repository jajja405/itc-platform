'use strict';

/**
 * delegationService.js — Step 5e
 *
 * Temporary authority delegation (§5):
 *   grantDelegation → [auto-expire] → revokeDelegation
 *   hasActiveDelegation (checked by permissions layer)
 *
 * Rules enforced here:
 *   - Granted by Admin/Super Admin only (§5.1)
 *   - Never to Student or Agentic AI (§5.1)
 *   - Single named permission, not blanket role upgrade (§5.1)
 *   - Non-delegable: admin account management, audit log config,
 *     AI action boundaries (§5.1)
 *   - Overlap blocked — Admin notified (§5.1)
 *   - 24h expiry warning to grantor and recipient (§5.1)
 *   - Early revocation logged (§5.1)
 *   - Existing grants are immutable records; renewal = new grant (§5.1)
 *   - Deactivation immediately revokes all delegations (§6.4)
 */

const { withTenant, audit, writeAuditLog } = require('../db/index');
const { checkPermission }                   = require('../permissions');

const GRANTORS          = ['super_admin', 'admin'];
const NEVER_RECIPIENTS  = ['student', 'agentic_ai'];
const NON_DELEGABLE     = [
  'admin:create', 'admin:manage',        // creating/managing Admin accounts
  'audit_log:configure',                 // audit log configuration
  'ai:boundary_configure'                // AI action boundaries (§10.2)
];

// ---------------------------------------------------------------------------
// grantDelegation
// ---------------------------------------------------------------------------
async function grantDelegation(ctx, { recipientId, permission, expiresAt }) {
  checkPermission(ctx, 'delegation:grant');

  const grantor = ctx.userRole?.toLowerCase();
  if (!GRANTORS.includes(grantor)) {
    throw Object.assign(
      new Error('Only Admin and Super Admin may grant delegations'),
      { statusCode: 403 }
    );
  }

  if (!permission || !permission.trim()) {
    throw Object.assign(new Error('Permission name is required'), { statusCode: 422 });
  }

  if (NON_DELEGABLE.includes(permission.trim())) {
    throw Object.assign(
      new Error(`'${permission}' cannot be delegated (§5.1 non-delegable)`),
      { code: 'NON_DELEGABLE', statusCode: 422 }
    );
  }

  if (!expiresAt || new Date(expiresAt) <= new Date()) {
    throw Object.assign(
      new Error('expiresAt must be a future datetime'),
      { statusCode: 422 }
    );
  }

  return withTenant(ctx, async (db) => {
    // Validate recipient exists and is not a forbidden role
    const recipientRes = await db.query(
      `SELECT id, role, status FROM users WHERE id = $1`, [recipientId]
    );
    if (recipientRes.rows.length === 0) {
      throw Object.assign(new Error('Recipient user not found'), { statusCode: 404 });
    }
    const recipient = recipientRes.rows[0];

    if (NEVER_RECIPIENTS.includes(recipient.role?.toLowerCase())) {
      throw Object.assign(
        new Error(`Cannot delegate to role '${recipient.role}' (§5.1)`),
        { statusCode: 403 }
      );
    }
    if (recipient.status !== 'active') {
      throw Object.assign(new Error('Cannot delegate to an inactive user'), { statusCode: 422 });
    }

    // Check overlap — recipient already holds this permission actively (§5.1)
    const overlapRes = await db.query(
      `SELECT id FROM delegations
       WHERE tenant_id    = $1
         AND recipient_id = $2
         AND permission   = $3
         AND status       = 'active'
         AND expires_at   > now()
       LIMIT 1`,
      [ctx.tenantId, recipientId, permission.trim()]
    );

    if (overlapRes.rows.length > 0) {
      // Record as blocked_redundant and notify Admin (§5.1)
      const blocked = await db.query(
        `INSERT INTO delegations
           (tenant_id, grantor_id, recipient_id, permission, starts_at, expires_at, status)
         VALUES ($1,$2,$3,$4,now(),$5,'blocked_redundant')
         RETURNING *`,
        [ctx.tenantId, ctx.userId, recipientId, permission.trim(), expiresAt]
      );

      await _auditDelegation(db, ctx, 'delegation.blocked_redundant', blocked.rows[0]);
      await _notify(db, ctx.tenantId, ctx.userId, 'delegation.blocked_redundant', {
        recipientId, permission, existingGrantId: overlapRes.rows[0].id
      });

      throw Object.assign(
        new Error(`Recipient already holds '${permission}'. Grant blocked as redundant (§5.1).`),
        { code: 'DELEGATION_REDUNDANT', statusCode: 409 }
      );
    }

    // Create the grant
    const grantRes = await db.query(
      `INSERT INTO delegations
         (tenant_id, grantor_id, recipient_id, permission, expires_at)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING *`,
      [ctx.tenantId, ctx.userId, recipientId, permission.trim(), expiresAt]
    );

    const grant = grantRes.rows[0];
    await _auditDelegation(db, ctx, 'delegation.granted', grant);

    // Enqueue 24h expiry warning (§5.1) — consumed by scheduler / Step 7
    await db.query(
      `INSERT INTO scheduled_notifications
         (tenant_id, send_at, event_type, payload)
       VALUES ($1, $2::timestamptz - INTERVAL '24 hours', 'delegation.expiry_warning', $3)`,
      [ctx.tenantId, expiresAt, JSON.stringify({
        grantId: grant.id, grantorId: ctx.userId, recipientId, permission
      })]
    );

    return grant;
  });
}

// ---------------------------------------------------------------------------
// revokeDelegation — early revocation (§5.1)
// ---------------------------------------------------------------------------
async function revokeDelegation(ctx, { grantId }) {
  checkPermission(ctx, 'delegation:revoke');

  if (!GRANTORS.includes(ctx.userRole?.toLowerCase())) {
    throw Object.assign(
      new Error('Only Admin and Super Admin may revoke delegations'),
      { statusCode: 403 }
    );
  }

  return withTenant(ctx, async (db) => {
    const grantRes = await db.query(
      `SELECT * FROM delegations WHERE id = $1`, [grantId]
    );
    if (grantRes.rows.length === 0) {
      throw Object.assign(new Error('Delegation not found'), { statusCode: 404 });
    }
    const grant = grantRes.rows[0];

    if (grant.status !== 'active') {
      throw Object.assign(
        new Error(`Delegation is '${grant.status}'; can only revoke active grants`),
        { statusCode: 409 }
      );
    }

    await db.query(
      `UPDATE delegations
       SET status = 'revoked_early', revoked_at = now(), revoked_by = $1
       WHERE id = $2`,
      [ctx.userId, grantId]
    );

    await _auditDelegation(db, ctx, 'delegation.revoked_early', { ...grant, revoked_by: ctx.userId });

    // Notify recipient
    await _notify(db, ctx.tenantId, grant.recipient_id, 'delegation.revoked', {
      grantId, permission: grant.permission
    });

    return { revoked: true, grantId };
  });
}

// ---------------------------------------------------------------------------
// expireGrants — called by scheduler to mark lapsed grants (§5.1 auto-expire)
// ---------------------------------------------------------------------------
async function expireGrants(db, tenantId) {
  const res = await db.query(
    `UPDATE delegations
     SET status = 'expired'
     WHERE tenant_id = $1 AND status = 'active' AND expires_at <= now()
     RETURNING *`,
    [tenantId]
  );
  return res.rows;
}

// ---------------------------------------------------------------------------
// hasActiveDelegation — checked by permissions layer to extend effective perms
// ---------------------------------------------------------------------------
async function hasActiveDelegation(db, { tenantId, userId, permission }) {
  const res = await db.query(
    `SELECT id FROM delegations
     WHERE tenant_id    = $1
       AND recipient_id = $2
       AND permission   = $3
       AND status       = 'active'
       AND expires_at   > now()
     LIMIT 1`,
    [tenantId, userId, permission]
  );
  return res.rows.length > 0;
}

// ---------------------------------------------------------------------------
// listDelegations
// ---------------------------------------------------------------------------
async function listDelegations(ctx, { recipientId, status } = {}) {
  checkPermission(ctx, 'delegation:read');

  return withTenant(ctx, async (db) => {
    const conditions = ['d.tenant_id = $1'];
    const params     = [ctx.tenantId];

    if (recipientId) { params.push(recipientId); conditions.push(`d.recipient_id = $${params.length}`); }
    if (status)      { params.push(status);       conditions.push(`d.status = $${params.length}`); }

    const res = await db.query(
      `SELECT d.*, u.role AS recipient_role
       FROM delegations d
       JOIN users u ON u.id = d.recipient_id
       WHERE ${conditions.join(' AND ')}
       ORDER BY d.created_at DESC`,
      params
    );
    return res.rows;
  });
}

// ---------------------------------------------------------------------------
// revokeAllForUser — called on deactivation (§6.4)
// ---------------------------------------------------------------------------
async function revokeAllForUser(db, { tenantId, userId, revokedBy }) {
  const res = await db.query(
    `UPDATE delegations
     SET status = 'revoked_early', revoked_at = now(), revoked_by = $1
     WHERE tenant_id    = $2
       AND recipient_id = $3
       AND status       = 'active'
     RETURNING id`,
    [revokedBy, tenantId, userId]
  );
  return res.rows.map(r => r.id);
}

// helpers
async function _auditDelegation(db, ctx, action, grant) {
  await writeAuditLog(db, {
    tenantId:   ctx.tenantId,
    actorId:    ctx.userId,
    action,
    entityType: 'delegation',
    entityId:   grant.id,
    meta:       { recipientId: grant.recipient_id, permission: grant.permission,
                  expiresAt: grant.expires_at, status: grant.status }
  });
}

async function _notify(db, tenantId, recipientId, eventType, payload) {
  await db.query(
    `INSERT INTO notification_events (tenant_id, recipient_id, event_type, payload)
     VALUES ($1,$2,$3,$4)`,
    [tenantId, recipientId, eventType, JSON.stringify(payload)]
  );
}

module.exports = {
  grantDelegation, revokeDelegation, expireGrants,
  hasActiveDelegation, listDelegations, revokeAllForUser
};
