'use strict';

/**
 * notificationService.js — Step 7
 *
 * Full §17 notification system:
 *
 * enqueueNotification  — called by all other services to schedule sends
 * dispatch             — picks up pending queue entries, renders template,
 *                        respects preferences + quiet hours, sends, logs
 * scheduleReminders    — wires class reminders (72h + 24h before)
 * scheduleExpiryAlerts — wires instructor card / TCF renewal / delegation
 *                        expiry warnings at correct offsets
 * processScheduled     — called by cron; fires due scheduled_notifications
 *
 * Event catalogue (§17.2) — all 12 event types:
 *   booking.confirmed, booking.waitlist_offer
 *   class.reminder, class.rescheduled, class.cancelled
 *   card.issued
 *   instructor.card_expiry_warning, instructor.alignment_expiry_warning
 *   tcf.renewal_due
 *   delegation.expiry_warning
 *   payment.received, payment.failed
 *   subscription.charge_failed, subscription.dunning_reminder,
 *   subscription.final_warning, subscription.suspended, subscription.reactivated
 *   complaint.status_changed, complaint.assigned, complaint.escalated_to_you
 *   checklist.version_retired_no_replacement
 *   card.low_stock
 *
 * Template rules (§17.3):
 *   - Per-tenant library with branding in English and Urdu
 *   - Variables validated at save time — broken template cannot drop a booking confirmation
 *   - Platform-level compliance notices are not tenant-editable
 *
 * Preference + delivery rules (§17.4):
 *   - Transactional notices about own bookings cannot be fully disabled
 *   - Marketing always can be disabled
 *   - Quiet hours suppress non-urgent notifications (22:00–07:00 local)
 *   - Critical/cancellation events override quiet hours
 *   - Every send logged with channel, delivery status, timestamps
 */

const { writeAuditLog } = require('../db/index');
const { getAdapter }    = require('../lib/channelAdapters');

// ── Event metadata ─────────────────────────────────────────────────────────
// category: determines which preference bucket controls it
// canDisable: false = transactional (cannot be fully disabled, §17.4)
// quietHoursOverride: true = sends even during quiet hours
// channels: default channel order; SMS is reliability fallback for time-critical

const EVENT_META = {
  'booking.confirmed':                    { category: 'booking',    canDisable: false, quietOverride: false, channels: ['email','whatsapp','sms','push','in_app'] },
  'booking.waitlist_offer':               { category: 'booking',    canDisable: false, quietOverride: false, channels: ['email','sms','whatsapp','push'] },
  'class.reminder':                       { category: 'reminders',  canDisable: true,  quietOverride: false, channels: ['email','sms','whatsapp','push'] },
  'class.rescheduled':                    { category: 'booking',    canDisable: false, quietOverride: true,  channels: ['email','sms','whatsapp','push','in_app'] },
  'class.cancelled':                      { category: 'booking',    canDisable: false, quietOverride: true,  channels: ['email','sms','whatsapp','push','in_app'] },
  'card.issued':                          { category: 'cards',      canDisable: false, quietOverride: false, channels: ['email','whatsapp','sms','in_app'] },
  'instructor.card_expiry_warning':       { category: 'reminders',  canDisable: true,  quietOverride: false, channels: ['email','sms'] },
  'instructor.alignment_expiry_warning':  { category: 'reminders',  canDisable: true,  quietOverride: false, channels: ['email','sms'] },
  'tcf.renewal_due':                      { category: 'reminders',  canDisable: true,  quietOverride: false, channels: ['email','sms'] },
  'delegation.expiry_warning':            { category: 'reminders',  canDisable: true,  quietOverride: false, channels: ['email','in_app'] },
  'payment.received':                     { category: 'payments',   canDisable: false, quietOverride: false, channels: ['email','sms','in_app'] },
  'payment.failed':                       { category: 'payments',   canDisable: false, quietOverride: true,  channels: ['email','sms','whatsapp'] },
  'subscription.charge_failed':           { category: 'payments',   canDisable: false, quietOverride: true,  channels: ['email','sms'] },
  'subscription.dunning_reminder':        { category: 'payments',   canDisable: false, quietOverride: false, channels: ['email','sms'] },
  'subscription.final_warning':           { category: 'payments',   canDisable: false, quietOverride: true,  channels: ['email','sms','whatsapp'] },
  'subscription.suspended':              { category: 'payments',   canDisable: false, quietOverride: true,  channels: ['email','sms'] },
  'subscription.reactivated':            { category: 'payments',   canDisable: false, quietOverride: false, channels: ['email','in_app'] },
  'complaint.status_changed':             { category: 'complaints', canDisable: false, quietOverride: false, channels: ['email','in_app','sms'] },
  'complaint.assigned':                   { category: 'complaints', canDisable: false, quietOverride: false, channels: ['email','in_app'] },
  'complaint.escalated_to_you':           { category: 'complaints', canDisable: false, quietOverride: false, channels: ['email','in_app'] },
  'checklist.version_retired_no_replacement': { category: 'reminders', canDisable: false, quietOverride: true, channels: ['email','in_app'] },
  'card.low_stock':                       { category: 'reminders',  canDisable: false, quietOverride: false, channels: ['email','in_app'] },
};

const QUIET_START = 22;  // 22:00 local
const QUIET_END   = 7;   // 07:00 local

// ---------------------------------------------------------------------------
// enqueueNotification
// Called by all services — drops entry into notification_queue.
// Resolves which channels to use based on event meta + user preferences.
// ---------------------------------------------------------------------------
async function enqueueNotification(db, { tenantId, recipientId, eventType, payload, scheduledAt, priority }) {
  const meta = EVENT_META[eventType];
  if (!meta) {
    // Unknown event — log and skip rather than silently drop
    await writeAuditLog(db, { tenantId, actorId: null, action: 'notification.unknown_event_type',
      entityType: 'notification', entityId: null, meta: { eventType } });
    return [];
  }

  // Load user preferences
  const prefRes = await db.query(
    `SELECT * FROM notification_preferences WHERE user_id = $1 AND category = $2`,
    [recipientId, meta.category]
  );
  const prefs = prefRes.rows[0] || {};   // defaults to all-enabled if no row

  const enqueued = [];
  for (const channel of meta.channels) {
    // Transactional events (canDisable=false) always send — preference cannot block them (§17.4)
    const prefAllows = meta.canDisable ? (prefs[channel] !== false) : true;
    if (!prefAllows) continue;

    // Marketing category always respects opt-out (§17.4)
    if (meta.category === 'marketing' && prefs[channel] === false) continue;

    const res = await db.query(
      `INSERT INTO notification_queue
         (tenant_id, recipient_id, event_type, channel, payload, scheduled_at, priority)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING *`,
      [
        tenantId || null, recipientId, eventType, channel,
        JSON.stringify(payload || {}),
        scheduledAt || new Date().toISOString(),
        priority || 'normal'
      ]
    );
    enqueued.push(res.rows[0]);
  }

  return enqueued;
}

// ---------------------------------------------------------------------------
// dispatch
// Picks up pending queue entries, renders template, applies quiet hours,
// calls channel adapter, logs outcome.
// Called by scheduler (e.g. every minute).
// ---------------------------------------------------------------------------
async function dispatch(db, { batchSize = 50, adapterOverrides = {}, now = new Date() } = {}) {
  const pending = await db.query(
    `SELECT nq.*, u.timezone, u.locale AS user_locale
     FROM notification_queue nq
     JOIN users u ON u.id = nq.recipient_id
     WHERE nq.status = 'pending'
       AND nq.scheduled_at <= $1
     ORDER BY nq.priority DESC, nq.scheduled_at ASC
     LIMIT $2`,
    [now.toISOString(), batchSize]
  );

  const results = [];
  for (const entry of pending.rows) {
    const meta = EVENT_META[entry.event_type] || {};

    // Quiet hours check (§17.4) — suppresses non-urgent unless override
    if (!meta.quietOverride && _isQuietHours(now, entry.timezone)) {
      // Re-schedule to end of quiet period rather than suppress permanently
      const resume = _nextQuietEnd(now, entry.timezone);
      await db.query(
        `UPDATE notification_queue SET scheduled_at = $1 WHERE id = $2`,
        [resume.toISOString(), entry.id]
      );
      results.push({ id: entry.id, action: 'deferred_quiet_hours' });
      continue;
    }

    // Render template
    const rendered = await _renderTemplate(db, {
      tenantId:   entry.tenant_id,
      eventType:  entry.event_type,
      channel:    entry.channel,
      locale:     entry.user_locale || 'en',
      payload:    typeof entry.payload === 'string' ? JSON.parse(entry.payload) : entry.payload
    });

    // Send via channel adapter
    const adapter = getAdapter(entry.channel, adapterOverrides[entry.channel]);
    let sendResult;
    try {
      sendResult = await adapter.send({
        to:      entry.recipient_id,   // real impl resolves email/phone from user record
        subject: rendered.subject,
        body:    rendered.body
      });
    } catch (err) {
      sendResult = { status: 'failed', failureReason: err.message };
    }

    const logStatus = sendResult.status === 'sent' ? 'sent' : 'failed';

    // Mark queue entry
    await db.query(
      `UPDATE notification_queue
       SET status = $1, attempts = attempts + 1
       WHERE id = $2`,
      [logStatus, entry.id]
    );

    // Log every send (§17.4 — "I was never told" disputes are answerable)
    await db.query(
      `INSERT INTO notification_log
         (queue_entry_id, tenant_id, recipient_id, event_type, channel,
          status, provider_ref, failure_reason, sent_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [
        entry.id, entry.tenant_id, entry.recipient_id,
        entry.event_type, entry.channel, logStatus,
        sendResult.providerRef || null,
        sendResult.failureReason || null,
        logStatus === 'sent' ? now.toISOString() : null
      ]
    );

    // SMS fallback: if primary channel failed and SMS not already the channel
    if (logStatus === 'failed' && entry.channel !== 'sms' && _isTimeCritical(entry.event_type)) {
      await enqueueNotification(db, {
        tenantId:    entry.tenant_id,
        recipientId: entry.recipient_id,
        eventType:   entry.event_type,
        payload:     entry.payload,
        priority:    'high'
        // Will re-resolve channels — SMS is in the list for time-critical events
      });
    }

    results.push({ id: entry.id, channel: entry.channel, status: logStatus });
  }

  return results;
}

// ---------------------------------------------------------------------------
// scheduleReminders — class reminders at 72h and 24h before (§17.2)
// ---------------------------------------------------------------------------
async function scheduleReminders(db, { tenantId, classId, classStartsAt, studentIds, instructorIds }) {
  const scheduled = [];
  const offsets = [72, 24];   // hours before

  for (const hoursOffset of offsets) {
    const sendAt = new Date(new Date(classStartsAt).getTime() - hoursOffset * 60 * 60 * 1000);
    const recipients = [...(studentIds || []), ...(instructorIds || [])];

    for (const recipientId of recipients) {
      const res = await db.query(
        `INSERT INTO scheduled_notifications
           (tenant_id, send_at, event_type, payload)
         VALUES ($1,$2,'class.reminder',$3)
         RETURNING *`,
        [tenantId, sendAt.toISOString(), JSON.stringify({ classId, hoursOffset })]
      );
      scheduled.push(res.rows[0]);
    }
  }
  return scheduled;
}

// ---------------------------------------------------------------------------
// scheduleExpiryAlerts — instructor card / alignment / TCF / delegation (§17.2)
// ---------------------------------------------------------------------------
async function scheduleExpiryAlerts(db, { tenantId, alertType, expiryDate, recipientIds, additionalRecipients = [], payload = {} }) {
  const offsetDays = {
    'instructor.card_expiry_warning':      [90, 30, 7],
    'instructor.alignment_expiry_warning': [90, 30, 7],
    'tcf.renewal_due':                     [90, 30],
    'delegation.expiry_warning':           [1]    // 24 hours = 1 day
  };

  const days = offsetDays[alertType];
  if (!days) throw new Error(`Unknown alert type: ${alertType}`);

  const allRecipients = [...new Set([...recipientIds, ...additionalRecipients])];
  const scheduled = [];

  for (const daysOffset of days) {
    const sendAt = new Date(new Date(expiryDate).getTime() - daysOffset * 86400000);
    for (const recipientId of allRecipients) {
      const res = await db.query(
        `INSERT INTO scheduled_notifications
           (tenant_id, send_at, event_type, payload)
         VALUES ($1,$2,$3,$4)
         RETURNING *`,
        [tenantId, sendAt.toISOString(), alertType, JSON.stringify({ ...payload, daysOffset, expiryDate })]
      );
      scheduled.push(res.rows[0]);
    }
  }
  return scheduled;
}

// ---------------------------------------------------------------------------
// processScheduled — fires due scheduled_notifications (called by cron)
// ---------------------------------------------------------------------------
async function processScheduled(db, { now = new Date(), batchSize = 100 } = {}) {
  const due = await db.query(
    `SELECT * FROM scheduled_notifications
     WHERE fired = false AND send_at <= $1
     ORDER BY send_at ASC
     LIMIT $2`,
    [now.toISOString(), batchSize]
  );

  const fired = [];
  for (const item of due.rows) {
    const payload = typeof item.payload === 'string' ? JSON.parse(item.payload) : item.payload;

    // Resolve recipients from payload (each scheduled entry is per-recipient in practice,
    // but some batch entries have a recipientId in the payload)
    if (payload.recipientId) {
      await enqueueNotification(db, {
        tenantId:    item.tenant_id,
        recipientId: payload.recipientId,
        eventType:   item.event_type,
        payload
      });
    }

    await db.query(
      `UPDATE scheduled_notifications SET fired = true, fired_at = $1 WHERE id = $2`,
      [now.toISOString(), item.id]
    );

    fired.push(item.id);
  }

  return fired;
}

// ---------------------------------------------------------------------------
// saveTemplate (§17.3) — validates variables at save time
// ---------------------------------------------------------------------------
async function saveTemplate(db, ctx, { eventType, channel, locale, subject, body, variables = [] }) {
  // Validate all declared variables appear in body
  const fullTemplate = (subject || '') + ' ' + (body || '');
  const missingInBody = variables.filter(v => !fullTemplate.includes(`{{${v}}}`));
  if (missingInBody.length > 0) {
    throw Object.assign(
      new Error(`Template declares variables not found in body: ${missingInBody.join(', ')}`),
      { statusCode: 422 }
    );
  }

  // Block tenants from editing platform-level templates
  const existingRes = await db.query(
    `SELECT is_platform FROM notification_templates
     WHERE event_type = $1 AND channel = $2 AND locale = $3 AND tenant_id IS NULL`,
    [eventType, channel, locale]
  );
  if (existingRes.rows.length > 0 && existingRes.rows[0].is_platform) {
    throw Object.assign(
      new Error('Platform-level compliance templates are not tenant-editable (§17.3)'),
      { statusCode: 403 }
    );
  }

  const res = await db.query(
    `INSERT INTO notification_templates
       (tenant_id, event_type, channel, locale, subject, body, variables, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     ON CONFLICT (tenant_id, event_type, channel, locale) DO UPDATE
       SET subject = EXCLUDED.subject, body = EXCLUDED.body,
           variables = EXCLUDED.variables, updated_at = now()
     RETURNING *`,
    [ctx.tenantId, eventType, channel, locale, subject || null, body, JSON.stringify(variables), ctx.userId]
  );
  return res.rows[0];
}

// ---------------------------------------------------------------------------
// setPreferences (§17.4)
// ---------------------------------------------------------------------------
async function setPreferences(db, { userId, category, preferences }) {
  const res = await db.query(
    `INSERT INTO notification_preferences
       (user_id, category, email, sms, whatsapp, push, in_app)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (user_id, category) DO UPDATE
       SET email = EXCLUDED.email, sms = EXCLUDED.sms,
           whatsapp = EXCLUDED.whatsapp, push = EXCLUDED.push, in_app = EXCLUDED.in_app
     RETURNING *`,
    [userId, category,
     preferences.email    !== false,
     preferences.sms      !== false,
     preferences.whatsapp !== false,
     preferences.push     !== false,
     preferences.in_app   !== false]
  );
  return res.rows[0];
}

// ---------------------------------------------------------------------------
// getDeliveryHistory — answers "I was never told" disputes (§17.4)
// ---------------------------------------------------------------------------
async function getDeliveryHistory(db, { recipientId, eventType, limit = 50 }) {
  const res = await db.query(
    `SELECT * FROM notification_log
     WHERE recipient_id = $1
       AND ($2::text IS NULL OR event_type = $2)
     ORDER BY created_at DESC
     LIMIT $3`,
    [recipientId, eventType || null, limit]
  );
  return res.rows;
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------
async function _renderTemplate(db, { tenantId, eventType, channel, locale, payload }) {
  // Try tenant template first, then platform fallback
  const res = await db.query(
    `SELECT * FROM notification_templates
     WHERE event_type = $1 AND channel = $2 AND locale = $3
       AND (tenant_id = $4 OR tenant_id IS NULL)
       AND active = true
     ORDER BY tenant_id NULLS LAST
     LIMIT 1`,
    [eventType, channel, locale, tenantId]
  );

  if (res.rows.length === 0) {
    // Graceful fallback — use a minimal body so broken templates don't silently drop
    return { subject: eventType, body: JSON.stringify(payload) };
  }

  const tpl = res.rows[0];
  let body    = tpl.body;
  let subject = tpl.subject || '';

  // Replace {{variable}} placeholders with payload values
  for (const [key, value] of Object.entries(payload || {})) {
    const re = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
    body    = body.replace(re, String(value ?? ''));
    subject = subject.replace(re, String(value ?? ''));
  }

  return { subject, body };
}

function _isQuietHours(now, timezone) {
  // Simple check — in production use a proper timezone library
  const hour = now.getHours();
  return hour >= QUIET_START || hour < QUIET_END;
}

function _nextQuietEnd(now, timezone) {
  const resume = new Date(now);
  resume.setHours(QUIET_END, 0, 0, 0);
  if (resume <= now) resume.setDate(resume.getDate() + 1);
  return resume;
}

function _isTimeCritical(eventType) {
  return ['class.rescheduled','class.cancelled','payment.failed',
          'subscription.final_warning','subscription.suspended'].includes(eventType);
}

module.exports = {
  enqueueNotification, dispatch,
  scheduleReminders, scheduleExpiryAlerts, processScheduled,
  saveTemplate, setPreferences, getDeliveryHistory,
  EVENT_META
};
