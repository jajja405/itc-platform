'use strict';

/**
 * checklistService.js — Step 5b
 *
 * Business logic for the skills checklist lifecycle:
 *   getActiveChecklist → openSession → saveMark → captureSignature
 *   → flattenToPdf → [createAmendment if correction needed]
 *
 * Rules enforced here (§14):
 *   - Auto-load: instructor never selects a checklist
 *   - Block if no active version exists
 *   - Alert TCC/TCA/Admin/TSC/TSA on retirement with no replacement
 *   - IRF marks recorded as distinct type from instructor/faculty
 *   - PDF is immutable; corrections via linked amendment record
 *   - Dual attachment: student record + course file
 *   - 3-year retention minimum
 *   - Tenant-scoped library
 */

const crypto = require('crypto');
const { withTenant, audit } = require('../db/index');
const { checkPermission }   = require('../permissions');

const RETENTION_YEARS = 3;
const ALERT_ROLES     = ['super_admin', 'admin', 'tcc', 'tca', 'tsc', 'tsa'];

// Map platform role names → marker_role enum
const MARKER_ROLE_MAP = {
  instructor:       'instructor',
  lead_instructor:  'instructor',
  course_director:  'instructor',
  faculty:          'faculty',
  tcf:              'faculty',
  irf:              'irf'
};

// ---------------------------------------------------------------------------
// getActiveChecklist
// Returns active checklist version + field map for a course type.
// Throws CHECKLIST_NOT_FOUND (409) if none active — blocks testing (§14.3).
// ---------------------------------------------------------------------------
async function getActiveChecklist(ctx, courseTypeId) {
  checkPermission(ctx, 'checklist:read');

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT
         cv.*,
         COALESCE(
           json_agg(
             json_build_object(
               'field_key',  cfm.field_key,
               'field_type', cfm.field_type,
               'x', cfm.x, 'y', cfm.y,
               'width', cfm.width, 'height', cfm.height
             ) ORDER BY cfm.field_key
           ) FILTER (WHERE cfm.id IS NOT NULL),
           '[]'
         ) AS field_map
       FROM checklist_versions cv
       LEFT JOIN checklist_field_maps cfm ON cfm.checklist_version_id = cv.id
       WHERE cv.course_type_id = $1
         AND cv.status = 'active'
       GROUP BY cv.id`,
      [courseTypeId]
    );

    if (res.rows.length === 0) {
      const err = new Error(
        `No active checklist for course type ${courseTypeId}. ` +
        `Testing is blocked until a replacement checklist is uploaded and mapped.`
      );
      err.code       = 'CHECKLIST_NOT_FOUND';
      err.statusCode = 409;
      throw err;
    }

    return res.rows[0];
  });
}

// ---------------------------------------------------------------------------
// retireVersion
// Retires a checklist version.
// - If no other active version exists for that course type, inserts a
//   retirement alert and notifies responsible roles.
// - Does NOT block the retirement — alert is informational, but testing
//   will block via getActiveChecklist until replacement is activated.
// ---------------------------------------------------------------------------
async function retireVersion(ctx, versionId) {
  checkPermission(ctx, 'checklist:manage');

  return withTenant(ctx, async (db) => {
    const vRes = await db.query(
      `SELECT * FROM checklist_versions WHERE id = $1`,
      [versionId]
    );
    if (vRes.rows.length === 0) throw Object.assign(
      new Error('Checklist version not found'), { statusCode: 404 }
    );
    const version = vRes.rows[0];

    if (version.status === 'retired') throw Object.assign(
      new Error('Version is already retired'), { statusCode: 409 }
    );

    // Check for another active version (a replacement already in place)
    const replRes = await db.query(
      `SELECT id FROM checklist_versions
       WHERE course_type_id = $1 AND status = 'active' AND id != $2
       LIMIT 1`,
      [version.course_type_id, versionId]
    );
    const hasReplacement = replRes.rows.length > 0;

    // Retire
    await db.query(
      `UPDATE checklist_versions
       SET status = 'retired', retired_at = now(), retired_by = $1
       WHERE id = $2`,
      [ctx.userId, versionId]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'checklist_version.retired',
      entityType: 'checklist_version',
      entityId:   versionId,
      meta:       { courseTypeId: version.course_type_id, hasReplacement }
    });

    if (!hasReplacement) {
      // Insert open alert
      await db.query(
        `INSERT INTO checklist_retirement_alerts
           (tenant_id, checklist_version_id, course_type_id)
         VALUES ($1, $2, $3)`,
        [ctx.tenantId, versionId, version.course_type_id]
      );

      // Enqueue notifications for responsible roles (consumed by Step 7)
      await _enqueueAlerts(db, ctx.tenantId, version.course_type_id, versionId);
    }

    return { retired: true, replacementRequired: !hasReplacement };
  });
}

// ---------------------------------------------------------------------------
// openSession
// Opens (or resumes) a marking session for one student in a class.
// Auto-loads the active checklist — instructor never selects it (§14.2).
// ---------------------------------------------------------------------------
async function openSession(ctx, { classId, studentId }) {
  checkPermission(ctx, 'checklist:mark');

  return withTenant(ctx, async (db) => {
    // Resolve course type from class
    const classRes = await db.query(
      `SELECT course_type_id FROM classes WHERE id = $1`, [classId]
    );
    if (classRes.rows.length === 0) throw Object.assign(
      new Error('Class not found'), { statusCode: 404 }
    );
    const { course_type_id } = classRes.rows[0];

    // Auto-load — throws 409 if no active checklist
    const checklist = await getActiveChecklist(ctx, course_type_id);

    const markerRole = _resolveMarkerRole(ctx.userRole);

    const sessRes = await db.query(
      `INSERT INTO checklist_sessions
         (tenant_id, checklist_version_id, class_id, student_id, marker_id, marker_role)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (class_id, student_id) DO UPDATE
         SET updated_at = now()
       RETURNING *`,
      [ctx.tenantId, checklist.id, classId, studentId, ctx.userId, markerRole]
    );

    const session = sessRes.rows[0];

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'checklist_session.opened',
      entityType: 'checklist_session',
      entityId:   session.id,
      meta:       { classId, studentId, checklistVersionId: checklist.id, markerRole }
    });

    return { session, checklist };
  });
}

// ---------------------------------------------------------------------------
// saveMark
// Records or updates a single field mark within an in-progress session.
// ---------------------------------------------------------------------------
async function saveMark(ctx, { sessionId, fieldKey, value }) {
  checkPermission(ctx, 'checklist:mark');

  return withTenant(ctx, async (db) => {
    const session = await _requireSession(db, sessionId, ['in_progress']);

    // Validate field_key against the version's field map
    const fRes = await db.query(
      `SELECT id FROM checklist_field_maps
       WHERE checklist_version_id = $1 AND field_key = $2`,
      [session.checklist_version_id, fieldKey]
    );
    if (fRes.rows.length === 0) throw Object.assign(
      new Error(`Unknown field key: ${fieldKey}`), { statusCode: 422 }
    );

    await db.query(
      `INSERT INTO checklist_marks (checklist_session_id, field_key, value)
       VALUES ($1, $2, $3)
       ON CONFLICT (checklist_session_id, field_key)
         DO UPDATE SET value = EXCLUDED.value, marked_at = now()`,
      [sessionId, fieldKey, value]
    );

    return { sessionId, fieldKey, value };
  });
}

// ---------------------------------------------------------------------------
// captureSignature
// Stores drawn on-screen signature + AHA instructor ID, advances to 'signed'.
// ---------------------------------------------------------------------------
async function captureSignature(ctx, { sessionId, instructorNumber, signatureData }) {
  checkPermission(ctx, 'checklist:sign');

  // TODO §14.6: Confirm with legal whether a drawn on-screen signature carries
  // the same evidentiary weight as a cryptographic digital signature under
  // Pakistan's Electronic Transactions Ordinance before treating as equivalent
  // for AHA compliance purposes.

  if (!signatureData || signatureData.length < 50) throw Object.assign(
    new Error('Signature data is missing or too short'), { statusCode: 422 }
  );
  if (!instructorNumber || !instructorNumber.trim()) throw Object.assign(
    new Error('Instructor number is required'), { statusCode: 422 }
  );

  return withTenant(ctx, async (db) => {
    await _requireSession(db, sessionId, ['in_progress']);

    await db.query(
      `INSERT INTO checklist_signatures
         (checklist_session_id, instructor_id, instructor_number, signature_data)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (checklist_session_id) DO UPDATE
         SET instructor_number = EXCLUDED.instructor_number,
             signature_data    = EXCLUDED.signature_data,
             signed_at         = now()`,
      [sessionId, ctx.userId, instructorNumber.trim(), signatureData]
    );

    await db.query(
      `UPDATE checklist_sessions
       SET status = 'signed', updated_at = now()
       WHERE id = $1`,
      [sessionId]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'checklist_session.signed',
      entityType: 'checklist_session',
      entityId:   sessionId,
      meta:       { instructorNumber: instructorNumber.trim() }
    });

    return { signed: true, sessionId };
  });
}

// ---------------------------------------------------------------------------
// flattenToPdf
// Flattens marks + signature onto sheet image → immutable PDF.
// Attaches to student record AND course file (§14.4).
// Session must be 'signed'.
// ---------------------------------------------------------------------------
async function flattenToPdf(ctx, { sessionId, pdfRenderer }) {
  checkPermission(ctx, 'checklist:archive');

  return withTenant(ctx, async (db) => {
    const session = await _requireSession(db, sessionId, ['signed']);

    const [versionRes, marksRes, sigRes, fieldMapRes] = await Promise.all([
      db.query(`SELECT * FROM checklist_versions WHERE id = $1`, [session.checklist_version_id]),
      db.query(`SELECT * FROM checklist_marks   WHERE checklist_session_id = $1`, [sessionId]),
      db.query(`SELECT * FROM checklist_signatures WHERE checklist_session_id = $1`, [sessionId]),
      db.query(`SELECT * FROM checklist_field_maps WHERE checklist_version_id = $1`, [session.checklist_version_id])
    ]);

    if (sigRes.rows.length === 0) throw Object.assign(
      new Error('Cannot archive: session has not been signed'), { statusCode: 409 }
    );

    const pdfBuffer = await pdfRenderer.render({
      sheetImagePath: versionRes.rows[0].sheet_image_path,
      fieldMap:       fieldMapRes.rows,
      marks:          marksRes.rows,
      signature:      sigRes.rows[0]
    });

    const hash     = crypto.createHash('sha256').update(pdfBuffer).digest('hex');
    const filename = `${sessionId}-${hash}.pdf`;
    const pdfPath  = await pdfRenderer.store(pdfBuffer, filename);

    const retainUntil = new Date();
    retainUntil.setFullYear(retainUntil.getFullYear() + RETENTION_YEARS);

    // Insert record — attached to both student_id and class_id (§14.4)
    const pdfRes = await db.query(
      `INSERT INTO checklist_pdfs
         (tenant_id, checklist_session_id, student_id, class_id,
          pdf_path, sha256_hash, retain_until)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        ctx.tenantId, sessionId,
        session.student_id, session.class_id,
        pdfPath, hash,
        retainUntil.toISOString().slice(0, 10)
      ]
    );

    await db.query(
      `UPDATE checklist_sessions SET status = 'archived', updated_at = now() WHERE id = $1`,
      [sessionId]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'checklist_pdf.archived',
      entityType: 'checklist_pdf',
      entityId:   pdfRes.rows[0].id,
      meta: {
        sessionId,
        studentId:   session.student_id,
        classId:     session.class_id,
        sha256:      hash,
        retainUntil: retainUntil.toISOString().slice(0, 10)
      }
    });

    return pdfRes.rows[0];
  });
}

// ---------------------------------------------------------------------------
// createAmendment
// Corrections are a NEW signed record linked to the original (§14.5).
// The original PDF is never modified — both records remain on file.
// ---------------------------------------------------------------------------
async function createAmendment(ctx, { originalPdfId, sessionId, pdfRenderer }) {
  checkPermission(ctx, 'checklist:archive');

  return withTenant(ctx, async (db) => {
    const origRes = await db.query(
      `SELECT id FROM checklist_pdfs WHERE id = $1`, [originalPdfId]
    );
    if (origRes.rows.length === 0) throw Object.assign(
      new Error('Original PDF not found'), { statusCode: 404 }
    );

    const newPdf = await flattenToPdf(ctx, { sessionId, pdfRenderer });

    // Link amendment → original (no UPDATE rule on table — use direct query)
    // Note: amends_pdf_id is the only mutable column; immutability rules block
    // changes to pdf_path and sha256_hash. Amendment link is set on INSERT here
    // by re-inserting — but since flattenToPdf already inserted, we update via
    // a special privileged path that only sets the amendment link.
    await db.query(
      `UPDATE checklist_pdfs SET amends_pdf_id = $1 WHERE id = $2`,
      [originalPdfId, newPdf.id]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'checklist_pdf.amended',
      entityType: 'checklist_pdf',
      entityId:   newPdf.id,
      meta:       { originalPdfId }
    });

    return { amendmentPdfId: newPdf.id, originalPdfId };
  });
}

// ---------------------------------------------------------------------------
// getStudentChecklists — all PDFs for a student record
// getClassChecklists   — all PDFs for a course file
// ---------------------------------------------------------------------------
async function getStudentChecklists(ctx, studentId) {
  checkPermission(ctx, 'checklist:read');
  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT cp.*, cs.marker_role, cv.version_label, cv.effective_date
       FROM checklist_pdfs cp
       JOIN checklist_sessions cs ON cs.id = cp.checklist_session_id
       JOIN checklist_versions cv ON cv.id = cs.checklist_version_id
       WHERE cp.student_id = $1
       ORDER BY cp.archived_at DESC`,
      [studentId]
    );
    return res.rows;
  });
}

async function getClassChecklists(ctx, classId) {
  checkPermission(ctx, 'checklist:read');
  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT cp.*, cs.student_id, cs.marker_role, cv.version_label
       FROM checklist_pdfs cp
       JOIN checklist_sessions cs ON cs.id = cp.checklist_session_id
       JOIN checklist_versions cv ON cv.id = cs.checklist_version_id
       WHERE cp.class_id = $1
       ORDER BY cp.archived_at DESC`,
      [classId]
    );
    return res.rows;
  });
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function _resolveMarkerRole(userRole) {
  const role = MARKER_ROLE_MAP[userRole?.toLowerCase()];
  if (!role) throw Object.assign(
    new Error(`Role '${userRole}' may not mark checklists`),
    { statusCode: 403 }
  );
  return role;
}

async function _requireSession(db, sessionId, allowedStatuses) {
  const res = await db.query(
    `SELECT * FROM checklist_sessions WHERE id = $1`, [sessionId]
  );
  if (res.rows.length === 0) throw Object.assign(
    new Error('Checklist session not found'), { statusCode: 404 }
  );
  const s = res.rows[0];
  if (!allowedStatuses.includes(s.status)) throw Object.assign(
    new Error(`Session is '${s.status}'; expected: ${allowedStatuses.join(' | ')}`),
    { code: 'INVALID_SESSION_STATUS', statusCode: 409 }
  );
  return s;
}

async function _enqueueAlerts(db, tenantId, courseTypeId, versionId) {
  const usersRes = await db.query(
    `SELECT id FROM users
     WHERE tenant_id = $1 AND role = ANY($2::text[]) AND status = 'active'`,
    [tenantId, ALERT_ROLES]
  );
  for (const u of usersRes.rows) {
    await db.query(
      `INSERT INTO notification_events
         (tenant_id, recipient_id, event_type, payload)
       VALUES ($1, $2, 'checklist.version_retired_no_replacement', $3)`,
      [tenantId, u.id, JSON.stringify({ courseTypeId, retiredVersionId: versionId })]
    );
  }
}

module.exports = {
  getActiveChecklist,
  retireVersion,
  openSession,
  saveMark,
  captureSignature,
  flattenToPdf,
  createAmendment,
  getStudentChecklists,
  getClassChecklists
};
