'use strict';

/**
 * helplineService.js — Step 8
 *
 * Helpline console + Agentic AI governance (§10).
 *
 * openInteraction      — start a contact session (human or AI)
 * closeInteraction     — record outcome, transcript
 * requestHandoff       — mandatory human handoff (§10.3)
 * queueCallback        — no human available → callback commitment
 * verifyIdentity       — gate before any account-specific disclosure (§10.4)
 *
 * AI-specific:
 * logAiTurn            — append a turn to ai_interaction_log (§10.5)
 * checkAiBoundary      — enforce action boundaries in permission layer (§10.2)
 * detectPromptInjection— untrusted input check (§10.4)
 * toggleKillSwitch     — Admin kill switch (§10.4)
 * isKillSwitchActive   — checked before every AI dispatch
 *
 * Quality:
 * submitQualityReview  — weekly human review of AI sample (§10.5)
 * getQualityMetrics    — containment rate, handoff rate, etc.
 */

const { withTenant, writeAuditLog } = require('../db/index');
const { checkPermission }           = require('../permissions');
const enrolSvc                      = require('./enrolmentService');
const complaintSvc                  = require('./complaintService');

// ── AI action boundary table (§10.2) ──────────────────────────────────────
// These are the ONLY actions the AI service account may take.
// Enforced here AND in the DB permission layer (service account has no other perms).
const AI_PERMITTED_ACTIONS = new Set([
  'booking:create',        // book into published scheduled class with seats
  'booking:reschedule',    // reschedule within policy windows
  'info:calendar',         // share calendar, course, venue, pricing info
  'info:general',          // answer general questions
  'complaint:file',        // log and route complaint
  'callback:queue',        // take callback commitment
]);

// Actions the AI can NEVER take — hardcoded, not configurable
const AI_PROHIBITED_ACTIONS = new Set([
  'refund:initiate',
  'payment:adjust',
  'fee:waive',
  'booking:capacity_override',
  'booking:prerequisite_override',
  'class:create', 'class:cancel', 'class:modify',
  'account:password_change', 'account:contact_change',
  'account:role_change', 'account:permission_change',
  'complaint:resolve', 'complaint:commit_outcome',
  'medical:advice',
  'delegation:grant', 'delegation:revoke',
  'admin:create', 'audit_log:configure', 'ai:boundary_configure',
]);

// Mandatory handoff triggers (§10.3)
const HANDOFF_TRIGGERS = [
  'caller_requests_human',
  'caller_distress_or_safety',
  'payment_dispute_or_refund',
  'intent_unresolved_after_two_attempts',
  'complaint_escalation_requested',
  'identity_unverifiable',
];

// Prompt injection patterns — inputs attempting to override boundaries
const INJECTION_PATTERNS = [
  /ignore (previous|all|your) instructions/i,
  /you are now/i,
  /pretend (you are|to be)/i,
  /disregard (your|the) (rules|guidelines|boundaries)/i,
  /act as (an? )?(unrestricted|jailbroken|DAN)/i,
  /system prompt/i,
];

// ---------------------------------------------------------------------------
// openInteraction
// ---------------------------------------------------------------------------
async function openInteraction(ctx, { channel, callerId, handlerType = 'human' }) {
  checkPermission(ctx, 'helpline:interact');

  return withTenant(ctx, async (db) => {
    // Kill switch check — if active, AI must immediately hand off
    if (handlerType === 'ai') {
      const killed = await isKillSwitchActive(db, ctx.tenantId);
      if (killed) {
        throw Object.assign(
          new Error('AI kill switch is active — all traffic routed to humans (§10.4)'),
          { code: 'KILL_SWITCH_ACTIVE', statusCode: 503 }
        );
      }
    }

    const res = await db.query(
      `INSERT INTO helpline_interactions
         (tenant_id, handler_id, handler_type, channel, caller_id)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING *`,
      [ctx.tenantId, ctx.userId, handlerType, channel, callerId || null]
    );

    const interaction = res.rows[0];

    // AI must disclose itself at session start (§10.1)
    if (handlerType === 'ai') {
      await logAiTurn(db, {
        interactionId: interaction.id,
        turnIndex:     0,
        role:          'assistant',
        content:       'I am an AI assistant. How can I help you today? You may ask to speak with a human at any time.',
        actionTaken:   'disclosure',
        decisionBasis: 'Mandatory AI self-disclosure at session start (§10.1)'
      });
    }

    await writeAuditLog(db, {
      tenantId:   ctx.tenantId, actorId: ctx.userId,
      action:     'helpline.interaction_opened',
      entityType: 'helpline_interaction', entityId: interaction.id,
      meta:       { channel, handlerType, callerId }
    });

    return interaction;
  });
}

// ---------------------------------------------------------------------------
// closeInteraction
// ---------------------------------------------------------------------------
async function closeInteraction(ctx, { interactionId, outcome, handoffReason }) {
  checkPermission(ctx, 'helpline:interact');

  return withTenant(ctx, async (db) => {
    await db.query(
      `UPDATE helpline_interactions
       SET ended_at = now(), outcome = $1, handoff_reason = $2
       WHERE id = $3`,
      [outcome, handoffReason || null, interactionId]
    );

    await writeAuditLog(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action: 'helpline.interaction_closed', entityType: 'helpline_interaction',
      entityId: interactionId, meta: { outcome, handoffReason }
    });

    return { closed: true, interactionId, outcome };
  });
}

// ---------------------------------------------------------------------------
// verifyIdentity (§10.4)
// Must be called before the AI discloses any account-specific information.
// ---------------------------------------------------------------------------
async function verifyIdentity(db, { interactionId, callerId, verificationChannel, verificationCode }) {
  // Check registered channel or verification code matches
  const userRes = await db.query(
    `SELECT id, phone, email, verification_code FROM users WHERE id = $1`,
    [callerId]
  );
  if (userRes.rows.length === 0) return { verified: false, reason: 'user_not_found' };

  const user = userRes.rows[0];
  const verified =
    (verificationChannel === 'phone'  && user.phone  === verificationCode) ||
    (verificationChannel === 'email'  && user.email  === verificationCode) ||
    (verificationChannel === 'code'   && user.verification_code === verificationCode);

  await db.query(
    `UPDATE helpline_interactions SET identity_verified = $1 WHERE id = $2`,
    [verified, interactionId]
  );

  if (!verified) {
    await writeAuditLog(db, {
      tenantId: null, actorId: null,
      action: 'helpline.identity_verification_failed',
      entityType: 'helpline_interaction', entityId: interactionId,
      meta: { callerId, verificationChannel }
    });
  }

  return { verified };
}

// ---------------------------------------------------------------------------
// requestHandoff (§10.3)
// ---------------------------------------------------------------------------
async function requestHandoff(ctx, { interactionId, reason, callerContact }) {
  if (!HANDOFF_TRIGGERS.includes(reason)) {
    throw Object.assign(
      new Error(`Unknown handoff reason: ${reason}. Must be one of: ${HANDOFF_TRIGGERS.join(', ')}`),
      { statusCode: 422 }
    );
  }

  return withTenant(ctx, async (db) => {
    // Check if a human agent is available
    const agentRes = await db.query(
      `SELECT id FROM users
       WHERE tenant_id = $1 AND role = 'helpline_agent'
         AND status = 'active' AND is_online = true
       LIMIT 1`,
      [ctx.tenantId]
    );

    if (agentRes.rows.length > 0) {
      // Transfer to available agent
      await closeInteraction(ctx, { interactionId, outcome: 'handed_off', handoffReason: reason });

      await writeAuditLog(db, {
        tenantId: ctx.tenantId, actorId: ctx.userId,
        action: 'helpline.handoff_transferred',
        entityType: 'helpline_interaction', entityId: interactionId,
        meta: { reason, assignedAgent: agentRes.rows[0].id }
      });

      return { handedOff: true, assignedAgent: agentRes.rows[0].id };
    } else {
      // No human available — queue callback (§10.3)
      const callback = await queueCallback(ctx, { interactionId, callerContact, reason }, db);
      await closeInteraction(ctx, { interactionId, outcome: 'callback_queued', handoffReason: reason });
      return { handedOff: false, callbackQueued: true, callbackId: callback.id };
    }
  });
}

// ---------------------------------------------------------------------------
// queueCallback
// ---------------------------------------------------------------------------
async function queueCallback(ctx, { interactionId, callerContact, reason }, db) {
  const inner = async (db2) => {
    const interactionRes = await db2.query(
      `SELECT caller_id FROM helpline_interactions WHERE id = $1`, [interactionId]
    );
    const callerId = interactionRes.rows[0]?.caller_id;

    const res = await db2.query(
      `INSERT INTO callback_queue
         (tenant_id, caller_id, caller_contact, interaction_id, reason)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING *`,
      [ctx.tenantId, callerId || null, callerContact, interactionId, reason || null]
    );
    return res.rows[0];
  };

  return db ? inner(db) : withTenant(ctx, inner);
}

// ---------------------------------------------------------------------------
// checkAiBoundary (§10.2)
// Called before every AI action. Throws if action is prohibited.
// This is the permission-layer enforcement — not just instructions.
// ---------------------------------------------------------------------------
function checkAiBoundary(action) {
  if (AI_PROHIBITED_ACTIONS.has(action)) {
    throw Object.assign(
      new Error(`AI boundary violation: '${action}' is prohibited (§10.2). Handoff required.`),
      { code: 'AI_BOUNDARY_VIOLATION', statusCode: 403 }
    );
  }
  if (!AI_PERMITTED_ACTIONS.has(action)) {
    throw Object.assign(
      new Error(`AI boundary violation: '${action}' is not in the permitted action set (§10.2).`),
      { code: 'AI_ACTION_NOT_PERMITTED', statusCode: 403 }
    );
  }
  return true;
}

// ---------------------------------------------------------------------------
// detectPromptInjection (§10.4)
// Untrusted input cannot alter boundaries. Attempts logged as security events.
// ---------------------------------------------------------------------------
async function detectPromptInjection(db, { interactionId, turnIndex, content, tenantId }) {
  const detected = INJECTION_PATTERNS.some(p => p.test(content));

  if (detected) {
    await logAiTurn(db, {
      interactionId, turnIndex, role: 'user', content,
      actionTaken:   null,
      boundaryCheck: 'prompt_injection_attempt',
      decisionBasis: 'Input matched prompt injection pattern — boundaries unchanged (§10.4)'
    });

    await writeAuditLog(db, {
      tenantId, actorId: null,
      action:     'ai.prompt_injection_attempt',
      entityType: 'helpline_interaction', entityId: interactionId,
      meta:       { turnIndex, contentHash: _hash(content) }
    });

    return { injectionDetected: true };
  }

  return { injectionDetected: false };
}

// ---------------------------------------------------------------------------
// logAiTurn (§10.5)
// Every AI interaction logged with transcript, actions, decision basis.
// ---------------------------------------------------------------------------
async function logAiTurn(db, { interactionId, turnIndex, role, content, actionTaken, actionParams, boundaryCheck, decisionBasis }) {
  await db.query(
    `INSERT INTO ai_interaction_log
       (interaction_id, turn_index, role, content, action_taken,
        action_params, boundary_check, decision_basis)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [
      interactionId, turnIndex, role, content,
      actionTaken   || null,
      actionParams  ? JSON.stringify(actionParams) : null,
      boundaryCheck || 'permitted',
      decisionBasis || null
    ]
  );
}

// ---------------------------------------------------------------------------
// toggleKillSwitch (§10.4) — Admin only, platform-wide or per-tenant
// ---------------------------------------------------------------------------
async function toggleKillSwitch(ctx, { tenantId: targetTenantId, active, reason }) {
  checkPermission(ctx, 'ai:kill_switch');

  if (!['super_admin','admin'].includes(ctx.userRole?.toLowerCase())) {
    throw Object.assign(new Error('Only Admin may operate the kill switch (§10.4)'), { statusCode: 403 });
  }

  return withTenant(ctx, async (db) => {
    await db.query(
      `INSERT INTO ai_kill_switch (tenant_id, active, activated_by, activated_at, reason)
       VALUES ($1,$2,$3,$4,$5)
       ON CONFLICT (COALESCE(tenant_id,'00000000-0000-0000-0000-000000000000'::UUID)) DO UPDATE
         SET active        = EXCLUDED.active,
             activated_by  = CASE WHEN EXCLUDED.active THEN EXCLUDED.activated_by ELSE ai_kill_switch.activated_by END,
             activated_at  = CASE WHEN EXCLUDED.active THEN EXCLUDED.activated_at ELSE ai_kill_switch.activated_at END,
             reason        = EXCLUDED.reason,
             deactivated_by = CASE WHEN NOT EXCLUDED.active THEN $3 ELSE NULL END,
             deactivated_at = CASE WHEN NOT EXCLUDED.active THEN now() ELSE NULL END`,
      [targetTenantId || null, active, ctx.userId, new Date().toISOString(), reason || null]
    );

    await writeAuditLog(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action:   active ? 'ai.kill_switch_activated' : 'ai.kill_switch_deactivated',
      entityType: 'ai_kill_switch', entityId: null,
      meta:     { targetTenantId, reason }
    });

    return { killSwitchActive: active, tenantId: targetTenantId };
  });
}

// ---------------------------------------------------------------------------
// isKillSwitchActive
// ---------------------------------------------------------------------------
async function isKillSwitchActive(db, tenantId) {
  const res = await db.query(
    `SELECT active FROM ai_kill_switch
     WHERE (tenant_id = $1 OR tenant_id IS NULL)
       AND active = true
     LIMIT 1`,
    [tenantId]
  );
  return res.rows.length > 0;
}

// ---------------------------------------------------------------------------
// submitQualityReview (§10.5 — weekly human review)
// ---------------------------------------------------------------------------
async function submitQualityReview(ctx, { interactionId, weekOf, accuracy, boundaryCompliance, handoffCorrectness, tone, notes }) {
  checkPermission(ctx, 'ai:quality_review');

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `INSERT INTO ai_quality_reviews
         (interaction_id, reviewer_id, week_of, accuracy, boundary_compliance,
          handoff_correctness, tone, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [interactionId, ctx.userId, weekOf, accuracy, boundaryCompliance, handoffCorrectness, tone, notes || null]
    );
    return res.rows[0];
  });
}

// ---------------------------------------------------------------------------
// getQualityMetrics (§10.5 — containment, handoff, error rates)
// ---------------------------------------------------------------------------
async function getQualityMetrics(ctx, { fromDate, toDate } = {}) {
  checkPermission(ctx, 'ai:quality_review');

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT
         COUNT(*)                                              AS total_interactions,
         COUNT(*) FILTER (WHERE outcome = 'resolved')         AS resolved,
         COUNT(*) FILTER (WHERE outcome IN ('handed_off','callback_queued')) AS handed_off,
         COUNT(*) FILTER (WHERE outcome = 'callback_queued')  AS callbacks,
         ROUND(
           COUNT(*) FILTER (WHERE outcome = 'resolved')::numeric
           / NULLIF(COUNT(*),0) * 100, 1
         )                                                     AS containment_rate_pct,
         COUNT(*) FILTER (WHERE handler_type = 'ai')          AS ai_handled,
         COUNT(*) FILTER (WHERE handler_type = 'human')       AS human_handled
       FROM helpline_interactions
       WHERE tenant_id = $1
         AND ($2::date IS NULL OR started_at::date >= $2)
         AND ($3::date IS NULL OR started_at::date <= $3)
         AND handler_type = 'ai'`,
      [ctx.tenantId, fromDate || null, toDate || null]
    );

    const handoffReasonsRes = await db.query(
      `SELECT handoff_reason, COUNT(*) AS count
       FROM helpline_interactions
       WHERE tenant_id = $1
         AND handler_type = 'ai'
         AND outcome IN ('handed_off','callback_queued')
         AND ($2::date IS NULL OR started_at::date >= $2)
       GROUP BY handoff_reason
       ORDER BY count DESC`,
      [ctx.tenantId, fromDate || null]
    );

    return {
      ...res.rows[0],
      handoffReasons: handoffReasonsRes.rows
    };
  });
}

// ---------------------------------------------------------------------------
// executeAiAction — runs a permitted AI action against the real services
// This is the single choke point: boundary check → execute → log
// ---------------------------------------------------------------------------
async function executeAiAction(ctx, db, { interactionId, turnIndex, action, params }) {
  // 1. Enforce boundary (throws on prohibited/unknown)
  checkAiBoundary(action);

  let result;
  let decisionBasis;

  switch (action) {
    case 'booking:create':
      result = await enrolSvc.enrolStudent(ctx, params);
      decisionBasis = `AI booked student ${params.studentId} into class ${params.classId}`;
      break;

    case 'booking:reschedule':
      result = await enrolSvc.rescheduleEnrolment(ctx, params);
      decisionBasis = `AI rescheduled enrolment ${params.enrolmentId} to class ${params.newClassId}`;
      break;

    case 'complaint:file':
      result = await complaintSvc.fileComplaint(ctx, { ...params, filedVia: 'agentic_ai' });
      decisionBasis = `AI logged complaint, routed per §3.6`;
      break;

    case 'info:calendar':
    case 'info:general':
      // Info actions don't call a service — they return pre-fetched data
      result = params;
      decisionBasis = `AI shared information: ${action}`;
      break;

    case 'callback:queue':
      result = await queueCallback(ctx, params, db);
      decisionBasis = `AI queued callback for caller`;
      break;

    default:
      // Should never reach here — checkAiBoundary would have thrown
      throw new Error(`Unhandled permitted action: ${action}`);
  }

  // 2. Log every action with decision basis (§10.5)
  await logAiTurn(db, {
    interactionId, turnIndex,
    role:          'assistant',
    content:       `[action: ${action}]`,
    actionTaken:   action,
    actionParams:  params,
    boundaryCheck: 'permitted',
    decisionBasis
  });

  return result;
}

// ---------------------------------------------------------------------------
// getInteractionHistory — helpline console view
// ---------------------------------------------------------------------------
async function getInteractionHistory(ctx, { fromDate, toDate, handlerType, limit = 50 } = {}) {
  checkPermission(ctx, 'helpline:read');

  return withTenant(ctx, async (db) => {
    const conditions = ['hi.tenant_id = $1'];
    const params     = [ctx.tenantId];

    if (handlerType) { params.push(handlerType); conditions.push(`hi.handler_type = $${params.length}`); }
    if (fromDate)    { params.push(fromDate);     conditions.push(`hi.started_at::date >= $${params.length}`); }
    if (toDate)      { params.push(toDate);       conditions.push(`hi.started_at::date <= $${params.length}`); }
    params.push(Math.min(limit, 500));

    const res = await db.query(
      `SELECT hi.*, u.full_name AS handler_name
       FROM helpline_interactions hi
       JOIN users u ON u.id = hi.handler_id
       WHERE ${conditions.join(' AND ')}
       ORDER BY hi.started_at DESC
       LIMIT $${params.length}`,
      params
    );
    return res.rows;
  });
}

// Internal
function _hash(str) {
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(str).digest('hex').slice(0, 16);
}

module.exports = {
  openInteraction, closeInteraction, verifyIdentity,
  requestHandoff, queueCallback,
  checkAiBoundary, detectPromptInjection, logAiTurn,
  toggleKillSwitch, isKillSwitchActive,
  executeAiAction,
  submitQualityReview, getQualityMetrics,
  getInteractionHistory,
  AI_PERMITTED_ACTIONS, AI_PROHIBITED_ACTIONS, HANDOFF_TRIGGERS
};
