'use strict';

/**
 * cardService.js — Step 5c
 *
 * Card inventory lifecycle (§15):
 *   recordIntake → allocate → issueCard → revokeCard / voidCard
 *
 * Public verification (§2.9):
 *   verifyCard — unauthenticated, logs every lookup
 *
 * Reconciliation report (§15.2):
 *   getReconciliationReport
 *
 * Permission rules from §4:
 *   Super Admin, Admin, TCC, TCA   → issue cards unconditionally
 *   Instructor                      → issue only if allocation stock available
 *   Lead Instructor                 → verifies only (no issuance)
 *   Faculty, TSC, TSA, others       → no issuance
 */

const { withTenant, audit } = require('../db/index');
const { checkPermission }   = require('../permissions');

// Roles that may issue cards unconditionally
const UNCONDITIONAL_ISSUERS = ['super_admin', 'admin', 'tcc', 'tca'];
// Roles that may issue only if they hold allocated stock
const CONDITIONAL_ISSUERS   = ['instructor', 'lead_instructor'];

// ---------------------------------------------------------------------------
// recordIntake
// TCC records a batch of stock received from AHA (§15.1 Intake).
// ---------------------------------------------------------------------------
async function recordIntake(ctx, { courseTypeId, stockType, batchReference, quantity, receivedDate, notes }) {
  checkPermission(ctx, 'card:intake');

  if (!['physical', 'ecard'].includes(stockType)) {
    throw Object.assign(new Error('stockType must be physical or ecard'), { statusCode: 422 });
  }
  if (!Number.isInteger(quantity) || quantity <= 0) {
    throw Object.assign(new Error('quantity must be a positive integer'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `INSERT INTO card_stock_batches
         (tenant_id, course_type_id, stock_type, batch_reference, quantity, received_date, received_by, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [ctx.tenantId, courseTypeId, stockType, batchReference, quantity, receivedDate, ctx.userId, notes || null]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'card_stock.intake_recorded',
      entityType: 'card_stock_batch',
      entityId:   res.rows[0].id,
      meta:       { courseTypeId, stockType, quantity, batchReference }
    });

    return res.rows[0];
  });
}

// ---------------------------------------------------------------------------
// allocate
// TCC or TCA allocates stock to a site or named instructor (§15.1 Allocation).
// Validates that the batch has enough remaining stock.
// ---------------------------------------------------------------------------
async function allocate(ctx, { batchId, allocatedToUser, allocatedToSite, quantity }) {
  checkPermission(ctx, 'card:allocate');

  if (!allocatedToUser && !allocatedToSite) {
    throw Object.assign(new Error('Must specify allocatedToUser or allocatedToSite'), { statusCode: 422 });
  }
  if (!Number.isInteger(quantity) || quantity <= 0) {
    throw Object.assign(new Error('quantity must be a positive integer'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    // Check available stock in batch
    const available = await _availableInBatch(db, batchId);
    if (available < quantity) {
      throw Object.assign(
        new Error(`Insufficient stock: ${available} available, ${quantity} requested`),
        { code: 'INSUFFICIENT_STOCK', statusCode: 409 }
      );
    }

    const res = await db.query(
      `INSERT INTO card_allocations
         (tenant_id, batch_id, allocated_to_user, allocated_to_site, quantity, allocated_by)
       VALUES ($1,$2,$3,$4,$5,$6)
       RETURNING *`,
      [ctx.tenantId, batchId, allocatedToUser || null, allocatedToSite || null, quantity, ctx.userId]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'card_stock.allocated',
      entityType: 'card_allocation',
      entityId:   res.rows[0].id,
      meta:       { batchId, allocatedToUser, allocatedToSite, quantity }
    });

    // Check low-stock threshold after allocation
    await _checkLowStock(db, ctx, batchId);

    return res.rows[0];
  });
}

// ---------------------------------------------------------------------------
// issueCard
// Issues a course completion card to a student (§15.1 Issuance).
//
// Permission rules (§4):
//   - Unconditional issuers: super_admin, admin, tcc, tca
//   - Conditional issuers (instructor, lead_instructor): must have
//     an allocation with remaining stock
//   - All others: blocked
//
// Decrements the issuer's allocation automatically.
// Links card to student, class, and completion record (checklist PDF).
// ---------------------------------------------------------------------------
async function issueCard(ctx, { studentId, classId, courseTypeId, stockType, checklistPdfId, expiryDate }) {
  checkPermission(ctx, 'card:issue');

  const role = ctx.userRole?.toLowerCase();
  const isUnconditional = UNCONDITIONAL_ISSUERS.includes(role);
  const isConditional   = CONDITIONAL_ISSUERS.includes(role);

  if (!isUnconditional && !isConditional) {
    throw Object.assign(
      new Error(`Role '${ctx.userRole}' may not issue cards`),
      { statusCode: 403 }
    );
  }

  return withTenant(ctx, async (db) => {
    let batchId = null;
    let allocationId = null;

    if (isConditional) {
      // Must find an allocation belonging to this instructor with remaining stock
      const allocRes = await db.query(
        `SELECT ca.id, ca.batch_id,
                ca.quantity - COALESCE(
                  (SELECT COUNT(*) FROM issued_cards ic
                   WHERE ic.allocation_id = ca.id AND ic.status != 'voided'),
                  0
                ) AS remaining
         FROM card_allocations ca
         JOIN card_stock_batches csb ON csb.id = ca.batch_id
         WHERE ca.allocated_to_user = $1
           AND csb.course_type_id   = $2
           AND csb.stock_type       = $3
           AND csb.tenant_id        = $4
         ORDER BY ca.allocated_at ASC`,
        [ctx.userId, courseTypeId, stockType, ctx.tenantId]
      );

      const allocation = allocRes.rows.find(r => r.remaining > 0);
      if (!allocation) {
        throw Object.assign(
          new Error('No card stock available. Issuance blocked until TCC allocates more stock.'),
          { code: 'NO_STOCK', statusCode: 409 }
        );
      }
      batchId      = allocation.batch_id;
      allocationId = allocation.id;
    } else {
      // Unconditional issuers — find any batch with stock for this course/type
      const batchRes = await db.query(
        `SELECT csb.id AS batch_id,
                csb.quantity - COALESCE(
                  (SELECT COUNT(*) FROM issued_cards ic
                   WHERE ic.batch_id = csb.id AND ic.status != 'voided'),
                  0
                ) AS remaining
         FROM card_stock_batches csb
         WHERE csb.tenant_id      = $1
           AND csb.course_type_id = $2
           AND csb.stock_type     = $3
         ORDER BY csb.received_date ASC`,
        [ctx.tenantId, courseTypeId, stockType]
      );
      const batch = batchRes.rows.find(r => r.remaining > 0);
      if (!batch) {
        throw Object.assign(
          new Error('No card stock available for this course type.'),
          { code: 'NO_STOCK', statusCode: 409 }
        );
      }
      batchId = batch.batch_id;
    }

    // Issue the card
    const cardRes = await db.query(
      `INSERT INTO issued_cards
         (tenant_id, student_id, class_id, course_type_id,
          checklist_pdf_id, stock_type, batch_id, allocation_id,
          issued_by, expiry_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`,
      [
        ctx.tenantId, studentId, classId, courseTypeId,
        checklistPdfId || null, stockType, batchId, allocationId || null,
        ctx.userId, expiryDate
      ]
    );

    const card = cardRes.rows[0];

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'card.issued',
      entityType: 'issued_card',
      entityId:   card.id,
      meta:       { studentId, classId, courseTypeId, stockType, verificationCode: card.verification_code }
    });

    // Enqueue issued notification (consumed by Step 7)
    await db.query(
      `INSERT INTO notification_events (tenant_id, recipient_id, event_type, payload)
       VALUES ($1,$2,'card.issued',$3)`,
      [ctx.tenantId, studentId, JSON.stringify({
        cardId: card.id,
        verificationCode: card.verification_code,
        expiryDate
      })]
    );

    // Check low-stock after issuance
    await _checkLowStockByBatch(db, ctx, batchId, courseTypeId, stockType);

    return card;
  });
}

// ---------------------------------------------------------------------------
// revokeCard
// Revokes a card — immediately shows as invalid on verification page (§15.1).
// ---------------------------------------------------------------------------
async function revokeCard(ctx, { cardId, reason }) {
  checkPermission(ctx, 'card:revoke');

  if (!reason || !reason.trim()) {
    throw Object.assign(new Error('Revocation reason is required'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    const card = await _requireCard(db, cardId, ['valid']);

    await db.query(
      `UPDATE issued_cards
       SET status = 'revoked', revoked_at = now(), revoked_by = $1, revocation_reason = $2
       WHERE id = $3`,
      [ctx.userId, reason.trim(), cardId]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'card.revoked',
      entityType: 'issued_card',
      entityId:   cardId,
      meta:       { reason: reason.trim(), studentId: card.student_id }
    });

    return { revoked: true, cardId };
  });
}

// ---------------------------------------------------------------------------
// voidCard
// Records a spoiled or lost card (§15.1 Voids and revocations).
// ---------------------------------------------------------------------------
async function voidCard(ctx, { cardId, reason }) {
  checkPermission(ctx, 'card:void');

  if (!reason || !reason.trim()) {
    throw Object.assign(new Error('Void reason is required'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    await _requireCard(db, cardId, ['valid']);

    await db.query(
      `UPDATE issued_cards
       SET status = 'revoked', voided_at = now(), voided_by = $1, void_reason = $2
       WHERE id = $3`,
      [ctx.userId, reason.trim(), cardId]
    );

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'card.voided',
      entityType: 'issued_card',
      entityId:   cardId,
      meta:       { reason: reason.trim() }
    });

    return { voided: true, cardId };
  });
}

// ---------------------------------------------------------------------------
// verifyCard — PUBLIC, unauthenticated (§2.9)
// Returns only: student name, course, issue date, expiry date, issuing
// centre, and current validity. Nothing else is exposed.
// Every lookup is logged.
// ---------------------------------------------------------------------------
async function verifyCard(db, { verificationCode, requesterIp }) {
  // No checkPermission — this is intentionally public

  // Look up the card (no RLS needed — verification_code is a public token)
  const cardRes = await db.query(
    `SELECT
       ic.verification_code,
       ic.issued_at,
       ic.expiry_date,
       ic.status,
       ic.revoked_at,
       u.full_name    AS student_name,
       ct.name        AS course_name,
       t.name         AS issuing_centre
     FROM issued_cards ic
     JOIN users        u  ON u.id  = ic.student_id
     JOIN course_types ct ON ct.id = ic.course_type_id
     JOIN tenants      t  ON t.id  = ic.tenant_id
     WHERE ic.verification_code = $1`,
    [verificationCode]
  );

  // Compute live expiry status
  let result;
  if (cardRes.rows.length === 0) {
    result = 'not_found';
  } else {
    const card = cardRes.rows[0];
    if (card.status === 'revoked') {
      result = 'revoked';
    } else if (new Date(card.expiry_date) < new Date()) {
      result = 'expired';
    } else {
      result = 'valid';
    }
  }

  // Log every lookup (§2.9)
  await db.query(
    `INSERT INTO card_verification_log (verification_code, requester_ip, result)
     VALUES ($1,$2,$3)`,
    [verificationCode, requesterIp || null, result]
  );

  if (result === 'not_found') {
    return { valid: false, status: 'not_found' };
  }

  const card = cardRes.rows[0];

  // Return ONLY the fields §2.9 permits — nothing else
  return {
    valid:          result === 'valid',
    status:         result,
    studentName:    card.student_name,
    course:         card.course_name,
    issuedAt:       card.issued_at,
    expiryDate:     card.expiry_date,
    issuingCentre:  card.issuing_centre
  };
}

// ---------------------------------------------------------------------------
// getReconciliationReport (§15.2)
// Cards received vs allocated vs issued vs voided vs remaining,
// per discipline, per site, per instructor.
// Flags: card issued without completion record, completion without card.
// ---------------------------------------------------------------------------
async function getReconciliationReport(ctx, { courseTypeId } = {}) {
  checkPermission(ctx, 'card:reconcile');

  return withTenant(ctx, async (db) => {
    const params = [ctx.tenantId];
    const courseFilter = courseTypeId ? 'AND csb.course_type_id = $2' : '';
    if (courseTypeId) params.push(courseTypeId);

    const res = await db.query(
      `SELECT
         csb.id           AS batch_id,
         csb.batch_reference,
         csb.stock_type,
         ct.name          AS course_name,
         csb.quantity     AS received,
         COALESCE(SUM(ca.quantity), 0)                         AS allocated,
         COALESCE(
           (SELECT COUNT(*) FROM issued_cards ic
            WHERE ic.batch_id = csb.id AND ic.status = 'valid'),
           0
         )                                                      AS issued,
         COALESCE(
           (SELECT COUNT(*) FROM issued_cards ic
            WHERE ic.batch_id = csb.id AND ic.voided_at IS NOT NULL),
           0
         )                                                      AS voided,
         csb.quantity
           - COALESCE(SUM(ca.quantity), 0)                     AS unallocated
       FROM card_stock_batches csb
       JOIN course_types ct ON ct.id = csb.course_type_id
       LEFT JOIN card_allocations ca ON ca.batch_id = csb.id
       WHERE csb.tenant_id = $1 ${courseFilter}
       GROUP BY csb.id, ct.name
       ORDER BY csb.received_date DESC`,
      params
    );

    // Flag: issued cards without a linked completion record
    const missingCompletionRes = await db.query(
      `SELECT ic.id, ic.student_id, ic.class_id, ic.issued_at
       FROM issued_cards ic
       WHERE ic.tenant_id = $1
         AND ic.status    = 'valid'
         AND ic.checklist_pdf_id IS NULL`,
      [ctx.tenantId]
    );

    // Flag: checklist PDFs without an issued card (beyond configurable lag)
    const missingCardRes = await db.query(
      `SELECT cp.student_id, cp.class_id, cp.archived_at
       FROM checklist_pdfs cp
       WHERE cp.tenant_id = $1
         AND cp.archived_at < now() - INTERVAL '24 hours'
         AND NOT EXISTS (
           SELECT 1 FROM issued_cards ic
           WHERE ic.student_id = cp.student_id
             AND ic.class_id   = cp.class_id
             AND ic.status     = 'valid'
         )`,
      [ctx.tenantId]
    );

    return {
      batches:               res.rows,
      flags: {
        issuedWithoutCompletion: missingCompletionRes.rows,
        completionWithoutCard:   missingCardRes.rows
      }
    };
  });
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------
async function _availableInBatch(db, batchId) {
  const res = await db.query(
    `SELECT
       csb.quantity
         - COALESCE(SUM(ca.quantity), 0) AS available
     FROM card_stock_batches csb
     LEFT JOIN card_allocations ca ON ca.batch_id = csb.id
     WHERE csb.id = $1
     GROUP BY csb.quantity`,
    [batchId]
  );
  return res.rows.length > 0 ? parseInt(res.rows[0].available, 10) : 0;
}

async function _requireCard(db, cardId, allowedStatuses) {
  const res = await db.query(
    `SELECT * FROM issued_cards WHERE id = $1`, [cardId]
  );
  if (res.rows.length === 0) throw Object.assign(
    new Error('Card not found'), { statusCode: 404 }
  );
  const card = res.rows[0];
  if (!allowedStatuses.includes(card.status)) throw Object.assign(
    new Error(`Card is '${card.status}'; expected: ${allowedStatuses.join(' | ')}`),
    { statusCode: 409 }
  );
  return card;
}

async function _checkLowStock(db, ctx, batchId) {
  const batchRes = await db.query(
    `SELECT course_type_id, stock_type FROM card_stock_batches WHERE id = $1`, [batchId]
  );
  if (!batchRes.rows.length) return;
  const { course_type_id, stock_type } = batchRes.rows[0];
  return _checkLowStockByBatch(db, ctx, batchId, course_type_id, stock_type);
}

async function _checkLowStockByBatch(db, ctx, batchId, courseTypeId, stockType) {
  const threshRes = await db.query(
    `SELECT threshold FROM card_low_stock_thresholds
     WHERE tenant_id = $1 AND course_type_id = $2 AND stock_type = $3`,
    [ctx.tenantId, courseTypeId, stockType]
  );
  const threshold = threshRes.rows.length > 0 ? threshRes.rows[0].threshold : 10;

  const totalRes = await db.query(
    `SELECT
       COALESCE(SUM(csb.quantity), 0)
         - COALESCE(
             (SELECT COUNT(*) FROM issued_cards ic
              WHERE ic.batch_id = csb.id AND ic.status != 'voided'),
             0
           ) AS remaining
     FROM card_stock_batches csb
     WHERE csb.tenant_id = $1 AND csb.course_type_id = $2 AND csb.stock_type = $3`,
    [ctx.tenantId, courseTypeId, stockType]
  );

  const remaining = parseInt(totalRes.rows[0]?.remaining || 0, 10);
  if (remaining <= threshold) {
    // Notify TCC (event consumed by Step 7)
    const tccRes = await db.query(
      `SELECT id FROM users WHERE tenant_id = $1 AND role = 'tcc' AND status = 'active'`,
      [ctx.tenantId]
    );
    for (const u of tccRes.rows) {
      await db.query(
        `INSERT INTO notification_events (tenant_id, recipient_id, event_type, payload)
         VALUES ($1,$2,'card.low_stock',$3)`,
        [ctx.tenantId, u.id, JSON.stringify({ courseTypeId, stockType, remaining, threshold })]
      );
    }
  }
}

module.exports = {
  recordIntake,
  allocate,
  issueCard,
  revokeCard,
  voidCard,
  verifyCard,
  getReconciliationReport
};
