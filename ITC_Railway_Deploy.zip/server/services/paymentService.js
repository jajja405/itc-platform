'use strict';

/**
 * paymentService.js — Step 6
 *
 * Gateway payments, refunds, disputes, dunning, ledger entries,
 * and daily reconciliation (§12, §13).
 *
 * Core rules:
 *  - No raw card/bank credentials stored anywhere (§8.2 PCI-DSS)
 *  - Idempotency key on every mutating call (§11.2)
 *  - Refunds always to original gateway (§12.1)
 *  - Out-of-policy refunds need TCC approval + reason (§12.1)
 *  - Cash alternatives need Accountant sign-off (§12.1)
 *  - Agentic AI never initiates refunds (§10.2) — enforced in permissions
 *  - Dunning: day 0→3→7→14 (§12.3)
 *  - Reconciliation exceptions open automatically (§12.5)
 *  - Two separate ledgers: course_fee_ledger, subscription_ledger (§13.2)
 */

const { v4: uuid }       = require('uuid');
const { withTenant, writeAuditLog } = require('../db/index');
const { checkPermission }           = require('../permissions');
const { getConnector }              = require('../lib/gateways/gatewayConnector');

// Roles that may initiate refunds (§12.1: TCC or TCA)
const REFUND_INITIATORS  = ['super_admin','admin','tcc','tca'];
// Out-of-policy needs TCC-level approval
const REFUND_APPROVERS   = ['super_admin','admin','tcc'];

// ---------------------------------------------------------------------------
// initiatePayment
// ---------------------------------------------------------------------------
async function initiatePayment(ctx, { gateway, amount, currency = 'PKR', payerId, enrolmentId, idempotencyKey, metadata = {} }) {
  checkPermission(ctx, 'payment:initiate');

  if (!idempotencyKey) {
    throw Object.assign(new Error('idempotencyKey is required (§11.2)'), { statusCode: 422 });
  }
  if (!amount || amount <= 0) {
    throw Object.assign(new Error('amount must be positive'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    // Idempotency check — return existing if already processed
    const existing = await db.query(
      `SELECT * FROM gateway_transactions WHERE idempotency_key = $1`, [idempotencyKey]
    );
    if (existing.rows.length > 0) return existing.rows[0];

    const connector = getConnector(gateway);
    const gwResult  = await connector.initiate({ amount, currency, payerId, idempotencyKey, metadata });

    const txn = await db.query(
      `INSERT INTO gateway_transactions
         (tenant_id, gateway, gateway_ref, direction, amount, currency, status, payer_id, idempotency_key, raw_response)
       VALUES ($1,$2,$3,'charge',$4,$5,$6,$7,$8,$9)
       RETURNING *`,
      [ctx.tenantId, gateway, gwResult.gatewayRef, 'charge', amount, currency, gwResult.status, payerId || null, idempotencyKey, JSON.stringify(gwResult.raw)]
    );

    const txnRow = txn.rows[0];

    // Auto-post to course fee ledger if succeeded
    if (gwResult.status === 'succeeded') {
      await _postToCourseLedger(db, ctx, {
        entryType: 'charge', studentId: payerId, enrolmentId,
        transactionId: txnRow.id, amount, currency, description: `Payment via ${gateway}`
      });

      // Notify payer
      if (payerId) {
        await _enqueueNotif(db, ctx.tenantId, payerId, 'payment.received', { amount, currency, txnId: txnRow.id });
      }
    } else if (gwResult.status === 'failed') {
      if (payerId) {
        await _enqueueNotif(db, ctx.tenantId, payerId, 'payment.failed', { amount, currency });
      }
    }

    await writeAuditLog(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action: 'payment.initiated', entityType: 'gateway_transaction', entityId: txnRow.id,
      meta: { gateway, amount, currency, status: gwResult.status }
    });

    return txnRow;
  });
}

// ---------------------------------------------------------------------------
// initiateRefund (§12.1)
// ---------------------------------------------------------------------------
async function initiateRefund(ctx, { originalTxnId, amount, refundType = 'full', withinPolicy, reason, approvalReason }) {
  checkPermission(ctx, 'refund:initiate');

  const role = ctx.userRole?.toLowerCase();
  if (!REFUND_INITIATORS.includes(role)) {
    throw Object.assign(
      new Error('Only TCC, TCA, Admin, or Super Admin may initiate refunds (§12.1)'),
      { statusCode: 403 }
    );
  }

  if (!reason || !reason.trim()) {
    throw Object.assign(new Error('Reason is required for refunds'), { statusCode: 422 });
  }

  // Out-of-policy requires TCC-level role
  if (!withinPolicy && !REFUND_APPROVERS.includes(role)) {
    throw Object.assign(
      new Error('Out-of-policy refunds require TCC or Admin approval (§12.1)'),
      { statusCode: 403 }
    );
  }
  if (!withinPolicy && !approvalReason) {
    throw Object.assign(
      new Error('approvalReason is required for out-of-policy refunds (§12.1)'),
      { statusCode: 422 }
    );
  }

  return withTenant(ctx, async (db) => {
    const txnRes = await db.query(
      `SELECT * FROM gateway_transactions WHERE id = $1`, [originalTxnId]
    );
    if (txnRes.rows.length === 0) throw Object.assign(new Error('Transaction not found'), { statusCode: 404 });
    const origTxn = txnRes.rows[0];

    if (origTxn.status !== 'succeeded') {
      throw Object.assign(new Error(`Cannot refund a ${origTxn.status} transaction`), { statusCode: 409 });
    }

    const refundAmount = refundType === 'full' ? origTxn.amount : amount;
    if (!refundAmount || refundAmount <= 0) {
      throw Object.assign(new Error('Refund amount must be positive'), { statusCode: 422 });
    }

    const idempotencyKey = `refund_${originalTxnId}_${uuid()}`;

    // Call original gateway — refunds always to original method (§12.1)
    const connector = getConnector(origTxn.gateway);
    const gwResult  = await connector.refund({
      gatewayRef: origTxn.gateway_ref, amount: refundAmount, idempotencyKey
    });

    // Record refund gateway transaction
    const refundTxn = await db.query(
      `INSERT INTO gateway_transactions
         (tenant_id, gateway, gateway_ref, direction, amount, currency, status, idempotency_key, raw_response)
       VALUES ($1,$2,$3,'refund',$4,$5,$6,$7,$8)
       RETURNING *`,
      [ctx.tenantId, origTxn.gateway, gwResult.refundRef, refundAmount, origTxn.currency, gwResult.status, idempotencyKey, JSON.stringify(gwResult.raw)]
    );

    // Record in refunds table
    const refundRow = await db.query(
      `INSERT INTO refunds
         (tenant_id, original_txn_id, amount, currency, refund_type, within_policy,
          initiated_by, approved_by, approval_reason, gateway_ref, status, reason)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
       RETURNING *`,
      [
        ctx.tenantId, originalTxnId, refundAmount, origTxn.currency, refundType,
        withinPolicy, ctx.userId,
        (!withinPolicy ? ctx.userId : null),
        approvalReason || null,
        gwResult.refundRef,
        gwResult.status === 'succeeded' ? 'processed' : 'failed',
        reason.trim()
      ]
    );

    // Post negative entry to course fee ledger (§12.1 auto-reconcile)
    const ledgerEntry = await _postToCourseLedger(db, ctx, {
      entryType: 'refund', transactionId: refundTxn.rows[0].id,
      amount: -refundAmount, currency: origTxn.currency,
      description: `Refund (${refundType}) — ${reason.trim()}`
    });

    // Link ledger entry to refund
    await db.query(
      `UPDATE refunds SET ledger_entry_id = $1 WHERE id = $2`,
      [ledgerEntry.id, refundRow.rows[0].id]
    );

    await writeAuditLog(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action: 'refund.initiated', entityType: 'refund', entityId: refundRow.rows[0].id,
      meta: { originalTxnId, amount: refundAmount, withinPolicy, refundType }
    });

    return refundRow.rows[0];
  });
}

// ---------------------------------------------------------------------------
// handleDisputeWebhook (§12.2) — called by gateway webhook handler
// ---------------------------------------------------------------------------
async function handleDisputeWebhook(db, { tenantId, gateway, gatewayDisputeId, transactionGatewayRef, amount, currency, reasonCode, deadline }) {
  // Find the original transaction
  const txnRes = await db.query(
    `SELECT * FROM gateway_transactions WHERE gateway_ref = $1 AND gateway = $2`,
    [transactionGatewayRef, gateway]
  );
  if (txnRes.rows.length === 0) {
    // Log unknown dispute — don't silently drop
    await writeAuditLog(db, {
      tenantId, actorId: null, action: 'dispute.webhook_unmatched',
      entityType: 'dispute', entityId: null,
      meta: { gateway, gatewayDisputeId, transactionGatewayRef }
    });
    return null;
  }
  const txn = txnRes.rows[0];

  // Find Accountant to assign
  const acctRes = await db.query(
    `SELECT id FROM users WHERE tenant_id = $1 AND role = 'accountant' AND status = 'active' LIMIT 1`,
    [tenantId]
  );

  const dispute = await db.query(
    `INSERT INTO disputes
       (tenant_id, transaction_id, gateway_dispute_id, gateway, amount, currency, reason_code, deadline, assigned_to)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (gateway_dispute_id) DO NOTHING
     RETURNING *`,
    [tenantId, txn.id, gatewayDisputeId, gateway, amount, currency, reasonCode || null, deadline || null, acctRes.rows[0]?.id || null]
  );

  if (dispute.rows.length > 0) {
    await writeAuditLog(db, {
      tenantId, actorId: null, action: 'dispute.opened',
      entityType: 'dispute', entityId: dispute.rows[0].id,
      meta: { gateway, gatewayDisputeId, amount, deadline }
    });

    // Notify Accountant
    if (acctRes.rows[0]) {
      await _enqueueNotif(db, tenantId, acctRes.rows[0].id, 'dispute.assigned', { disputeId: dispute.rows[0].id });
    }
  }

  return dispute.rows[0] || null;
}

// ---------------------------------------------------------------------------
// runDunningStep (§12.3) — called by scheduler at day 0, 3, 7, 14
// ---------------------------------------------------------------------------
async function runDunningStep(db, { tenantId, subscriptionId, dayOffset, gatewayConnectorOverride }) {
  const sub = await db.query(
    `SELECT * FROM tenant_subscriptions WHERE tenant_id = $1`, [tenantId]
  );
  if (!sub.rows.length) return null;
  const subscription = sub.rows[0];

  // Get billing contact
  const contactRes = await db.query(
    `SELECT id FROM users WHERE tenant_id = $1 AND role IN ('admin','tcc') AND status = 'active' LIMIT 1`,
    [tenantId]
  );
  const billingContactId = contactRes.rows[0]?.id;

  if (dayOffset === 14) {
    // Suspend tenant (§12.3 — data preserved, calendar hidden)
    await db.query(
      `UPDATE tenants SET status = 'suspended', updated_at = now() WHERE id = $1`, [tenantId]
    );
    await db.query(
      `UPDATE tenant_subscriptions SET status = 'suspended', updated_at = now() WHERE tenant_id = $1`, [tenantId]
    );
    await _recordDunning(db, tenantId, dayOffset, 'suspended', null, 'Tenant suspended for non-payment');

    if (billingContactId) {
      await _enqueueNotif(db, tenantId, billingContactId, 'subscription.suspended', { dayOffset });
    }
    return { action: 'suspended' };
  }

  // Days 0, 3, 7 — retry charge
  const eventType = dayOffset === 0 ? 'charge_failed' : 'retry';
  const connector  = getConnector(subscription.gateway || 'stripe', gatewayConnectorOverride);
  let chargeResult;

  try {
    chargeResult = await connector.initiate({
      amount: subscription.rate_pkr, currency: 'PKR',
      idempotencyKey: `dunning_${tenantId}_day${dayOffset}_${Date.now()}`
    });
  } catch (err) {
    chargeResult = { status: 'failed', gatewayRef: null, raw: { error: err.message } };
  }

  const txnRow = await db.query(
    `INSERT INTO gateway_transactions
       (tenant_id, gateway, gateway_ref, direction, amount, currency, status, idempotency_key)
     VALUES ($1,$2,$3,'charge',$4,'PKR',$5,$6)
     RETURNING *`,
    [
      tenantId, subscription.gateway || 'stripe',
      chargeResult.gatewayRef || `failed_${Date.now()}`,
      subscription.rate_pkr, chargeResult.status,
      `dunning_${tenantId}_${dayOffset}`
    ]
  );

  await _recordDunning(db, tenantId, dayOffset, eventType, txnRow.rows[0].id, null);

  if (chargeResult.status === 'succeeded') {
    // Reactivate immediately (§12.3 "On payment: immediate automatic reactivation")
    await db.query(
      `UPDATE tenant_subscriptions SET status = 'active', updated_at = now() WHERE tenant_id = $1`, [tenantId]
    );
    await db.query(
      `UPDATE tenants SET status = 'active', updated_at = now() WHERE id = $1`, [tenantId]
    );
    await _recordDunning(db, tenantId, dayOffset, 'reactivated', txnRow.rows[0].id, 'Payment succeeded');

    // Post to subscription ledger
    await db.query(
      `INSERT INTO subscription_ledger
         (tenant_id, entry_type, amount, currency, billing_cycle, transaction_id, recorded_by)
       VALUES ($1,'subscription_charge',$2,'PKR',$3,$4,$5)`,
      [tenantId, subscription.rate_pkr, new Date().toISOString().slice(0,7), txnRow.rows[0].id, null]
    );

    if (billingContactId) {
      await _enqueueNotif(db, tenantId, billingContactId, 'subscription.reactivated', {});
    }
    return { action: 'reactivated' };
  }

  // Still failed — notify and schedule next step
  const notifType = dayOffset === 0 ? 'subscription.charge_failed' :
                    dayOffset === 3 ? 'subscription.dunning_reminder' :
                    'subscription.final_warning';
  if (billingContactId) {
    await _enqueueNotif(db, tenantId, billingContactId, notifType, { dayOffset });
  }

  return { action: eventType, status: 'failed' };
}

// ---------------------------------------------------------------------------
// runDailyReconciliation (§12.5)
// ---------------------------------------------------------------------------
async function runDailyReconciliation(db, { tenantId, date, gatewayConnectorOverride }) {
  const fromDate = date || new Date().toISOString().slice(0,10);
  const toDate   = fromDate;
  const exceptions = [];

  // Pull settlement feed from each gateway connector
  const { GATEWAYS } = require('../lib/gateways/gatewayConnector');

  for (const gwName of GATEWAYS) {
    const connector = getConnector(gwName, gatewayConnectorOverride);
    let settlements;
    try {
      settlements = await connector.reconcile({ fromDate, toDate });
    } catch (e) {
      continue; // log separately
    }

    for (const settlement of settlements) {
      // Check we have a matching ledger entry
      const ledgerRes = await db.query(
        `SELECT cfl.* FROM course_fee_ledger cfl
         JOIN gateway_transactions gt ON gt.id = cfl.transaction_id
         WHERE gt.gateway_ref = $1 AND cfl.tenant_id = $2`,
        [settlement.gatewayRef, tenantId]
      );

      if (ledgerRes.rows.length === 0) {
        // Payment without enrolment/ledger entry
        exceptions.push(await _openException(db, tenantId, {
          exceptionType: 'payment_no_enrolment',
          amountActual: settlement.amount
        }));
      } else {
        const ledger = ledgerRes.rows[0];
        // Amount mismatch check
        if (Math.abs(Number(ledger.amount) - Number(settlement.amount)) > 0.01) {
          exceptions.push(await _openException(db, tenantId, {
            exceptionType: 'amount_mismatch',
            ledgerEntryId: ledger.id,
            amountExpected: ledger.amount,
            amountActual: settlement.amount
          }));
        } else {
          // Mark reconciled
          await db.query(
            `UPDATE course_fee_ledger SET reconciled = true, reconciled_at = now() WHERE id = $1`,
            [ledger.id]
          );
        }
      }
    }
  }

  // Check for enrolments without payment (beyond 24h)
  const unpaidRes = await db.query(
    `SELECT e.id AS enrolment_id
     FROM enrolments e
     WHERE e.tenant_id = $1
       AND e.created_at < now() - INTERVAL '24 hours'
       AND NOT EXISTS (
         SELECT 1 FROM course_fee_ledger cfl
         WHERE cfl.enrolment_id = e.id AND cfl.entry_type = 'charge'
       )`,
    [tenantId]
  );

  for (const row of unpaidRes.rows) {
    exceptions.push(await _openException(db, tenantId, {
      exceptionType: 'enrolment_no_payment', enrolmentId: row.enrolment_id
    }));
  }

  return { date: fromDate, exceptionsOpened: exceptions.length, exceptions };
}

// ---------------------------------------------------------------------------
// setSubscriptionRate (§13.1 — Admin/Super Admin only)
// ---------------------------------------------------------------------------
async function setSubscriptionRate(ctx, { tenantId: targetTenantId, ratepkr, overrideReason }) {
  checkPermission(ctx, 'subscription:manage');

  if (!['super_admin','admin'].includes(ctx.userRole?.toLowerCase())) {
    throw Object.assign(new Error('Only Admin or Super Admin may set subscription rates (§13.1)'), { statusCode: 403 });
  }
  if (ratepkr < 0) {
    throw Object.assign(new Error('Rate must be non-negative'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    await db.query(
      `INSERT INTO tenant_subscriptions (tenant_id, rate_pkr, rate_override, override_reason)
       VALUES ($1,$2,true,$3)
       ON CONFLICT (tenant_id) DO UPDATE
         SET rate_pkr = EXCLUDED.rate_pkr, rate_override = true,
             override_reason = EXCLUDED.override_reason, updated_at = now()`,
      [targetTenantId, ratepkr, overrideReason || null]
    );

    await writeAuditLog(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action: 'subscription.rate_set', entityType: 'tenant_subscription', entityId: targetTenantId,
      meta: { ratepkr, overrideReason }
    });

    await db.query(
      `INSERT INTO subscription_ledger
         (tenant_id, entry_type, amount, currency, override_reason, recorded_by)
       VALUES ($1,'rate_override',$2,'PKR',$3,$4)`,
      [targetTenantId, ratetkr, overrideReason || null, ctx.userId]
    );

    return { updated: true, tenantId: targetTenantId, ratepkr };
  });
}

// ---------------------------------------------------------------------------
// getAgeingReport (§12.5 — month-end close needs 0 open exceptions > 30 days)
// ---------------------------------------------------------------------------
async function getAgeingReport(ctx) {
  checkPermission(ctx, 'reconciliation:read');

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT
         re.*,
         EXTRACT(DAY FROM now() - re.opened_at) AS age_days
       FROM reconciliation_exceptions re
       WHERE re.tenant_id = $1
         AND re.resolved_at IS NULL
       ORDER BY re.opened_at ASC`,
      [ctx.tenantId]
    );

    const over30 = res.rows.filter(r => r.age_days > 30);
    return {
      openExceptions:     res.rows,
      countOver30Days:    over30.length,
      monthEndCloseReady: over30.length === 0
    };
  });
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
async function _postToCourseLedger(db, ctx, { entryType, studentId, enrolmentId, transactionId, amount, currency, description }) {
  const res = await db.query(
    `INSERT INTO course_fee_ledger
       (tenant_id, entry_type, student_id, enrolment_id, transaction_id,
        amount, currency, description, recorded_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     RETURNING *`,
    [ctx.tenantId, entryType, studentId || null, enrolmentId || null, transactionId || null,
     amount, currency || 'PKR', description, ctx.userId]
  );
  return res.rows[0];
}

async function _recordDunning(db, tenantId, dayOffset, eventType, transactionId, note) {
  await db.query(
    `INSERT INTO dunning_events (tenant_id, day_offset, event_type, transaction_id, note)
     VALUES ($1,$2,$3,$4,$5)`,
    [tenantId, dayOffset, eventType, transactionId || null, note || null]
  );
}

async function _openException(db, tenantId, { exceptionType, transactionId, enrolmentId, ledgerEntryId, amountExpected, amountActual }) {
  // Find Accountant
  const acctRes = await db.query(
    `SELECT id FROM users WHERE tenant_id = $1 AND role = 'accountant' AND status = 'active' LIMIT 1`,
    [tenantId]
  );
  const res = await db.query(
    `INSERT INTO reconciliation_exceptions
       (tenant_id, exception_type, transaction_id, enrolment_id, ledger_entry_id,
        amount_expected, amount_actual, assigned_to)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     RETURNING *`,
    [tenantId, exceptionType, transactionId || null, enrolmentId || null, ledgerEntryId || null,
     amountExpected || null, amountActual || null, acctRes.rows[0]?.id || null]
  );
  return res.rows[0];
}

async function _enqueueNotif(db, tenantId, recipientId, eventType, payload) {
  await db.query(
    `INSERT INTO notification_events (tenant_id, recipient_id, event_type, payload)
     VALUES ($1,$2,$3,$4)`,
    [tenantId, recipientId, eventType, JSON.stringify(payload)]
  );
}

module.exports = {
  initiatePayment, initiateRefund,
  handleDisputeWebhook, runDunningStep,
  runDailyReconciliation, setSubscriptionRate,
  getAgeingReport
};
