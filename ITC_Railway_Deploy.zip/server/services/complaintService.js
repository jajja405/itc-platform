'use strict';

/**
 * complaintService.js — Step 5d
 *
 * Complaint lifecycle (§3.6, §18.1):
 *   fileComplaint → [auto-route] → acknowledge → addComment
 *   → resolve | escalate → close
 *
 * Permission rules (§4):
 *   File:    Student (own), Helpline Agent, Agentic AI, any handler
 *   Route:   Automatic on filing — centre → TCC, site → TSC/TSA
 *   Resolve: Super Admin, Admin, TCC/TCA (centre-level)
 *            TSC/TSA (site-level only)
 *   Log+Route only: Helpline Agent, Agentic AI (never resolve)
 *
 * Response targets (§18.1):
 *   Acknowledge ≤ 2 working days
 *   Resolve or escalate ≤ 10 working days
 */

const { withTenant, audit } = require('../db/index');
const { checkPermission }   = require('../permissions');

// Roles that may resolve complaints
const CENTRE_RESOLVERS = ['super_admin', 'admin', 'tcc', 'tca'];
const SITE_RESOLVERS   = ['tsc', 'tsa'];
// Roles that may only log and route — never resolve
const LOG_ROUTE_ONLY   = ['helpline_agent', 'agentic_ai'];

// Response targets in working days (§18.1)
const ACK_DAYS     = 2;
const RESOLVE_DAYS = 10;

// ---------------------------------------------------------------------------
// fileComplaint
// Filed by student, helpline agent, or agentic AI.
// Automatically routes to TCC (centre) or TSC/TSA (site) on creation.
// ---------------------------------------------------------------------------
async function fileComplaint(ctx, {
  description, filedVia, scope, siteId, studentId, category
}) {
  checkPermission(ctx, 'complaint:file');

  if (!description || !description.trim()) {
    throw Object.assign(new Error('Complaint description is required'), { statusCode: 422 });
  }
  if (!['centre', 'site'].includes(scope)) {
    throw Object.assign(new Error("scope must be 'centre' or 'site'"), { statusCode: 422 });
  }
  if (scope === 'site' && !siteId) {
    throw Object.assign(new Error('siteId is required for site-scoped complaints'), { statusCode: 422 });
  }

  // Students may only file on their own behalf
  const role = ctx.userRole?.toLowerCase();
  if (role === 'student' && studentId && studentId !== ctx.userId) {
    throw Object.assign(new Error('Students may only file complaints on their own behalf'), { statusCode: 403 });
  }

  return withTenant(ctx, async (db) => {
    // Auto-route: find the right assignee
    const assignee = await _resolveAssignee(db, ctx.tenantId, scope, siteId);

    const res = await db.query(
      `INSERT INTO complaints
         (tenant_id, filed_by, filed_via, student_id, scope, site_id,
          assigned_to, assigned_at, description, category, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'open')
       RETURNING *`,
      [
        ctx.tenantId, ctx.userId,
        filedVia || 'student_portal',
        studentId || (role === 'student' ? ctx.userId : null),
        scope, siteId || null,
        assignee?.id || null,
        assignee ? new Date().toISOString() : null,
        description.trim(),
        category || null
      ]
    );

    const complaint = res.rows[0];

    await _recordHistory(db, {
      complaintId: complaint.id,
      fromStatus:  null,
      toStatus:    'open',
      changedBy:   ctx.userId,
      note:        `Filed via ${filedVia || 'student_portal'}` +
                   (assignee ? `. Auto-routed to ${assignee.role} (${assignee.id})` : '')
    });

    await audit(db, {
      tenantId:   ctx.tenantId,
      actorId:    ctx.userId,
      action:     'complaint.filed',
      entityType: 'complaint',
      entityId:   complaint.id,
      meta:       { scope, filedVia, assignedTo: assignee?.id }
    });

    // Notify assignee and student
    if (assignee) {
      await _enqueueNotification(db, ctx.tenantId, assignee.id, 'complaint.assigned', { complaintId: complaint.id });
    }
    if (complaint.student_id && complaint.student_id !== ctx.userId) {
      await _enqueueNotification(db, ctx.tenantId, complaint.student_id, 'complaint.filed_on_behalf', { complaintId: complaint.id });
    }

    return complaint;
  });
}

// ---------------------------------------------------------------------------
// acknowledge
// Assigned owner (or supervisor) acknowledges the complaint.
// Target: within 2 working days of filing (§18.1).
// ---------------------------------------------------------------------------
async function acknowledge(ctx, { complaintId, note }) {
  checkPermission(ctx, 'complaint:manage');
  _assertNotLogRouteOnly(ctx.userRole);

  return withTenant(ctx, async (db) => {
    const complaint = await _requireComplaint(db, complaintId, ['open']);

    await _assertCanManage(ctx, complaint);

    await db.query(
      `UPDATE complaints
       SET status = 'acknowledged', acknowledged_at = now(), acknowledged_by = $1, updated_at = now()
       WHERE id = $2`,
      [ctx.userId, complaintId]
    );

    await _recordHistory(db, { complaintId, fromStatus: 'open', toStatus: 'acknowledged', changedBy: ctx.userId, note });
    await audit(db, { tenantId: ctx.tenantId, actorId: ctx.userId, action: 'complaint.acknowledged', entityType: 'complaint', entityId: complaintId });

    // Notify student
    await _notifyStudent(db, ctx.tenantId, complaint, 'complaint.status_changed', { newStatus: 'acknowledged' });

    return { acknowledged: true, complaintId };
  });
}

// ---------------------------------------------------------------------------
// addComment
// Internal investigation note. Owner and supervisors only.
// ---------------------------------------------------------------------------
async function addComment(ctx, { complaintId, body }) {
  checkPermission(ctx, 'complaint:manage');
  _assertNotLogRouteOnly(ctx.userRole);

  if (!body || !body.trim()) {
    throw Object.assign(new Error('Comment body is required'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    const complaint = await _requireComplaint(db, complaintId, ['open', 'acknowledged', 'in_progress', 'escalated']);
    await _assertCanManage(ctx, complaint);

    const res = await db.query(
      `INSERT INTO complaint_comments (complaint_id, author_id, body) VALUES ($1,$2,$3) RETURNING *`,
      [complaintId, ctx.userId, body.trim()]
    );

    // Advance to in_progress on first comment if still acknowledged
    if (complaint.status === 'acknowledged') {
      await db.query(
        `UPDATE complaints SET status = 'in_progress', updated_at = now() WHERE id = $1`,
        [complaintId]
      );
      await _recordHistory(db, { complaintId, fromStatus: 'acknowledged', toStatus: 'in_progress', changedBy: ctx.userId, note: 'Investigation started' });
    }

    return res.rows[0];
  });
}

// ---------------------------------------------------------------------------
// resolve
// Owner resolves the complaint with a resolution note.
// Target: within 10 working days (§18.1).
// Student sees status update in portal.
// ---------------------------------------------------------------------------
async function resolve(ctx, { complaintId, resolutionNote }) {
  checkPermission(ctx, 'complaint:manage');
  _assertNotLogRouteOnly(ctx.userRole);

  if (!resolutionNote || !resolutionNote.trim()) {
    throw Object.assign(new Error('Resolution note is required'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    const complaint = await _requireComplaint(db, complaintId, ['open', 'acknowledged', 'in_progress', 'escalated']);
    await _assertCanManage(ctx, complaint);

    await db.query(
      `UPDATE complaints
       SET status = 'resolved', resolved_at = now(), resolved_by = $1,
           resolution_note = $2, updated_at = now()
       WHERE id = $3`,
      [ctx.userId, resolutionNote.trim(), complaintId]
    );

    await _recordHistory(db, {
      complaintId, fromStatus: complaint.status, toStatus: 'resolved',
      changedBy: ctx.userId, note: resolutionNote.trim()
    });

    await audit(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action: 'complaint.resolved', entityType: 'complaint', entityId: complaintId,
      meta: { resolutionNote: resolutionNote.trim() }
    });

    await _notifyStudent(db, ctx.tenantId, complaint, 'complaint.status_changed', { newStatus: 'resolved', resolutionNote: resolutionNote.trim() });

    return { resolved: true, complaintId };
  });
}

// ---------------------------------------------------------------------------
// escalate
// Escalate to a higher-tier owner (e.g. TSC → TCC, TCC → Admin).
// Must complete within 10 working days total (§18.1).
// ---------------------------------------------------------------------------
async function escalate(ctx, { complaintId, escalateToUserId, note }) {
  checkPermission(ctx, 'complaint:manage');
  _assertNotLogRouteOnly(ctx.userRole);

  return withTenant(ctx, async (db) => {
    const complaint = await _requireComplaint(db, complaintId, ['open', 'acknowledged', 'in_progress']);
    await _assertCanManage(ctx, complaint);

    await db.query(
      `UPDATE complaints
       SET status = 'escalated', escalated_at = now(), escalated_by = $1,
           escalated_to = $2, assigned_to = $2, assigned_at = now(), updated_at = now()
       WHERE id = $3`,
      [ctx.userId, escalateToUserId, complaintId]
    );

    await _recordHistory(db, {
      complaintId, fromStatus: complaint.status, toStatus: 'escalated',
      changedBy: ctx.userId, note: note || `Escalated to ${escalateToUserId}`
    });

    await audit(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId, action: 'complaint.escalated',
      entityType: 'complaint', entityId: complaintId,
      meta: { escalatedTo: escalateToUserId }
    });

    await _enqueueNotification(db, ctx.tenantId, escalateToUserId, 'complaint.escalated_to_you', { complaintId });
    await _notifyStudent(db, ctx.tenantId, complaint, 'complaint.status_changed', { newStatus: 'escalated' });

    return { escalated: true, complaintId };
  });
}

// ---------------------------------------------------------------------------
// close
// Final closure after resolution. Super Admin / Admin / TCC only.
// ---------------------------------------------------------------------------
async function close(ctx, { complaintId, note }) {
  checkPermission(ctx, 'complaint:manage');

  const role = ctx.userRole?.toLowerCase();
  if (!CENTRE_RESOLVERS.includes(role)) {
    throw Object.assign(new Error('Only Admin/TCC may close complaints'), { statusCode: 403 });
  }

  return withTenant(ctx, async (db) => {
    const complaint = await _requireComplaint(db, complaintId, ['resolved']);

    await db.query(
      `UPDATE complaints SET status = 'closed', updated_at = now() WHERE id = $1`,
      [complaintId]
    );

    await _recordHistory(db, { complaintId, fromStatus: 'resolved', toStatus: 'closed', changedBy: ctx.userId, note });
    await audit(db, { tenantId: ctx.tenantId, actorId: ctx.userId, action: 'complaint.closed', entityType: 'complaint', entityId: complaintId });

    return { closed: true, complaintId };
  });
}

// ---------------------------------------------------------------------------
// getComplaint / listComplaints
// ---------------------------------------------------------------------------
async function getComplaint(ctx, complaintId) {
  checkPermission(ctx, 'complaint:read');

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT c.*,
         (SELECT json_agg(h ORDER BY h.changed_at)
          FROM complaint_status_history h WHERE h.complaint_id = c.id) AS history,
         (SELECT json_agg(cm ORDER BY cm.created_at)
          FROM complaint_comments cm WHERE cm.complaint_id = c.id) AS comments
       FROM complaints c WHERE c.id = $1`,
      [complaintId]
    );
    if (res.rows.length === 0) throw Object.assign(new Error('Complaint not found'), { statusCode: 404 });

    // Students may only view their own complaints
    const role = ctx.userRole?.toLowerCase();
    const row  = res.rows[0];
    if (role === 'student' && row.student_id !== ctx.userId && row.filed_by !== ctx.userId) {
      throw Object.assign(new Error('Access denied'), { statusCode: 403 });
    }

    return row;
  });
}

async function listComplaints(ctx, { status, scope, assignedToMe } = {}) {
  checkPermission(ctx, 'complaint:read');

  return withTenant(ctx, async (db) => {
    const role = ctx.userRole?.toLowerCase();
    const conditions = [];
    const params     = [ctx.tenantId];

    if (role === 'student') {
      // Students only see their own
      params.push(ctx.userId);
      conditions.push(`(c.student_id = $${params.length} OR c.filed_by = $${params.length})`);
    } else if (role === 'tsc' || role === 'tsa') {
      // Site-scoped roles only see site complaints assigned to them
      params.push(ctx.userId);
      conditions.push(`c.assigned_to = $${params.length}`);
    } else if (assignedToMe) {
      params.push(ctx.userId);
      conditions.push(`c.assigned_to = $${params.length}`);
    }

    if (status) { params.push(status); conditions.push(`c.status = $${params.length}`); }
    if (scope)  { params.push(scope);  conditions.push(`c.scope = $${params.length}`); }

    const where = conditions.length ? 'AND ' + conditions.join(' AND ') : '';

    const res = await db.query(
      `SELECT c.* FROM complaints c
       WHERE c.tenant_id = $1 ${where}
       ORDER BY c.created_at DESC`,
      params
    );

    return res.rows;
  });
}

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------
async function _resolveAssignee(db, tenantId, scope, siteId) {
  if (scope === 'centre') {
    const res = await db.query(
      `SELECT id, role FROM users WHERE tenant_id = $1 AND role = 'tcc' AND status = 'active' LIMIT 1`,
      [tenantId]
    );
    return res.rows[0] || null;
  } else {
    // Site scope — prefer TSC, fall back to TSA
    const res = await db.query(
      `SELECT id, role FROM users
       WHERE tenant_id = $1 AND site_id = $2 AND role IN ('tsc','tsa') AND status = 'active'
       ORDER BY CASE role WHEN 'tsc' THEN 1 ELSE 2 END LIMIT 1`,
      [tenantId, siteId]
    );
    return res.rows[0] || null;
  }
}

async function _requireComplaint(db, complaintId, allowedStatuses) {
  const res = await db.query(`SELECT * FROM complaints WHERE id = $1`, [complaintId]);
  if (res.rows.length === 0) throw Object.assign(new Error('Complaint not found'), { statusCode: 404 });
  const c = res.rows[0];
  if (!allowedStatuses.includes(c.status)) throw Object.assign(
    new Error(`Complaint is '${c.status}'; expected: ${allowedStatuses.join(' | ')}`),
    { statusCode: 409 }
  );
  return c;
}

function _assertNotLogRouteOnly(userRole) {
  if (LOG_ROUTE_ONLY.includes(userRole?.toLowerCase())) {
    throw Object.assign(
      new Error(`${userRole} may log and route complaints but not manage them`),
      { statusCode: 403 }
    );
  }
}

function _assertCanManage(ctx, complaint) {
  const role = ctx.userRole?.toLowerCase();
  if (CENTRE_RESOLVERS.includes(role)) return; // always allowed
  if (SITE_RESOLVERS.includes(role)) {
    if (complaint.scope !== 'site') throw Object.assign(
      new Error('TSC/TSA may only manage site-scoped complaints'), { statusCode: 403 }
    );
    return;
  }
  throw Object.assign(new Error('Insufficient permission to manage complaints'), { statusCode: 403 });
}

async function _recordHistory(db, { complaintId, fromStatus, toStatus, changedBy, note }) {
  await db.query(
    `INSERT INTO complaint_status_history (complaint_id, from_status, to_status, changed_by, note)
     VALUES ($1,$2,$3,$4,$5)`,
    [complaintId, fromStatus || null, toStatus, changedBy, note || null]
  );
}

async function _enqueueNotification(db, tenantId, recipientId, eventType, payload) {
  await db.query(
    `INSERT INTO notification_events (tenant_id, recipient_id, event_type, payload)
     VALUES ($1,$2,$3,$4)`,
    [tenantId, recipientId, eventType, JSON.stringify(payload)]
  );
}

async function _notifyStudent(db, tenantId, complaint, eventType, payload) {
  if (!complaint.student_id) return;
  await _enqueueNotification(db, tenantId, complaint.student_id, eventType, {
    complaintId: complaint.id, ...payload
  });
}

module.exports = {
  fileComplaint,
  acknowledge,
  addComment,
  resolve,
  escalate,
  close,
  getComplaint,
  listComplaints
};
