'use strict';

/**
 * accountService.js — Step 5e
 *
 * Account lifecycle (§6.4):
 *   provisionAccount → deactivateAccount → recertifyAccount
 *   flagDormant (scheduler) → suspendDormant (scheduler)
 *   autoSuspendInstructor / restoreInstructor (§6.4 automatic suspension)
 *
 * Session management (§6.2):
 *   createSession → revokeSession → revokeAllSessions → listSessions
 *
 * Hierarchy rule (§3.1): accounts created only by the tier above.
 */

const { withTenant, writeAuditLog } = require('../db/index');
const { checkPermission }            = require('../permissions');
const delegSvc                       = require('./delegationService');

// Creation hierarchy — who may create which roles
const CREATION_HIERARCHY = {
  super_admin: ['admin'],
  admin:       ['tcc'],
  tcc:         ['tca','tcf','instructor','tsc','tsa','helpline_agent','accountant'],
  tca:         ['tsc','tsa','instructor'],
  tsc:         [],
  tsa:         []
};

// Roles requiring mandatory MFA (§6.1)
const MFA_REQUIRED_ROLES = ['super_admin','admin','tcc','tca','accountant'];

// Idle timeout in minutes per role (§6.2)
const IDLE_TIMEOUT = {
  super_admin: 30, admin: 30, tcc: 30, tca: 30, accountant: 30,
  _default_staff: 480,   // 8 hours
  student: 43200         // 30 days
};

// ---------------------------------------------------------------------------
// provisionAccount (§6.4 Provisioning)
// ---------------------------------------------------------------------------
async function provisionAccount(ctx, { role, email, fullName, siteId, ownerId }) {
  checkPermission(ctx, 'account:create');

  const creatorRole = ctx.userRole?.toLowerCase();
  const allowed     = CREATION_HIERARCHY[creatorRole] || [];

  if (!allowed.includes(role?.toLowerCase())) {
    throw Object.assign(
      new Error(`Role '${creatorRole}' cannot create '${role}' accounts (§3.1 hierarchy)`),
      { statusCode: 403 }
    );
  }

  if (!email || !email.includes('@')) {
    throw Object.assign(new Error('Valid email required'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    // Check email uniqueness within tenant
    const existing = await db.query(
      `SELECT id FROM users WHERE tenant_id = $1 AND email = $2`, [ctx.tenantId, email.toLowerCase()]
    );
    if (existing.rows.length > 0) {
      throw Object.assign(new Error('Email already exists in this tenant'), { statusCode: 409 });
    }

    const res = await db.query(
      `INSERT INTO users
         (tenant_id, role, email, full_name, site_id, owner_id, status, mfa_required)
       VALUES ($1,$2,$3,$4,$5,$6,'active',$7)
       RETURNING *`,
      [
        ctx.tenantId, role.toLowerCase(), email.toLowerCase(), fullName,
        siteId || null, ownerId || ctx.userId,
        MFA_REQUIRED_ROLES.includes(role.toLowerCase())
      ]
    );

    const user = res.rows[0];
    await writeAuditLog(db, {
      tenantId:   ctx.tenantId, actorId: ctx.userId,
      action:     'account.provisioned', entityType: 'user', entityId: user.id,
      meta:       { role, email: email.toLowerCase() }
    });

    return user;
  });
}

// ---------------------------------------------------------------------------
// deactivateAccount (§6.4 Deactivation)
// Deactivates, not deletes. Revokes all sessions, API tokens, delegations.
// ---------------------------------------------------------------------------
async function deactivateAccount(ctx, { userId, reason }) {
  checkPermission(ctx, 'account:deactivate');

  if (!reason || !reason.trim()) {
    throw Object.assign(new Error('Deactivation reason is required'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    const userRes = await db.query(`SELECT * FROM users WHERE id = $1`, [userId]);
    if (userRes.rows.length === 0) throw Object.assign(new Error('User not found'), { statusCode: 404 });
    const user = userRes.rows[0];

    if (user.status === 'deactivated') {
      throw Object.assign(new Error('User is already deactivated'), { statusCode: 409 });
    }

    // 1. Deactivate account
    await db.query(
      `UPDATE users SET status = 'deactivated', updated_at = now() WHERE id = $1`, [userId]
    );

    // 2. Revoke all active sessions (§6.4)
    await db.query(
      `UPDATE user_sessions
       SET revoked_at = now(), revoke_reason = 'deactivation'
       WHERE user_id = $1 AND revoked_at IS NULL`,
      [userId]
    );

    // 3. Revoke all active delegations received by this user (§6.4)
    const revokedDelegations = await delegSvc.revokeAllForUser(db, {
      tenantId: ctx.tenantId, userId, revokedBy: ctx.userId
    });

    await writeAuditLog(db, {
      tenantId:   ctx.tenantId, actorId: ctx.userId,
      action:     'account.deactivated', entityType: 'user', entityId: userId,
      meta:       { reason: reason.trim(), revokedDelegations }
    });

    return { deactivated: true, userId, revokedDelegations };
  });
}

// ---------------------------------------------------------------------------
// recertifyAccount (§6.4 Recertification)
// TCC confirms active accounts quarterly; Super Admin confirms admins semi-annually.
// Unconfirmed accounts auto-suspend after 14 days (enforced by scheduler).
// ---------------------------------------------------------------------------
async function recertifyAccount(ctx, { reviewedUserId, confirmed, period, note }) {
  checkPermission(ctx, 'account:recertify');

  if (typeof confirmed !== 'boolean') {
    throw Object.assign(new Error('confirmed must be boolean'), { statusCode: 422 });
  }

  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `INSERT INTO account_recertifications
         (tenant_id, reviewer_id, reviewed_user_id, period, confirmed, note)
       VALUES ($1,$2,$3,$4,$5,$6)
       RETURNING *`,
      [ctx.tenantId, ctx.userId, reviewedUserId, period, confirmed, note || null]
    );

    await writeAuditLog(db, {
      tenantId:   ctx.tenantId, actorId: ctx.userId,
      action:     confirmed ? 'account.recertified' : 'account.recertification_failed',
      entityType: 'user', entityId: reviewedUserId,
      meta:       { period, confirmed }
    });

    // If not confirmed, flag for potential auto-suspend
    if (!confirmed) {
      await db.query(
        `UPDATE users SET recert_pending_since = now() WHERE id = $1 AND recert_pending_since IS NULL`,
        [reviewedUserId]
      );
    }

    return res.rows[0];
  });
}

// ---------------------------------------------------------------------------
// autoSuspendInstructor / restoreInstructor (§6.4 Automatic suspension)
// Called by scheduler when instructor alignment/card expires or is renewed.
// ---------------------------------------------------------------------------
async function autoSuspendInstructor(db, { tenantId, userId, reason }) {
  await db.query(
    `UPDATE users
     SET teach_test_suspended = true, teach_test_suspended_reason = $1, updated_at = now()
     WHERE id = $2`,
    [reason, userId]
  );
  await writeAuditLog(db, {
    tenantId, actorId: null,
    action: 'instructor.teach_test_suspended', entityType: 'user', entityId: userId,
    meta: { reason }
  });
}

async function restoreInstructor(db, { tenantId, userId }) {
  await db.query(
    `UPDATE users
     SET teach_test_suspended = false, teach_test_suspended_reason = NULL, updated_at = now()
     WHERE id = $1`,
    [userId]
  );
  await writeAuditLog(db, {
    tenantId, actorId: null,
    action: 'instructor.teach_test_restored', entityType: 'user', entityId: userId,
    meta: {}
  });
}

// ---------------------------------------------------------------------------
// Session management (§6.2)
// ---------------------------------------------------------------------------
async function createSession(ctx, { deviceLabel, ipAddress, userAgent, ttlMinutes }) {
  return withTenant(ctx, async (db) => {
    const role    = ctx.userRole?.toLowerCase();
    const timeout = IDLE_TIMEOUT[role] ?? IDLE_TIMEOUT._default_staff;
    const minutes = ttlMinutes || timeout;
    const expires = new Date(Date.now() + minutes * 60 * 1000);

    const res = await db.query(
      `INSERT INTO user_sessions
         (user_id, tenant_id, device_label, ip_address, user_agent, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6)
       RETURNING *`,
      [ctx.userId, ctx.tenantId, deviceLabel || null, ipAddress || null, userAgent || null, expires]
    );
    return res.rows[0];
  });
}

async function revokeSession(ctx, { sessionId, reason }) {
  return withTenant(ctx, async (db) => {
    await db.query(
      `UPDATE user_sessions
       SET revoked_at = now(), revoked_by = $1, revoke_reason = $2
       WHERE id = $3 AND (user_id = $4 OR $5 = 'admin' OR $5 = 'super_admin')`,
      [ctx.userId, reason || 'user_logout', sessionId, ctx.userId, ctx.userRole?.toLowerCase()]
    );
    await writeAuditLog(db, {
      tenantId: ctx.tenantId, actorId: ctx.userId,
      action: 'session.revoked', entityType: 'user_session', entityId: sessionId,
      meta: { reason }
    });
    return { revoked: true, sessionId };
  });
}

async function revokeAllSessions(db, { userId, reason }) {
  await db.query(
    `UPDATE user_sessions
     SET revoked_at = now(), revoke_reason = $1
     WHERE user_id = $2 AND revoked_at IS NULL`,
    [reason || 'security_event', userId]
  );
}

async function listSessions(ctx) {
  return withTenant(ctx, async (db) => {
    const res = await db.query(
      `SELECT id, device_label, ip_address, created_at, last_seen_at, expires_at, revoked_at
       FROM user_sessions
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [ctx.userId]
    );
    return res.rows;
  });
}

module.exports = {
  provisionAccount, deactivateAccount, recertifyAccount,
  autoSuspendInstructor, restoreInstructor,
  createSession, revokeSession, revokeAllSessions, listSessions,
  CREATION_HIERARCHY, MFA_REQUIRED_ROLES
};
