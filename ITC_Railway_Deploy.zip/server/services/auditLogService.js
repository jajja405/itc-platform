'use strict';

/**
 * auditLogService.js — Step 5e
 *
 * Platform-wide audit log (§8.3):
 *   writeAuditLog — append-only, hash-chained, tamper-evident
 *   queryAuditLog — tenant-scoped read with chain verification
 *   verifyChainIntegrity — detect tampering by re-computing hash chain
 *
 * Rules:
 *   - No role including Super Admin can edit or purge entries
 *   - Entries are hash-chained: each entry hashes content + prev_hash
 *   - Tenants see own entries; platform entries (tenant_id=NULL) visible to Super Admin/Admin
 *   - Minimum 3-year retention; financial entries follow statutory retention
 */

const crypto = require('crypto');
const { checkPermission } = require('../permissions');

// ---------------------------------------------------------------------------
// writeAuditLog — core append function used by all services
// This is also exported from db/index.js as a convenience wrapper.
// ---------------------------------------------------------------------------
async function writeAuditLog(db, { tenantId, actorId, action, entityType, entityId, meta }) {
  // Get previous entry hash for chain (latest by id)
  const prevRes = await db.query(
    `SELECT id, entry_hash FROM audit_log ORDER BY id DESC LIMIT 1`
  );
  const prevHash = prevRes.rows.length > 0 ? prevRes.rows[0].entry_hash : null;

  // Compute this entry's hash: SHA-256(action + JSON(meta) + prevHash)
  const hashInput = [
    action,
    JSON.stringify(meta || {}),
    prevHash || ''
  ].join('|');
  const entryHash = crypto.createHash('sha256').update(hashInput).digest('hex');

  const res = await db.query(
    `INSERT INTO audit_log
       (tenant_id, actor_id, action, entity_type, entity_id, meta, entry_hash, prev_hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     RETURNING *`,
    [
      tenantId || null, actorId || null, action,
      entityType || null, entityId || null,
      meta ? JSON.stringify(meta) : null,
      entryHash, prevHash
    ]
  );

  return res.rows[0];
}

// ---------------------------------------------------------------------------
// queryAuditLog — scoped read
// ---------------------------------------------------------------------------
async function queryAuditLog(ctx, { entityType, entityId, action, actorId, fromDate, toDate, limit = 100 } = {}) {
  checkPermission(ctx, 'audit_log:read');

  // Build filter
  const conditions = [];
  const params     = [];

  // Scope: tenants see own; super_admin/admin see all including platform rows
  const role = ctx.userRole?.toLowerCase();
  if (!['super_admin','admin'].includes(role)) {
    params.push(ctx.tenantId);
    conditions.push(`(al.tenant_id = $${params.length})`);
  }

  if (entityType) { params.push(entityType); conditions.push(`al.entity_type = $${params.length}`); }
  if (entityId)   { params.push(entityId);   conditions.push(`al.entity_id = $${params.length}`); }
  if (action)     { params.push(action);      conditions.push(`al.action = $${params.length}`); }
  if (actorId)    { params.push(actorId);     conditions.push(`al.actor_id = $${params.length}`); }
  if (fromDate)   { params.push(fromDate);    conditions.push(`al.occurred_at >= $${params.length}`); }
  if (toDate)     { params.push(toDate);      conditions.push(`al.occurred_at <= $${params.length}`); }

  params.push(Math.min(limit, 1000));

  const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

  // Use withTenant pattern without RLS for audit reads (audit log has its own scoping above)
  const res = await db.query(
    `SELECT al.* FROM audit_log al
     ${where}
     ORDER BY al.id DESC
     LIMIT $${params.length}`,
    params
  );

  return res.rows;
}

// ---------------------------------------------------------------------------
// verifyChainIntegrity — detect any tampering in the audit log
// Re-computes each entry's hash and checks it matches stored value.
// Returns { valid: true } or { valid: false, firstBadId: N }
// ---------------------------------------------------------------------------
async function verifyChainIntegrity(db, { tenantId, limit = 10000 } = {}) {
  const params = tenantId ? [tenantId] : [];
  const where  = tenantId ? 'WHERE tenant_id = $1' : '';

  const res = await db.query(
    `SELECT id, action, meta, entry_hash, prev_hash
     FROM audit_log ${where}
     ORDER BY id ASC
     LIMIT ${limit}`,
    params
  );

  const entries = res.rows;
  let expectedPrev = null;

  for (const entry of entries) {
    const hashInput = [
      entry.action,
      entry.meta || JSON.stringify({}),
      expectedPrev || ''
    ].join('|');
    const computed = crypto.createHash('sha256').update(hashInput).digest('hex');

    if (computed !== entry.entry_hash) {
      return { valid: false, firstBadId: entry.id, storedHash: entry.entry_hash, computedHash: computed };
    }
    expectedPrev = entry.entry_hash;
  }

  return { valid: true, entriesChecked: entries.length };
}

module.exports = { writeAuditLog, queryAuditLog, verifyChainIntegrity };
