/**
 * WhatsApp Business API integration.
 * Plug in Meta's Cloud API credentials via env vars to go live:
 *   WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_ACCESS_TOKEN
 */
const configured = () => !!(process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_ACCESS_TOKEN);

async function sendMessage({ to, text }) {
  if (!configured()) {
    return { status: 'sandbox', note: 'WHATSAPP_* credentials not configured; message logged, not sent.', to, text };
  }
  // Real integration point:
  // POST https://graph.facebook.com/v19.0/{WHATSAPP_PHONE_NUMBER_ID}/messages
  // Authorization: Bearer {WHATSAPP_ACCESS_TOKEN}
  throw new Error('Live WhatsApp send path not yet implemented against Meta Cloud API.');
}

// Inbound webhook verification handshake (Meta requires this for setup).
function verifyWebhook(query) {
  const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || 'dev-verify-token';
  if (query['hub.mode'] === 'subscribe' && query['hub.verify_token'] === VERIFY_TOKEN) {
    return query['hub.challenge'];
  }
  return null;
}

module.exports = { sendMessage, verifyWebhook, configured };
