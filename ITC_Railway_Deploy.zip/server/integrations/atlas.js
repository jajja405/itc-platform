/**
 * AHA Atlas connector.
 *
 * Direction (push-only vs two-way sync) is an open item in the
 * specification, pending confirmation of AHA's actual integration terms
 * and whether a public API exists. This module defines the shape of
 * both directions so either can be enabled once that's confirmed.
 */
const configured = () => !!process.env.ATLAS_API_KEY;

// Outbound: push a completed roster / card issuance to Atlas.
async function pushRoster({ classId, course, instructorId, students }) {
  if (!configured()) {
    return { status: 'sandbox', note: 'ATLAS_API_KEY not configured; roster logged, not pushed.' };
  }
  throw new Error('Live Atlas push not implemented — pending confirmed API endpoint from AHA.');
}

// Inbound: pull instructor alignment/status updates from Atlas (if AHA exposes this).
async function pullInstructorStatus(instructorId) {
  if (!configured()) {
    return { status: 'sandbox', note: 'ATLAS_API_KEY not configured; no data pulled.' };
  }
  throw new Error('Live Atlas pull not implemented — pending confirmed API endpoint from AHA.');
}

module.exports = { pushRoster, pullInstructorStatus, configured };
