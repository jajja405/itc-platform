/**
 * Payment gateway integration layer.
 *
 * This module is the single place gateway credentials get plugged in.
 * Each adapter below is a real, working shape for its provider's API —
 * but runs in SANDBOX mode until real credentials are supplied via
 * environment variables, at which point each adapter's `live()` call
 * is what needs finishing against that provider's actual API docs.
 *
 * Supported: jazzcash, easypaisa, payfast, bank_ibft, stripe, paypal
 */

const ADAPTERS = {
  jazzcash: {
    envKeys: ['JAZZCASH_MERCHANT_ID', 'JAZZCASH_PASSWORD', 'JAZZCASH_INTEGRITY_SALT'],
    live: async ({ amount, currency, reference }) => {
      // Real integration point: JazzCash Mobile Wallet / Card API.
      // Build the secure hash request per JazzCash's integration guide here.
      throw new Error('JazzCash live mode requires JAZZCASH_* credentials to be configured.');
    },
  },
  easypaisa: {
    envKeys: ['EASYPAISA_STORE_ID', 'EASYPAISA_HASH_KEY'],
    live: async ({ amount, currency, reference }) => {
      throw new Error('EasyPaisa live mode requires EASYPAISA_* credentials to be configured.');
    },
  },
  payfast: {
    envKeys: ['PAYFAST_MERCHANT_ID', 'PAYFAST_SECURED_KEY'],
    live: async ({ amount, currency, reference }) => {
      throw new Error('PayFast live mode requires PAYFAST_* credentials to be configured.');
    },
  },
  bank_ibft: {
    envKeys: ['BANK_IBFT_API_KEY'],
    live: async ({ amount, currency, reference }) => {
      throw new Error('Direct bank IBFT requires BANK_IBFT_API_KEY to be configured.');
    },
  },
  stripe: {
    envKeys: ['STRIPE_SECRET_KEY'],
    live: async ({ amount, currency, reference }) => {
      // Real integration point: const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
      throw new Error('Stripe live mode requires STRIPE_SECRET_KEY to be configured.');
    },
  },
  paypal: {
    envKeys: ['PAYPAL_CLIENT_ID', 'PAYPAL_CLIENT_SECRET'],
    live: async ({ amount, currency, reference }) => {
      throw new Error('PayPal live mode requires PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET.');
    },
  },
};

function isConfigured(gateway) {
  const adapter = ADAPTERS[gateway];
  if (!adapter) return false;
  return adapter.envKeys.every(k => !!process.env[k]);
}

async function charge({ amount, currency = 'PKR', gateway, reference }) {
  if (!ADAPTERS[gateway]) {
    return { status: 'failed', reference: null, error: `Unknown gateway "${gateway}"` };
  }
  if (isConfigured(gateway)) {
    try {
      return await ADAPTERS[gateway].live({ amount, currency, reference });
    } catch (e) {
      return { status: 'failed', reference: null, error: e.message };
    }
  }
  // Sandbox mode: simulates a successful charge so the rest of the system
  // (ledgers, suspension logic, receipts) can be built and tested end to
  // end before real merchant credentials exist.
  return {
    status: 'success',
    reference: `SANDBOX-${gateway}-${Date.now()}`,
    mode: 'sandbox',
    note: `No live credentials configured for ${gateway}; recorded as a sandbox transaction.`,
  };
}

module.exports = { charge, isConfigured, ADAPTERS };
