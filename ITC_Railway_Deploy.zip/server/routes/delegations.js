const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth } = require('../lib/auth');
const { NON_DELEGABLE } = require('../lib/roles');
const { logAction } = require('../lib/audit');

const router = express.Router();
router.use(requireAuth);

function sweepExpired() {
  const now = new Date().toISOString();
  for (const d of store.filter('delegations', x => x.status === 'active' && x.endTime < now)) {
    store.update('delegations', d.id, { status: 'expired' });
  }
}

router.get('/', (req, res) => {
  sweepExpired();
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.json(store.filter('delegations', d => d.recipientId === req.user.id));
  }
  res.json(store.all('delegations'));
});

// Only Admin/Super Admin may grant. TCC/TCA explicitly excluded per spec.
router.post('/', requireAuth, (req, res) => {
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only Admin or Super Admin may grant temporary authority.' });
  }
  const { recipientId, permission, startTime, endTime } = req.body;
  if (NON_DELEGABLE.has(permission)) {
    return res.status(422).json({ error: `"${permission}" can never be delegated.` });
  }
  const { hasPermission } = require('../lib/roles');
  const recipient = store.find('users', u => u.id === recipientId);
  if (!recipient) return res.status(404).json({ error: 'Recipient not found' });
  if (hasPermission(recipient.role, permission)) {
    return res.status(409).json({ error: 'Recipient already holds this permission standing. Delegation blocked as redundant.' });
  }

  const grant = {
    id: uuid(), grantorId: req.user.id, recipientId, permission,
    startTime: startTime || new Date().toISOString(), endTime,
    status: 'active', createdAt: new Date().toISOString(),
  };
  store.insert('delegations', grant);
  logAction(req.user, 'delegation.grant', { delegationId: grant.id, recipientId, permission, endTime });
  res.status(201).json(grant);
});

router.post('/:id/revoke', requireAuth, (req, res) => {
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only Admin or Super Admin may revoke a delegation.' });
  }
  const grant = store.find('delegations', d => d.id === req.params.id);
  if (!grant) return res.status(404).json({ error: 'Delegation not found' });
  const updated = store.update('delegations', grant.id, { status: 'revoked_early', revokedBy: req.user.id, revokedAt: new Date().toISOString() });
  logAction(req.user, 'delegation.revoke_early', { delegationId: grant.id });
  res.json(updated);
});

module.exports = router;
