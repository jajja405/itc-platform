const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth, requirePermission } = require('../lib/auth');
const { PERM } = require('../lib/roles');
const { logAction } = require('../lib/audit');

const router = express.Router();
router.use(requireAuth);

router.get('/', (req, res) => {
  const { role, tenantId, siteId } = req.user;
  let visible;
  if (role === 'super_admin' || role === 'admin') visible = store.all('complaints');
  else if (role === 'tcc' || role === 'tca') visible = store.filter('complaints', c => c.tenantId === tenantId && c.scope === 'itc');
  else if (role === 'tsc' || role === 'tsa') visible = store.filter('complaints', c => c.siteId === siteId && c.scope === 'site');
  else visible = store.filter('complaints', c => c.loggedBy === req.user.id);
  res.json(visible);
});

// Logged by Helpline Agent or Agentic AI (also allowed for platform/centre roles directly).
router.post('/', (req, res) => {
  const { studentName, channel, scope, siteId, description } = req.body;
  const complaint = {
    id: uuid(),
    tenantId: req.user.tenantId,
    siteId: siteId || req.user.siteId || null,
    studentName, channel, scope: scope || (siteId ? 'site' : 'itc'), description,
    status: 'open',
    loggedBy: req.user.id,
    handlerType: req.user.role === 'agentic_ai' ? 'ai' : (req.user.role === 'helpline_agent' ? 'human_agent' : 'staff'),
    loggedAt: new Date().toISOString(),
    resolution: null,
  };
  store.insert('complaints', complaint);
  logAction(req.user, 'complaint.log', { complaintId: complaint.id, scope: complaint.scope });
  res.status(201).json(complaint);
});

router.patch('/:id/resolve', (req, res) => {
  const complaint = store.find('complaints', c => c.id === req.params.id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found' });

  const perm = complaint.scope === 'site' ? PERM.RESOLVE_COMPLAINT_SITE : PERM.RESOLVE_COMPLAINT_ITC;
  const { hasPermission } = require('../lib/roles');
  if (!hasPermission(req.user.role, perm)) {
    return res.status(403).json({ error: `Only the responsible ${complaint.scope === 'site' ? 'TSC/TSA' : 'TCC/TCA'} may resolve this complaint.` });
  }

  const updated = store.update('complaints', complaint.id, {
    status: 'resolved', resolution: req.body.resolution, resolvedBy: req.user.id, resolvedAt: new Date().toISOString(),
  });
  logAction(req.user, 'complaint.resolve', { complaintId: complaint.id });
  res.json(updated);
});

module.exports = router;
