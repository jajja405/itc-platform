const express = require('express');
const { v4: uuid } = require('uuid');
const fs = require('fs');
const path = require('path');
const { PDFDocument, StandardFonts, rgb } = require('pdf-lib');
const store = require('../db/store');
const { requireAuth, requirePermission } = require('../lib/auth');
const { PERM, ROLES } = require('../lib/roles');
const { logAction } = require('../lib/audit');

const router = express.Router();
router.use(requireAuth);

const SIGNED_DIR = path.join(__dirname, '..', '..', 'uploads', 'signed');
if (!fs.existsSync(SIGNED_DIR)) fs.mkdirSync(SIGNED_DIR, { recursive: true });

// ---- Templates ----

router.get('/templates', (req, res) => {
  const { role, tenantId } = req.user;
  const isPlatform = role === 'super_admin' || role === 'admin';
  res.json(store.filter('checklist_templates', t => isPlatform || t.tenantId === tenantId));
});

/**
 * Upload and field-map a new checklist version for a course.
 * "fields" is the mapping step: each item's position on the sheet.
 * Restricted to Admin, TCC, TCA, TSC, TSA (and Super Admin by inheritance).
 */
router.post('/templates', requirePermission(PERM.UPLOAD_CHECKLIST), (req, res) => {
  const { course, versionLabel, sections } = req.body;
  if (!course || !sections) return res.status(422).json({ error: 'course and sections are required' });

  // Retire any currently active template for this course first.
  const current = store.find('checklist_templates', t => t.course === course && t.status === 'active' && t.tenantId === req.user.tenantId);
  let replacementAlert = null;
  if (current) {
    store.update('checklist_templates', current.id, { status: 'retired', retiredAt: new Date().toISOString() });
    logAction(req.user, 'checklist_template.retire', { templateId: current.id, course });
  }

  const template = {
    id: uuid(),
    tenantId: req.user.tenantId,
    course,
    versionLabel: versionLabel || `v${new Date().toISOString().slice(0, 10)}`,
    effectiveDate: new Date().toISOString(),
    status: 'active',
    sections, // [{ title, items: [{ id, main, sub }] }]
    uploadedBy: req.user.id,
  };
  store.insert('checklist_templates', template);
  logAction(req.user, 'checklist_template.upload', { templateId: template.id, course });

  // Any class already scheduled for this course before the new template
  // existed keeps its original templateId — this alert is informational,
  // surfaced to the roles responsible for keeping the library current.
  if (current) {
    replacementAlert = `Replacement uploaded for "${course}". New classes will use ${template.versionLabel} automatically.`;
  }
  res.status(201).json({ template, replacementAlert });
});

// Explicit retire endpoint — blocks the version and raises the replacement alert.
router.post('/templates/:id/retire', requirePermission(PERM.UPLOAD_CHECKLIST), (req, res) => {
  const t = store.find('checklist_templates', x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Template not found' });
  store.update('checklist_templates', t.id, { status: 'retired', retiredAt: new Date().toISOString() });
  logAction(req.user, 'checklist_template.retire', { templateId: t.id, course: t.course });
  res.json({
    message: 'Version retired and blocked for new tests.',
    alert: `ACTION NEEDED: "${t.course}" has no active checklist. Upload and map a replacement before scheduling further classes.`,
  });
});

// ---- Submissions ----

// Start (or resume) a submission for a given enrollment.
router.post('/submissions', (req, res) => {
  const { enrollmentId } = req.body;
  const enrollment = store.find('enrollments', e => e.id === enrollmentId);
  if (!enrollment) return res.status(404).json({ error: 'Enrollment not found' });
  const cls = store.find('classes', c => c.id === enrollment.classId);
  const template = store.find('checklist_templates', t => t.id === cls.checklistTemplateId);
  if (template.status !== 'active') {
    return res.status(409).json({ error: 'This checklist version has been retired. Cannot start a new test against it.' });
  }

  let submission = store.find('checklist_submissions', s => s.enrollmentId === enrollmentId);
  if (submission) return res.json(submission);

  submission = {
    id: uuid(),
    enrollmentId, classId: cls.id, tenantId: cls.tenantId,
    templateId: template.id, templateVersion: template.versionLabel,
    marks: {}, notes: '', result: null,
    markedBy: null, markedRole: null,
    signature: null, signedInstructorId: null,
    locked: false, pdfPath: null,
    createdAt: new Date().toISOString(),
  };
  store.insert('checklist_submissions', submission);
  res.status(201).json(submission);
});

// Mark items — Instructor, Faculty, and IRF only (base teach_and_test permission).
router.patch('/submissions/:id', requirePermission(PERM.TEACH_AND_TEST), (req, res) => {
  const sub = store.find('checklist_submissions', s => s.id === req.params.id);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });
  if (sub.locked) return res.status(409).json({ error: 'This record is signed and locked. Corrections require a formal amendment.' });

  const { marks, notes, result } = req.body;
  const updated = store.update('checklist_submissions', sub.id, {
    marks: marks ?? sub.marks,
    notes: notes ?? sub.notes,
    result: result ?? sub.result,
    markedBy: req.user.id,
    markedRole: req.user.role,
  });
  res.json(updated);
});

/**
 * Sign and lock a submission. Flattens the checklist and marks into a PDF
 * (the production version overlays these marks onto the uploaded scan of
 * the real AHA sheet at its mapped field positions; this prototype renders
 * the equivalent content directly since no scanned source image is loaded
 * here) and stores it as the immutable record.
 */
router.post('/submissions/:id/sign', requireAuth, async (req, res) => {
  const sub = store.find('checklist_submissions', s => s.id === req.params.id);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });
  if (sub.locked) return res.status(409).json({ error: 'Already signed and locked.' });
  if (!['instructor', 'faculty', 'irf'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only Instructor, Faculty, or IRF may sign a submission.' });
  }
  if (!sub.result) return res.status(422).json({ error: 'A result (PASS or NR) is required before signing.' });

  const { instructorId, signatureDataUrl } = req.body;
  const template = store.find('checklist_templates', t => t.id === sub.templateId);
  const enrollment = store.find('enrollments', e => e.id === sub.enrollmentId);
  const student = store.find('students', s => s.id === enrollment.studentId);

  const pdfBytes = await renderChecklistPdf({ template, sub, student, signerName: req.user.name, instructorId });
  const filename = `${sub.id}.pdf`;
  fs.writeFileSync(path.join(SIGNED_DIR, filename), pdfBytes);

  const updated = store.update('checklist_submissions', sub.id, {
    locked: true,
    signature: signatureDataUrl ? 'captured' : 'digital-id-only',
    signedInstructorId: instructorId || null,
    signedBy: req.user.id,
    signedRole: req.user.role,
    signedAt: new Date().toISOString(),
    pdfPath: `/uploads/signed/${filename}`,
  });
  logAction(req.user, 'checklist_submission.sign', { submissionId: sub.id, studentId: student.id, result: sub.result });
  res.json(updated);
});

router.get('/submissions/:id', requireAuth, (req, res) => {
  const sub = store.find('checklist_submissions', s => s.id === req.params.id);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });
  res.json(sub);
});

async function renderChecklistPdf({ template, sub, student, signerName, instructorId }) {
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  let page = doc.addPage([612, 792]);
  let y = 750;

  const draw = (text, opts = {}) => {
    if (y < 60) { page = doc.addPage([612, 792]); y = 750; }
    page.drawText(text, { x: opts.x ?? 56, y, size: opts.size ?? 10, font: opts.bold ? bold : font, color: rgb(0, 0, 0) });
    y -= opts.gap ?? 16;
  };

  draw(`${template.course} — Skills Testing Checklist`, { size: 15, bold: true, gap: 22 });
  draw(`Template version: ${template.versionLabel}    Record ID: ${sub.id}`, { size: 8, gap: 18 });
  draw(`Student: ${student.name}`, { bold: true });
  draw(`Result: ${sub.result}`, { bold: true, gap: 22 });

  for (const section of template.sections) {
    draw(section.title, { bold: true, size: 11, gap: 16 });
    for (const item of section.items) {
      const checked = !!sub.marks[item.id];
      draw(`${checked ? '[X]' : '[ ]'} ${item.main}`, { x: 66, size: 9.5 });
    }
    y -= 6;
  }

  if (sub.notes) {
    draw('Instructor notes:', { bold: true, gap: 14 });
    draw(sub.notes, { size: 9 });
  }

  y -= 10;
  draw(`Signed by: ${signerName}    Instructor ID: ${instructorId || 'N/A'}`, { bold: true });
  draw(`Signed at: ${new Date().toISOString()}`, { size: 8 });
  draw('This is an immutable signed record. Corrections require a formal amendment.', { size: 8 });

  return doc.save();
}

module.exports = router;
