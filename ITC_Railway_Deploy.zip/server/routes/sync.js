/**
 * Sync bridge to the existing enroll.itc.org.pk registration site.
 *
 * Runs alongside the legacy site rather than replacing it. Two directions:
 *   INBOUND  — legacy site posts new registrations here as they happen.
 *   OUTBOUND — this platform can push class/seat availability back to the
 *              legacy site's calendar, so both stay in step.
 *
 * The legacy site is ASP.NET (enroll.itc.org.pk/calender.aspx). Since its
 * own API is unknown from the outside, this module exposes a documented
 * inbound webhook now, and an outbound push function with the exact
 * request shape to complete once the legacy site's own endpoint
 * (or a small bridge script installed on it) is available.
 */
const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { logAction } = require('../lib/audit');
const { rateLimit } = require('../lib/rateLimit');

const router = express.Router();

const SYNC_TOKEN_RATE_LIMITED = rateLimit(30, 60_000, 'sync requests');

// §8.1 — same reasoning as JWT_SECRET: no hardcoded fallback for a
// credential that gates inbound writes of student PII (CNIC/passport
// numbers) from the legacy site.
if (!process.env.LEGACY_SYNC_TOKEN) {
  throw new Error('LEGACY_SYNC_TOKEN must be set. Refusing to start with a default sync token (see .env.example).');
}
const SYNC_TOKEN = process.env.LEGACY_SYNC_TOKEN;

function requireSyncToken(req, res, next) {
  if (req.headers['x-sync-token'] !== SYNC_TOKEN) {
    return res.status(401).json({ error: 'Invalid sync token' });
  }
  next();
}

/**
 * INBOUND — legacy enroll.itc.org.pk registration form posts here.
 * Expected fields mirror the live form: course, location, tentativeDate,
 * name, cnicOrPassport, phone, email, mailingAddress, discountCode.
 */
router.post('/inbound/registration', SYNC_TOKEN_RATE_LIMITED, requireSyncToken, (req, res) => {
  const { course, location, tentativeDate, name, cnicOrPassport, phone, email, mailingAddress, discountCode } = req.body;

  const record = {
    id: uuid(), source: 'enroll.itc.org.pk', course, location, tentativeDate,
    name, cnicOrPassport, phone, email, mailingAddress, discountCode: discountCode || null,
    receivedAt: new Date().toISOString(), status: 'pending_match',
  };
  store.insert('sync_log', record);
  logAction({ id: null, role: 'system', name: 'Legacy sync' }, 'sync.inbound_registration', { syncId: record.id, course });
  res.status(202).json({ message: 'Registration received, queued for matching to a scheduled class.', syncId: record.id });
});

// Staff review queue for inbound legacy registrations awaiting a matching class.
router.get('/inbound/pending', require('../lib/auth').requireAuth, (req, res) => {
  res.json(store.filter('sync_log', r => r.status === 'pending_match'));
});

/**
 * OUTBOUND — push current seat availability to the legacy site's calendar.
 * Documents the exact payload shape; completing the HTTP call requires
 * an endpoint or bridge script on the enroll.itc.org.pk side to receive it.
 */
async function pushAvailability(classRecord) {
  const payload = {
    course: classRecord.course,
    site: classRecord.siteId,
    date: classRecord.date,
    time: classRecord.time,
    status: classRecord.status,
  };
  const legacyEndpoint = process.env.LEGACY_CALENDAR_ENDPOINT;
  if (!legacyEndpoint) {
    return { status: 'sandbox', note: 'LEGACY_CALENDAR_ENDPOINT not configured; payload logged only.', payload };
  }
  // const res = await fetch(legacyEndpoint, { method: 'POST', headers: {...}, body: JSON.stringify(payload) });
  throw new Error('Outbound push requires LEGACY_CALENDAR_ENDPOINT to be reachable and confirmed.');
}

router.post('/outbound/push/:classId', require('../lib/auth').requireAuth, async (req, res) => {
  const cls = store.find('classes', c => c.id === req.params.classId);
  if (!cls) return res.status(404).json({ error: 'Class not found' });
  const result = await pushAvailability(cls);
  res.json(result);
});

module.exports = router;
