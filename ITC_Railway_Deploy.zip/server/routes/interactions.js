const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth } = require('../lib/auth');
const { logAction } = require('../lib/audit');

const router = express.Router();

// In-memory "online" presence for the demo — a real deployment would
// track this via active session heartbeats.
const onlineHelplineAgents = new Set();

router.post('/presence', requireAuth, (req, res) => {
  if (req.user.role !== 'helpline_agent') return res.status(403).json({ error: 'Only Helpline Agents set presence.' });
  if (req.body.online) onlineHelplineAgents.add(req.user.id);
  else onlineHelplineAgents.delete(req.user.id);
  res.json({ online: [...onlineHelplineAgents] });
});

let rrCursor = 0;

/**
 * Assigns an incoming contact to a handler: round-robin across whichever
 * Helpline Agents are currently online plus the tenant's Agentic AI.
 * Agentic AI is always eligible, so if no human agent is online it
 * becomes the sole handler by necessity rather than by rotation.
 */
router.post('/contact', requireAuth, (req, res) => {
  const { channel } = req.body;
  // Tenant context is always resolved from the authenticated session,
  // never from the request body — see spec §7.1 (application-layer
  // isolation). A client-supplied tenantId here would let any caller
  // route contacts into another tenant's helpline queue.
  const tenantId = req.user.tenantId;
  const humanAgents = store.filter('users', u => u.role === 'helpline_agent' && u.tenantId === tenantId && onlineHelplineAgents.has(u.id));
  const ai = store.find('users', u => u.role === 'agentic_ai' && u.tenantId === tenantId);

  const pool = [...humanAgents, ...(ai ? [ai] : [])];
  if (pool.length === 0) return res.status(503).json({ error: 'No handler available for this tenant.' });

  rrCursor = (rrCursor + 1) % pool.length;
  const handler = pool[rrCursor];

  const record = {
    id: uuid(), tenantId, channel,
    handlerId: handler.id, handlerName: handler.name,
    handlerType: handler.role === 'agentic_ai' ? 'ai' : 'human_agent',
    reason: humanAgents.length === 0 ? 'no_human_online' : 'round_robin',
    startedAt: new Date().toISOString(),
  };
  store.insert('interactions', record);
  logAction({ id: null, role: 'system', name: 'Router' }, 'interaction.assign', record);
  res.status(201).json(record);
});

router.get('/', requireAuth, (req, res) => {
  const isPlatform = ['super_admin', 'admin'].includes(req.user.role);
  res.json(store.filter('interactions', i => isPlatform || i.tenantId === req.user.tenantId));
});

module.exports = router;
