const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { signToken } = require('../lib/auth');
const { ROLES } = require('../lib/roles');
const { rateLimit } = require('../lib/rateLimit');

const router = express.Router();

// §8.5 — brute-force protection on the login endpoint: 10 attempts per
// 5 minutes per source IP. Deliberately looser than a typical single-user
// login limiter since this IP-based limit is shared by every account
// signing in from behind the same NAT/office network.
router.post('/login', rateLimit(10, 5 * 60_000, 'login attempts'), (req, res) => {
  const { email, password } = req.body;
  const user = store.find('users', u => u.email === email);
  if (!user) return res.status(401).json({ error: 'No account with that email' });
  if (!bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect password' });
  }
  const token = signToken(user);
  res.json({
    token,
    user: { id: user.id, name: user.name, role: user.role, tenantId: user.tenantId, siteId: user.siteId || null },
  });
});

// One-time seed of a demo tenant with one account per role, for evaluation.
// §8.1/§8.4 — this intentionally returns plaintext demo passwords, so it
// must never be reachable outside local evaluation. Refuses to run
// unless NODE_ENV is explicitly 'development' or unset, so a deployment
// that sets NODE_ENV=production (as any real deployment should) gets
// this route hard-disabled rather than relying on someone remembering
// to delete it before shipping.
router.post('/seed-demo', (req, res) => {
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ error: 'Not found' });
  }
  if (store.all('tenants').length > 0) {
    return res.json({ message: 'Demo data already seeded', accounts: demoAccountList() });
  }
  const tenantId = uuid();
  store.insert('tenants', {
    id: tenantId, name: 'ITC Pakistan (demo tenant)', status: 'active',
    subscription: { plan: 'flat', trialEndsAt: addDays(30), status: 'trial' },
    createdAt: new Date().toISOString(),
  });
  const siteId = uuid();
  store.insert('sites', { id: siteId, tenantId, name: 'Islamabad Training Site' });

  const pass = bcrypt.hashSync('demo1234', 8);
  const accounts = [
    { role: ROLES.SUPER_ADMIN, name: 'Sana (Super Admin)', tenantId: null },
    { role: ROLES.ADMIN, name: 'Bilal (Admin)', tenantId: null },
    { role: ROLES.TCC, name: 'Ahmed (TCC)', tenantId },
    { role: ROLES.TCA, name: 'Hina (TCA)', tenantId },
    { role: ROLES.FACULTY, name: 'Dr. Farah (Faculty/TCF)', tenantId },
    { role: ROLES.INSTRUCTOR, name: 'Usman (Instructor)', tenantId },
    { role: ROLES.TSC, name: 'Zara (TSC)', tenantId, siteId },
    { role: ROLES.TSA, name: 'Omar (TSA)', tenantId, siteId },
    { role: ROLES.HELPLINE_AGENT, name: 'Ayesha (Helpline Agent)', tenantId },
    { role: ROLES.AGENTIC_AI, name: 'Agentic AI', tenantId },
    { role: ROLES.ACCOUNTANT, name: 'Kamran (Accountant)', tenantId },
    { role: ROLES.IRF, name: 'Dr. Nadia (IRF)', tenantId: null },
  ];
  for (const a of accounts) {
    store.insert('users', {
      id: uuid(), email: `${a.role}@demo.itc.org.pk`, passwordHash: pass,
      name: a.name, role: a.role, tenantId: a.tenantId, siteId: a.siteId || null,
      createdAt: new Date().toISOString(),
    });
  }

  // Seed the two real AHA checklist templates extracted earlier in this project.
  const { ADULT_CPR_AED, INFANT_CPR } = require('../db/seed-checklists');
  for (const tpl of [ADULT_CPR_AED, INFANT_CPR]) {
    store.insert('checklist_templates', {
      id: uuid(), tenantId, course: tpl.course, versionLabel: tpl.versionLabel,
      effectiveDate: new Date().toISOString(), status: 'active', sections: tpl.sections,
      uploadedBy: 'seed',
    });
  }

  res.json({ message: 'Demo tenant and accounts created', accounts: demoAccountList() });
});

function demoAccountList() {
  return store.all('users').map(u => ({ email: u.email, role: u.role, password: 'demo1234' }));
}

function addDays(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString();
}

module.exports = router;
