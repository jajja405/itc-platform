const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth } = require('../lib/auth');
const { logAction } = require('../lib/audit');

const router = express.Router();
router.use(requireAuth);

function requirePlatform(req, res, next) {
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Platform administration only.' });
  }
  next();
}

// A caller may act on their own tenant, or (if platform staff) on any
// tenant. Non-platform roles are hard-blocked from reading/writing any
// tenantId other than their own session's — this is the application-layer
// half of §7.1 isolation.
function requireOwnTenantOrPlatform(req, res, next) {
  const isPlatform = ['super_admin', 'admin'].includes(req.user.role);
  if (isPlatform || req.user.tenantId === req.params.id) return next();
  return res.status(403).json({ error: 'Not authorised for this tenant.' });
}

function addDays(n) {
  const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString();
}

// Default fair-use quotas (§7.4). Generous by default, adjustable per
// subscription tier; visible to the tenant via GET /:id.
const DEFAULT_QUOTAS = {
  apiRequestsPerMinute: 300,
  notificationsPerDay: 5000,
  storageMb: 20000,
  bulkExportsPerDay: 20,
};

/**
 * §7.5 Operator access governance — every platform-admin read or write of
 * a tenant's operational/financial data must cite a reason and, where the
 * access is support-driven, a ticket reference. The record is written to
 * both the general audit log (internal) and a dedicated operator access
 * log that is exposed back to the tenant in their own console
 * (GET /:id/access-log) so the wall is independently verifiable by the
 * tenant, not just asserted internally.
 */
function logOperatorAccess(actor, tenantId, reason, ticketRef, action) {
  const entry = {
    id: uuid(), tenantId, actorId: actor.id, actorName: actor.name,
    reason, ticketRef: ticketRef || null, action,
    at: new Date().toISOString(),
  };
  store.insert('operator_access_log', entry);
  logAction(actor, 'tenant.operator_access', { tenantId, reason, ticketRef, action });
  return entry;
}

// ---- List / read ----------------------------------------------------

router.get('/', requirePlatform, (req, res) => res.json(store.all('tenants')));

// Platform-wide chain integrity check — every tenant chain plus the
// shared 'platform' chain. §8.3 requires alteration/deletion be
// detectable; this is the operational check for that.
router.get('/audit-log/verify-all', requirePlatform, (req, res) => {
  const { verifyAllChains } = require('../lib/audit');
  res.json(verifyAllChains());
});

router.get('/:id', requireOwnTenantOrPlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });

  const isPlatform = ['super_admin', 'admin'].includes(req.user.role);
  if (isPlatform && req.user.tenantId !== req.params.id) {
    // A platform admin viewing a tenant that isn't their own operating
    // tenant must supply a reason; billing/legal/support-ticket access
    // is logged and surfaced to the tenant per §7.5.
    const { reason, ticketRef } = req.query;
    if (!reason) {
      return res.status(400).json({
        error: 'reason is required when platform staff access another tenant\'s data (§7.5).',
      });
    }
    logOperatorAccess(req.user, tenant.id, reason, ticketRef, 'view_tenant');
  }
  res.json(tenant);
});

// The tenant's own transparency log — every operator access to their data,
// visible inside their own console. §7.5.
router.get('/:id/access-log', requireOwnTenantOrPlatform, (req, res) => {
  res.json(store.filter('operator_access_log', l => l.tenantId === req.params.id));
});

// §8.3 "Access" — tenants see their own audit entries; platform-level
// entries are visible only to Super Admin/Admin. Reuses the same chain
// key the audit log groups by, so this is exactly the chain a tenant
// (or the platform) can independently verify via verifyChain().
router.get('/:id/audit-log', requireOwnTenantOrPlatform, (req, res) => {
  res.json(store.filter('audit_log', e => e.chainKey === req.params.id));
});

router.get('/:id/audit-log/verify', requireOwnTenantOrPlatform, (req, res) => {
  const { verifyChain } = require('../lib/audit');
  res.json(verifyChain(req.params.id));
});

// ---- Onboarding (§7.2) ----------------------------------------------

/**
 * Guided onboarding as a single resource with a status field rather than
 * a fire-and-forget create, so the wizard's steps (profile, branding, TCC
 * account, gateway config, checklist library init, sandbox class) can be
 * tracked and resumed instead of assumed complete on tenant creation.
 */
router.post('/', requirePlatform, (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });

  const tenant = {
    id: uuid(), name, status: 'onboarding',
    subscription: { plan: 'flat', rateOverride: null, trialEndsAt: addDays(30), status: 'trial' },
    branding: { logoUrl: null, primaryColor: null, secondaryColor: null, subdomain: null },
    quotas: { ...DEFAULT_QUOTAS },
    onboarding: {
      profileComplete: true, // name given at creation
      brandingComplete: false,
      tccAccountComplete: false,
      gatewayConfigComplete: false,
      checklistLibraryComplete: false,
      sandboxClassComplete: false,
    },
    createdAt: new Date().toISOString(),
    terminatedAt: null,
    deletionDueAt: null,
  };
  store.insert('tenants', tenant);
  logAction(req.user, 'tenant.create', { tenantId: tenant.id, name });
  res.status(201).json(tenant);
});

router.patch('/:id/onboarding', requirePlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });

  const allowedSteps = [
    'profileComplete', 'brandingComplete', 'tccAccountComplete',
    'gatewayConfigComplete', 'checklistLibraryComplete', 'sandboxClassComplete',
  ];
  const patch = {};
  for (const step of allowedSteps) {
    if (typeof req.body[step] === 'boolean') patch[step] = req.body[step];
  }
  const onboarding = { ...tenant.onboarding, ...patch };
  const allDone = allowedSteps.every(s => onboarding[s]);
  const updated = store.update('tenants', tenant.id, {
    onboarding,
    status: allDone ? 'active' : tenant.status,
  });
  logAction(req.user, 'tenant.onboarding_step', { tenantId: tenant.id, patch, allDone });
  res.json(updated);
});

// ---- White-labelling (§7.3) ------------------------------------------

router.patch('/:id/branding', requireOwnTenantOrPlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });

  const { logoUrl, primaryColor, secondaryColor, subdomain } = req.body;

  if (subdomain) {
    const taken = store.find('tenants', t => t.id !== tenant.id && t.branding?.subdomain === subdomain);
    if (taken) return res.status(409).json({ error: 'Subdomain already in use by another tenant.' });
  }

  const branding = {
    ...tenant.branding,
    ...(logoUrl !== undefined && { logoUrl }),
    ...(primaryColor !== undefined && { primaryColor }),
    ...(secondaryColor !== undefined && { secondaryColor }),
    ...(subdomain !== undefined && { subdomain }),
  };
  const updated = store.update('tenants', tenant.id, {
    branding,
    onboarding: { ...tenant.onboarding, brandingComplete: true },
  });
  logAction(req.user, 'tenant.branding_update', { tenantId: tenant.id, branding });
  res.json(updated);
});

// Public, unauthenticated lookup so the public calendar / registration
// pages / student portal can resolve a subdomain to its tenant's brand.
// Deliberately returns branding only — no operational or financial data.
router.get('/by-subdomain/:subdomain', (req, res) => {
  const tenant = store.find('tenants', t => t.branding?.subdomain === req.params.subdomain && t.status === 'active');
  if (!tenant) return res.status(404).json({ error: 'No active tenant for this subdomain.' });
  res.json({ id: tenant.id, name: tenant.name, branding: tenant.branding });
});

// ---- Quotas (§7.4) -----------------------------------------------------

router.patch('/:id/quotas', requirePlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });
  const { apiRequestsPerMinute, notificationsPerDay, storageMb, bulkExportsPerDay } = req.body;
  const quotas = {
    ...tenant.quotas,
    ...(apiRequestsPerMinute !== undefined && { apiRequestsPerMinute }),
    ...(notificationsPerDay !== undefined && { notificationsPerDay }),
    ...(storageMb !== undefined && { storageMb }),
    ...(bulkExportsPerDay !== undefined && { bulkExportsPerDay }),
  };
  const updated = store.update('tenants', tenant.id, { quotas });
  logAction(req.user, 'tenant.quota_update', { tenantId: tenant.id, quotas });
  res.json(updated);
});

// ---- Suspension / reactivation (§7.2) -----------------------------------

router.patch('/:id/suspend', requirePlatform, (req, res) => {
  const t = store.update('tenants', req.params.id, { status: 'suspended' });
  if (!t) return res.status(404).json({ error: 'Tenant not found' });
  logAction(req.user, 'tenant.suspend', { tenantId: t.id });
  res.json(t);
});

router.patch('/:id/reactivate', requirePlatform, (req, res) => {
  const t = store.update('tenants', req.params.id, { status: 'active' });
  if (!t) return res.status(404).json({ error: 'Tenant not found' });
  logAction(req.user, 'tenant.reactivate', { tenantId: t.id });
  res.json(t);
});

// ---- Offboarding & deletion (§7.2) --------------------------------------

/**
 * Termination starts the clock on two independent windows:
 *  - a 30-day export window (the tenant can pull their JSON/CSV export)
 *  - a 90-day deletion window, after which non-retained data is purged
 * Records under AHA's 3-year retention or an active legal hold are
 * excluded from deletion and archived/access-restricted instead — see
 * the retention check in the deletion endpoint below.
 */
router.patch('/:id/terminate', requirePlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });
  const terminatedAt = new Date().toISOString();
  const updated = store.update('tenants', tenant.id, {
    status: 'terminated',
    terminatedAt,
    deletionDueAt: addDays(90),
  });
  logAction(req.user, 'tenant.terminate', { tenantId: tenant.id, terminatedAt });
  res.json(updated);
});

router.get('/:id/export', requireOwnTenantOrPlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });
  if (tenant.status === 'terminated' && new Date(tenant.terminatedAt) < new Date(Date.now() - 30 * 86400000)) {
    return res.status(410).json({ error: 'The 30-day post-termination export window has closed.' });
  }

  const collections = [
    'classes', 'students', 'enrollments', 'checklist_submissions',
    'complaints', 'ledger_course_fees', 'ledger_subscription',
  ];
  const exportData = {};
  for (const c of collections) {
    exportData[c] = store.filter(c, r => r.tenantId === tenant.id);
  }
  logAction(req.user, 'tenant.export', { tenantId: tenant.id, collections });
  res.json({ tenant: { id: tenant.id, name: tenant.name }, exportedAt: new Date().toISOString(), data: exportData });
});

// Names of records that must survive the 90-day purge: anything still
// inside the AHA 3-year retention window, or under an active legal hold.
// This mirrors the retention rule already enforced on checklist
// submissions; deletion here defers to that same flag rather than
// re-deriving it, so the two can never drift apart.
function isRetained(record) {
  if (record.legalHold) return true;
  if (record.ahaRetainUntil && new Date(record.ahaRetainUntil) > new Date()) return true;
  return false;
}

router.delete('/:id/purge', requirePlatform, (req, res) => {
  const tenant = store.find('tenants', t => t.id === req.params.id);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });
  if (tenant.status !== 'terminated') {
    return res.status(409).json({ error: 'Tenant must be terminated before deletion.' });
  }
  if (new Date(tenant.deletionDueAt) > new Date()) {
    return res.status(409).json({
      error: `Deletion not yet due. Eligible from ${tenant.deletionDueAt} (90 days post-termination).`,
    });
  }

  const collections = ['classes', 'students', 'enrollments', 'checklist_submissions', 'complaints'];
  const summary = {};
  for (const c of collections) {
    const all = store.all(c);
    const toDelete = all.filter(r => r.tenantId === tenant.id && !isRetained(r));
    const retained = all.filter(r => r.tenantId === tenant.id && isRetained(r));
    for (const r of toDelete) store.remove(c, r.id);
    summary[c] = { deleted: toDelete.length, retainedUnderHold: retained.length };
  }
  const updated = store.update('tenants', tenant.id, { status: 'deleted' });
  logAction(req.user, 'tenant.purge', { tenantId: tenant.id, summary });
  res.json({ tenant: updated, summary });
});

module.exports = router;
