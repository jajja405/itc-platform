/**
 * Platform/tenant-admin surface for managing Partner API credentials and
 * webhook subscriptions. This is session-authenticated (JWT, like every
 * other internal route) — distinct from routes/partner.js, which is the
 * key-authenticated surface partners actually call.
 */
const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth } = require('../lib/auth');
const { logAction } = require('../lib/audit');
const { generateApiKey } = require('../lib/partnerAuth');

const router = express.Router();
router.use(requireAuth);

const VALID_SCOPES = ['bookings:read', 'bookings:write', 'roster:read', 'certificates:read', 'webhooks:manage'];

function requireTenantAdmin(req, res, next) {
  const allowed = ['super_admin', 'admin', 'tcc', 'tca'];
  if (!allowed.includes(req.user.role)) {
    return res.status(403).json({ error: 'Only tenant or platform administrators manage Partner API credentials.' });
  }
  next();
}

// ---- API keys ------------------------------------------------------

router.get('/keys', requireTenantAdmin, (req, res) => {
  const isPlatform = ['super_admin', 'admin'].includes(req.user.role);
  const keys = store.filter('partner_api_keys', k => isPlatform || k.tenantId === req.user.tenantId);
  // Never return the hash or raw key on list/read — only at creation time.
  res.json(keys.map(({ keyHash, ...safe }) => safe));
});

router.post('/keys', requireTenantAdmin, (req, res) => {
  const { label, scopes, sandbox } = req.body;
  const requestedScopes = Array.isArray(scopes) ? scopes : [];
  const invalid = requestedScopes.filter(s => !VALID_SCOPES.includes(s));
  if (invalid.length) {
    return res.status(400).json({ error: `Unknown scope(s): ${invalid.join(', ')}`, validScopes: VALID_SCOPES });
  }

  const { raw, hash } = generateApiKey();
  const record = {
    id: uuid(), tenantId: req.user.tenantId, label: label || 'Untitled key',
    keyHash: hash, scopes: requestedScopes, sandbox: !!sandbox,
    revoked: false, createdBy: req.user.id, createdAt: new Date().toISOString(),
  };
  store.insert('partner_api_keys', record);
  logAction(req.user, 'partner_key.create', { keyId: record.id, scopes: requestedScopes, sandbox: record.sandbox });

  // The raw key is shown exactly once, at creation — it cannot be
  // retrieved again, matching standard API-key issuance practice.
  const { keyHash, ...safe } = record;
  res.status(201).json({ ...safe, apiKey: raw });
});

router.patch('/keys/:id/revoke', requireTenantAdmin, (req, res) => {
  const key = store.find('partner_api_keys', k => k.id === req.params.id);
  if (!key) return res.status(404).json({ error: 'Key not found' });
  if (!['super_admin', 'admin'].includes(req.user.role) && key.tenantId !== req.user.tenantId) {
    return res.status(403).json({ error: 'Not authorised for this key.' });
  }
  const updated = store.update('partner_api_keys', key.id, { revoked: true, revokedAt: new Date().toISOString() });
  logAction(req.user, 'partner_key.revoke', { keyId: key.id });
  const { keyHash, ...safe } = updated;
  res.json(safe);
});

// ---- Webhook subscriptions -------------------------------------------

router.get('/webhooks', requireTenantAdmin, (req, res) => {
  const isPlatform = ['super_admin', 'admin'].includes(req.user.role);
  res.json(store.filter('webhook_subscriptions', s => isPlatform || s.tenantId === req.user.tenantId));
});

router.post('/webhooks', requireTenantAdmin, (req, res) => {
  const { url, events } = req.body;
  if (!url || !Array.isArray(events) || events.length === 0) {
    return res.status(400).json({ error: 'url and a non-empty events array are required.' });
  }
  const sub = {
    id: uuid(), tenantId: req.user.tenantId, url, events,
    secret: `whsec_${uuid().replace(/-/g, '')}`,
    active: true, createdBy: req.user.id, createdAt: new Date().toISOString(),
  };
  store.insert('webhook_subscriptions', sub);
  logAction(req.user, 'webhook.subscribe', { subscriptionId: sub.id, url, events });
  res.status(201).json(sub);
});

router.patch('/webhooks/:id/deactivate', requireTenantAdmin, (req, res) => {
  const sub = store.find('webhook_subscriptions', s => s.id === req.params.id);
  if (!sub) return res.status(404).json({ error: 'Subscription not found' });
  const updated = store.update('webhook_subscriptions', sub.id, { active: false });
  logAction(req.user, 'webhook.deactivate', { subscriptionId: sub.id });
  res.json(updated);
});

// Redelivery console (§11.2) — list a subscription's deliveries and
// manually retry one.
router.get('/webhooks/:id/deliveries', requireTenantAdmin, (req, res) => {
  res.json(store.filter('webhook_deliveries', d => d.subscriptionId === req.params.id));
});

router.post('/webhooks/deliveries/:deliveryId/redeliver', requireTenantAdmin, (req, res) => {
  const { redeliver } = require('../lib/webhooks');
  const delivery = redeliver(req.params.deliveryId);
  if (!delivery) return res.status(404).json({ error: 'Delivery not found' });
  logAction(req.user, 'webhook.redeliver', { deliveryId: delivery.id });
  res.json({ status: 'redelivery_triggered', deliveryId: delivery.id });
});

module.exports = router;
