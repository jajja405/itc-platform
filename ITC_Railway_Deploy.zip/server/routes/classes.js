const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth, requirePermission } = require('../lib/auth');
const { PERM } = require('../lib/roles');
const { logAction } = require('../lib/audit');

const router = express.Router();
router.use(requireAuth);

// List classes visible to this user's tenant (Super Admin/Admin see all tenants).
router.get('/', (req, res) => {
  const { role, tenantId } = req.user;
  const isPlatform = role === 'super_admin' || role === 'admin';
  const classes = store.filter('classes', c => isPlatform || c.tenantId === tenantId);
  res.json(classes);
});

// Create a class — TCC/TCA/Admin/Super Admin only, and must reference an
// active (non-retired) checklist template for the course.
router.post('/', requirePermission(PERM.CREATE_CLASS), (req, res) => {
  const { course, date, time, siteId, leadInstructorId, courseDirectorId } = req.body;
  const template = store.find('checklist_templates', t => t.course === course && t.status === 'active');
  if (!template) {
    return res.status(422).json({
      error: `No active checklist template for "${course}". A class cannot be created until one is uploaded and mapped.`,
    });
  }
  const cls = {
    id: uuid(),
    tenantId: req.user.tenantId,
    siteId: siteId || req.user.siteId || null,
    course, date, time,
    leadInstructorId: leadInstructorId || null,
    courseDirectorId: courseDirectorId || null,
    checklistTemplateId: template.id,
    status: 'scheduled',
    createdBy: req.user.id,
    createdAt: new Date().toISOString(),
  };
  store.insert('classes', cls);
  logAction(req.user, 'class.create', { classId: cls.id, course, date });
  res.status(201).json(cls);
});

// Reschedule an existing class only — cannot be used to create one.
router.patch('/:id/reschedule', requirePermission(PERM.RESCHEDULE_CLASS), (req, res) => {
  const { date, time } = req.body;
  const existing = store.find('classes', c => c.id === req.params.id);
  if (!existing) return res.status(404).json({ error: 'Class not found' });
  const updated = store.update('classes', existing.id, {
    date: date ?? existing.date,
    time: time ?? existing.time,
    rescheduledBy: req.user.id,
    rescheduledAt: new Date().toISOString(),
  });
  logAction(req.user, 'class.reschedule', {
    classId: existing.id, from: { date: existing.date, time: existing.time }, to: { date, time },
    handlerType: req.user.role === 'agentic_ai' ? 'ai' : (req.user.role === 'helpline_agent' ? 'human_agent' : 'staff'),
  });
  res.json(updated);
});

// Enroll a student into an already-scheduled class (booking, not creation).
router.post('/:id/enroll', requirePermission(PERM.ENROLL_STUDENT), (req, res) => {
  const { studentName, studentContact } = req.body;
  const cls = store.find('classes', c => c.id === req.params.id);
  if (!cls) return res.status(404).json({ error: 'Class not found' });

  let student = store.find('students', s => s.contact === studentContact && s.tenantId === cls.tenantId);
  if (!student) {
    student = store.insert('students', {
      id: uuid(), tenantId: cls.tenantId, name: studentName, contact: studentContact,
      createdAt: new Date().toISOString(),
    });
  }
  const enrollment = store.insert('enrollments', {
    id: uuid(), classId: cls.id, studentId: student.id, tenantId: cls.tenantId,
    bookedBy: req.user.id,
    handlerType: req.user.role === 'agentic_ai' ? 'ai' : (req.user.role === 'helpline_agent' ? 'human_agent' : 'staff'),
    bookedAt: new Date().toISOString(),
    status: 'enrolled',
  });
  logAction(req.user, 'enrollment.create', { classId: cls.id, studentId: student.id });
  res.status(201).json({ student, enrollment });
});

router.get('/:id/roster', requireAuth, (req, res) => {
  const cls = store.find('classes', c => c.id === req.params.id);
  if (!cls) return res.status(404).json({ error: 'Class not found' });
  const enrollments = store.filter('enrollments', e => e.classId === cls.id);
  const roster = enrollments.map(e => ({
    enrollment: e,
    student: store.find('students', s => s.id === e.studentId),
    checklistSubmission: store.find('checklist_submissions', sub => sub.enrollmentId === e.id) || null,
  }));
  res.json({ class: cls, roster });
});

module.exports = router;
