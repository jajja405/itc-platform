const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requireAuth, requirePermission } = require('../lib/auth');
const { PERM } = require('../lib/roles');
const { logAction } = require('../lib/audit');
const payment = require('../integrations/payment');

const router = express.Router();
router.use(requireAuth);

// ---- Course fee ledger (student -> tenant) ----
router.get('/course-fees', requirePermission(PERM.VIEW_FEES), (req, res) => {
  const isPlatform = ['super_admin', 'admin'].includes(req.user.role);
  res.json(store.filter('ledger_course_fees', l => isPlatform || l.tenantId === req.user.tenantId));
});

router.post('/course-fees', requirePermission(PERM.MANAGE_BILLING), async (req, res) => {
  const { enrollmentId, amount, currency, gateway } = req.body;
  const result = await payment.charge({ amount, currency, gateway, reference: enrollmentId });
  const entry = {
    id: uuid(), tenantId: req.user.tenantId, enrollmentId, amount, currency, gateway,
    status: result.status, gatewayReference: result.reference,
    recordedBy: req.user.id, at: new Date().toISOString(),
  };
  store.insert('ledger_course_fees', entry);
  logAction(req.user, 'ledger.course_fee', { entryId: entry.id, amount, status: result.status });
  res.status(201).json(entry);
});

// ---- Subscription ledger (tenant -> platform) ----
router.get('/subscriptions', requireAuth, (req, res) => {
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only Admin or Super Admin manage the subscription ledger.' });
  }
  res.json(store.all('ledger_subscription'));
});

router.post('/subscriptions/:tenantId/charge', requireAuth, async (req, res) => {
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only Admin or Super Admin may charge subscriptions.' });
  }
  const tenant = store.find('tenants', t => t.id === req.params.tenantId);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });
  if (new Date(tenant.subscription.trialEndsAt) > new Date()) {
    return res.status(409).json({ error: 'Tenant is still within its 30-day free trial.' });
  }
  const { amount, currency, gateway } = req.body;
  const result = await payment.charge({ amount, currency, gateway, reference: tenant.id });
  const entry = {
    id: uuid(), tenantId: tenant.id, amount, currency, gateway,
    status: result.status, gatewayReference: result.reference, at: new Date().toISOString(),
  };
  store.insert('ledger_subscription', entry);
  if (result.status !== 'success') {
    store.update('tenants', tenant.id, { status: 'suspended' });
    logAction(req.user, 'tenant.suspend_nonpayment', { tenantId: tenant.id });
  }
  logAction(req.user, 'ledger.subscription_charge', { entryId: entry.id, tenantId: tenant.id, status: result.status });
  res.status(201).json(entry);
});

// Admin override of the flat subscription rate for a specific tenant.
router.patch('/subscriptions/:tenantId/rate', requireAuth, (req, res) => {
  if (!['super_admin', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only Admin or Super Admin may override subscription rates.' });
  }
  const tenant = store.find('tenants', t => t.id === req.params.tenantId);
  if (!tenant) return res.status(404).json({ error: 'Tenant not found' });
  const updated = store.update('tenants', tenant.id, {
    subscription: { ...tenant.subscription, rateOverride: req.body.rate },
  });
  logAction(req.user, 'subscription.rate_override', { tenantId: tenant.id, rate: req.body.rate });
  res.json(updated);
});

module.exports = router;
