/**
 * Partner API v1 — third-party training centre integration (§11.3
 * "Partner API"). Key-authenticated (X-API-Key), scoped, rate-limited,
 * idempotent on writes, versioned path, one error envelope.
 *
 * Versioning contract (§11.2): this path (v1) is supported for at least
 * 12 months after a v2 ships, with deprecation announced via the
 * developer changelog and response headers — not implemented as code
 * here since no v2 exists yet, but the /v1/ prefix is deliberate so a
 * v2 can be added alongside it without breaking existing partners.
 */
const express = require('express');
const { v4: uuid } = require('uuid');
const store = require('../db/store');
const { requirePartnerAuth, requireScope, idempotent, rateLimit, errorEnvelope } = require('../lib/partnerAuth');
const { emitEvent } = require('../lib/webhooks');
const { logAction } = require('../lib/audit');

const router = express.Router();
router.use(requirePartnerAuth, rateLimit);

// Sandbox keys only ever see/affect data flagged `sandbox: true`, so
// partners can integrate against realistic responses without touching
// production records (§11.2 "Sandbox").
function scopedFilter(req, predicate) {
  return (record) => predicate(record) && !!record.sandbox === !!req.partner.sandbox;
}

// ---- Bookings ---------------------------------------------------------

router.get('/bookings', requireScope('bookings:read'), (req, res) => {
  const bookings = store.filter('enrollments', scopedFilter(req, e => e.tenantId === req.partner.tenantId));
  res.json({ data: bookings });
});

router.post('/bookings', requireScope('bookings:write'), idempotent, (req, res) => {
  const { classId, studentName, studentEmail, studentPhone } = req.body;
  if (!classId || !studentName) {
    return errorEnvelope(res, 422, 'invalid_request', 'classId and studentName are required.');
  }

  const cls = store.find('classes', c => c.id === classId && c.tenantId === req.partner.tenantId && !!c.sandbox === !!req.partner.sandbox);
  if (!cls) return errorEnvelope(res, 404, 'class_not_found', 'No such class for this tenant/environment.');

  const capacity = cls.capacity || 20;
  const currentCount = store.filter('enrollments', e => e.classId === classId && e.status !== 'cancelled').length;
  if (currentCount >= capacity) {
    return errorEnvelope(res, 409, 'class_full', 'This class has no remaining capacity.');
  }

  const student = {
    id: uuid(), tenantId: req.partner.tenantId, name: studentName,
    email: studentEmail || null, phone: studentPhone || null,
    sandbox: !!req.partner.sandbox, createdVia: 'partner_api', createdAt: new Date().toISOString(),
  };
  store.insert('students', student);

  const enrollment = {
    id: uuid(), tenantId: req.partner.tenantId, classId, studentId: student.id,
    status: 'confirmed', source: 'partner_api', partnerKeyId: req.partner.keyId,
    sandbox: !!req.partner.sandbox, createdAt: new Date().toISOString(),
  };
  store.insert('enrollments', enrollment);
  logAction({ id: req.partner.keyId, role: 'partner_api', name: 'Partner API' }, 'partner.booking_create', { enrollmentId: enrollment.id, classId });

  if (!req.partner.sandbox) emitEvent(req.partner.tenantId, 'booking.created', { enrollment, student });
  res.status(201).json({ data: enrollment });
});

router.post('/bookings/:id/reschedule', requireScope('bookings:write'), idempotent, (req, res) => {
  const { classId } = req.body;
  const existing = store.find('enrollments', e => e.id === req.params.id && e.tenantId === req.partner.tenantId);
  if (!existing) return errorEnvelope(res, 404, 'booking_not_found', 'No such booking for this tenant.');
  if (!classId) return errorEnvelope(res, 422, 'invalid_request', 'classId is required.');

  const newClass = store.find('classes', c => c.id === classId && c.tenantId === req.partner.tenantId);
  if (!newClass) return errorEnvelope(res, 404, 'class_not_found', 'Target class not found for this tenant.');

  const updated = store.update('enrollments', existing.id, {
    classId, status: 'rescheduled', rescheduledVia: 'partner_api', rescheduledAt: new Date().toISOString(),
  });
  logAction({ id: req.partner.keyId, role: 'partner_api', name: 'Partner API' }, 'partner.booking_reschedule', { enrollmentId: existing.id, from: existing.classId, to: classId });

  if (!req.partner.sandbox) emitEvent(req.partner.tenantId, 'booking.rescheduled', { enrollment: updated });
  res.json({ data: updated });
});

// ---- Roster / calendar (read-only) -------------------------------------

router.get('/classes', requireScope('roster:read'), (req, res) => {
  const classes = store.filter('classes', scopedFilter(req, c => c.tenantId === req.partner.tenantId && c.status === 'scheduled'));
  res.json({ data: classes });
});

router.get('/classes/:id/roster', requireScope('roster:read'), (req, res) => {
  const cls = store.find('classes', c => c.id === req.params.id && c.tenantId === req.partner.tenantId);
  if (!cls) return errorEnvelope(res, 404, 'class_not_found', 'No such class for this tenant.');
  const roster = store.filter('enrollments', e => e.classId === cls.id && e.status !== 'cancelled')
    .map(e => ({ enrollmentId: e.id, status: e.status, student: store.find('students', s => s.id === e.studentId) }));
  res.json({ data: roster });
});

// ---- Certificates (eCard verification, read-only) ----------------------

router.get('/certificates/:submissionId', requireScope('certificates:read'), (req, res) => {
  const submission = store.find('checklist_submissions', s => s.id === req.params.submissionId && s.tenantId === req.partner.tenantId);
  if (!submission) return errorEnvelope(res, 404, 'certificate_not_found', 'No such certificate for this tenant.');
  if (submission.status !== 'signed' && submission.status !== 'card_issued') {
    return errorEnvelope(res, 409, 'certificate_not_issued', 'This checklist has not been signed off yet.');
  }
  res.json({
    data: {
      submissionId: submission.id, course: submission.course,
      status: submission.status, signedAt: submission.signedAt || null,
      cardIssued: submission.status === 'card_issued',
    },
  });
});

module.exports = router;
