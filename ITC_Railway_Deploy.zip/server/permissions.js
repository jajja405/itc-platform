'use strict';
// Bridge: re-export the canonical permissions module from src/
module.exports = require('../src/permissions');
