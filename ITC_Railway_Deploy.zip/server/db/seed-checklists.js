// Real checklist content extracted from the uploaded AHA HeartCode BLS
// skills testing checklists earlier in this project.
const ADULT_CPR_AED = {
  course: 'Adult CPR and AED',
  versionLabel: 'AHA 2025 Guidelines',
  sections: [
    { title: 'Assessment and Activation', items: [
      { id: 'a_resp', main: 'Checks responsiveness' },
      { id: 'a_shout', main: 'Shouts for help / activates emergency response system / sends for AED' },
      { id: 'a_breath', main: 'Checks breathing' },
      { id: 'a_pulse', main: 'Checks pulse' },
    ]},
    { title: 'Cycle 1 of CPR (30:2)', items: [
      { id: 'a_comp1', main: 'Performs high-quality compressions (center of chest, 30 at 100-120/min, at least 5cm, full recoil)' },
      { id: 'a_breath1', main: 'Gives 2 breaths with barrier device (each over 1 sec, visible chest rise, resumes in <10 sec)' },
    ]},
    { title: 'Cycle 2 of CPR', items: [
      { id: 'a_comp2', main: 'Compressions' },
      { id: 'a_breath2', main: 'Breaths' },
      { id: 'a_resume2', main: 'Resumes compressions in less than 10 seconds' },
    ]},
    { title: 'AED', items: [
      { id: 'a_aed_on', main: 'Powers on AED' },
      { id: 'a_aed_pads', main: 'Correctly attaches pads' },
      { id: 'a_aed_analyze', main: 'Clears for analysis' },
      { id: 'a_aed_clear', main: 'Clears to safely deliver a shock' },
      { id: 'a_aed_shock', main: 'Safely delivers a shock' },
    ]},
    { title: 'Resumes Compressions', items: [
      { id: 'a_resume_final', main: 'Ensures compressions are resumed immediately after shock delivery' },
    ]},
  ],
};

const INFANT_CPR = {
  course: 'Infant CPR',
  versionLabel: 'AHA 2025 Guidelines',
  sections: [
    { title: 'Assessment and Activation', items: [
      { id: 'i_resp', main: 'Checks responsiveness' },
      { id: 'i_shout', main: 'Shouts for help / activates emergency response system' },
      { id: 'i_breath', main: 'Checks breathing' },
      { id: 'i_pulse', main: 'Checks pulse' },
    ]},
    { title: 'Cycle 1 of CPR (30:2)', items: [
      { id: 'i_comp1', main: 'Performs high-quality compressions (below nipple line, 30 in 15-18 sec, ~4cm, full recoil)' },
      { id: 'i_breath1', main: 'Gives 2 breaths with barrier device (each over 1 sec, visible chest rise, resumes in <10 sec)' },
    ]},
    { title: 'Cycle 2 of CPR', items: [
      { id: 'i_comp2', main: 'Compressions' },
      { id: 'i_breath2', main: 'Breaths' },
      { id: 'i_resume2', main: 'Resumes compressions in less than 10 seconds' },
    ]},
    { title: 'Cycle 3 of CPR - Rescuer 1 (2 thumb-encircling hands)', items: [
      { id: 'i_comp3', main: 'Performs high-quality compressions (15 in 7-9 sec, ~4cm, full recoil)' },
    ]},
  ],
};

module.exports = { ADULT_CPR_AED, INFANT_CPR };
