'use strict';
/**
 * server/db/index.js — DB interface layer for services.
 * In production this wraps PostgreSQL via pg Pool.
 * In tests, jest.mock() replaces this with an in-memory store.
 */
const store = require('./store');

async function withTenant(ctx, fn) {
  // In production: set RLS session vars, run in transaction
  // For now delegates to store's client handling
  return store.withTenant ? store.withTenant(ctx, fn) : fn(store);
}

async function audit(db, entry) {
  // Writes to audit_log via the db client
  if (db && db.query) {
    return db.query(
      `INSERT INTO audit_log (tenant_id, actor_id, actor_role, action, entity_type, entity_id, meta, row_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,encode(sha256(($4||now()::text)::bytea),'hex'))`,
      [entry.tenantId, entry.actorId, entry.actorRole || 'system',
       entry.action, entry.entityType, entry.entityId,
       JSON.stringify(entry.meta || {})]
    );
  }
}

async function writeAuditLog(db, entry) {
  return audit(db, entry);
}

function getPublicDb() {
  return store.publicClient || store;
}

module.exports = { withTenant, audit, writeAuditLog, getPublicDb };
