/**
 * Lightweight JSON-file data store.
 *
 * This is a prototype persistence layer only. Every read/write in the
 * application goes through this module, so swapping in a real database
 * (Postgres is recommended for production) means rewriting this file
 * only — no other module needs to change.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const COLLECTIONS = [
  'tenants', 'users', 'sites', 'classes', 'students', 'enrollments',
  'checklist_templates', 'checklist_submissions', 'complaints',
  'delegations', 'ledger_subscription', 'ledger_course_fees',
  'interactions', 'sync_log', 'audit_log',
  // Step 9 — multi-tenant surfaces + Partner API
  'operator_access_log', 'partner_api_keys', 'webhook_subscriptions',
  'webhook_deliveries', 'idempotency_keys',
];

const cache = {};

function fileFor(name) {
  return path.join(DATA_DIR, `${name}.json`);
}

function load(name) {
  if (cache[name]) return cache[name];
  const f = fileFor(name);
  if (fs.existsSync(f)) {
    cache[name] = JSON.parse(fs.readFileSync(f, 'utf8'));
  } else {
    cache[name] = [];
  }
  return cache[name];
}

function save(name) {
  fs.writeFileSync(fileFor(name), JSON.stringify(cache[name], null, 2));
}

for (const c of COLLECTIONS) load(c);

const store = {
  all(collection) {
    return load(collection);
  },
  find(collection, predicate) {
    return load(collection).find(predicate);
  },
  filter(collection, predicate) {
    return load(collection).filter(predicate);
  },
  insert(collection, doc) {
    const arr = load(collection);
    arr.push(doc);
    save(collection);
    return doc;
  },
  update(collection, id, patch) {
    const arr = load(collection);
    const idx = arr.findIndex(d => d.id === id);
    if (idx === -1) return null;
    arr[idx] = { ...arr[idx], ...patch };
    save(collection);
    return arr[idx];
  },
  remove(collection, id) {
    const arr = load(collection);
    const idx = arr.findIndex(d => d.id === id);
    if (idx === -1) return false;
    arr.splice(idx, 1);
    save(collection);
    return true;
  },
};

module.exports = store;
