require('dotenv').config({ quiet: true });
const express = require('express');
const cors = require('cors');
const path = require('path');
const { rateLimit } = require('./lib/rateLimit');


// Run database migrations on startup (Railway / production)
if (process.env.NODE_ENV === 'production' || process.env.RUN_MIGRATIONS === 'true') {
  const { execSync } = require('child_process');
  try {
    console.log('Running database migrations...');
    execSync('node scripts/migrate.js', {
      stdio: 'inherit',
      cwd: path.join(__dirname, '..'),
    });
    console.log('Migrations complete.');
  } catch(e) {
    console.error('Migration warning:', e.message);
  }
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));
app.use(express.static(path.join(__dirname, '..', 'public')));

// §8.5 — baseline rate limit across all API traffic. Auth and the legacy
// sync webhook have their own tighter, purpose-specific limits (see
// routes/auth.js and routes/sync.js); the Partner API has its own
// quota-driven limiter (lib/partnerAuth.js) since that one is scoped per
// API key rather than per IP. This is the floor for everything else.
app.use('/api', rateLimit(600, 60_000, 'API requests'));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/tenants', require('./routes/tenants'));
app.use('/api/classes', require('./routes/classes'));
app.use('/api/checklists', require('./routes/checklists'));
app.use('/api/complaints', require('./routes/complaints'));
app.use('/api/delegations', require('./routes/delegations'));
app.use('/api/billing', require('./routes/billing'));
app.use('/api/sync', require('./routes/sync'));
app.use('/api/interactions', require('./routes/interactions'));
app.use('/api/partner-admin', require('./routes/partnerAdmin'));
app.use('/api/v1/partner', require('./routes/partnerV1'));

// WhatsApp webhook verification handshake (Meta requirement).
app.get('/api/webhooks/whatsapp', (req, res) => {
  const challenge = require('./integrations/whatsapp').verifyWebhook(req.query);
  if (challenge) return res.send(challenge);
  res.sendStatus(403);
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`ITC platform API listening on port ${PORT}`));
