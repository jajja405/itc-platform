let state = { view: 'login', activeClassId: null, activeSubmissionId: null };

function toast(msg) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2500);
}

const NAV = {
  super_admin: [['dashboard', 'Dashboard'], ['tenants', 'Tenants'], ['classes', 'Classes'], ['complaints', 'Complaints'], ['delegations', 'Delegations'], ['billing', 'Billing'], ['sync', 'Legacy sync']],
  admin: [['dashboard', 'Dashboard'], ['tenants', 'Tenants'], ['classes', 'Classes'], ['complaints', 'Complaints'], ['delegations', 'Delegations'], ['billing', 'Billing'], ['sync', 'Legacy sync']],
  tcc: [['dashboard', 'Dashboard'], ['classes', 'Classes'], ['checklists', 'Checklist library'], ['complaints', 'Complaints'], ['billing', 'Fees']],
  tca: [['dashboard', 'Dashboard'], ['classes', 'Classes'], ['checklists', 'Checklist library'], ['complaints', 'Complaints'], ['billing', 'Fees']],
  faculty: [['dashboard', 'Dashboard'], ['classes', 'Classes']],
  instructor: [['dashboard', 'Dashboard'], ['classes', 'Classes']],
  tsc: [['dashboard', 'Dashboard'], ['classes', 'Classes'], ['complaints', 'Complaints']],
  tsa: [['dashboard', 'Dashboard'], ['classes', 'Classes'], ['complaints', 'Complaints']],
  helpline_agent: [['dashboard', 'Dashboard'], ['classes', 'Classes'], ['complaints', 'Complaints']],
  agentic_ai: [['dashboard', 'Dashboard'], ['classes', 'Classes'], ['complaints', 'Complaints']],
  accountant: [['dashboard', 'Dashboard'], ['billing', 'Billing']],
  irf: [['dashboard', 'Dashboard'], ['classes', 'Classes']],
};

async function render() {
  const app = document.getElementById('app');
  if (!API.token) { app.innerHTML = loginView(); bindLogin(); return; }

  app.innerHTML = `
    <div class="topbar">
      <div class="brand"><span class="brand-mark">ITC</span><strong>Platform</strong></div>
      <div class="who">${API.user.name} · ${API.user.role} <button class="btn btn-ghost" id="logout-btn" style="margin-left:14px;">Log out</button></div>
    </div>
    <div class="shell">
      <div class="sidebar" id="sidebar"></div>
      <div class="main" id="main">Loading…</div>
    </div>`;
  document.getElementById('logout-btn').onclick = () => { API.token = null; API.user = null; render(); };

  const nav = NAV[API.user.role] || [['dashboard', 'Dashboard']];
  document.getElementById('sidebar').innerHTML = nav.map(([key, label]) =>
    `<button class="nav-item ${state.view === key ? 'active' : ''}" data-view="${key}">${label}</button>`
  ).join('');
  document.querySelectorAll('[data-view]').forEach(b => b.onclick = () => { state.view = b.dataset.view; render(); });

  const views = {
    dashboard: viewDashboard, tenants: viewTenants, classes: viewClasses,
    checklists: viewChecklistLibrary, complaints: viewComplaints,
    delegations: viewDelegations, billing: viewBilling, sync: viewSync,
    checklistFill: viewChecklistFill,
  };
  await (views[state.view] || viewDashboard)();
}

function loginView() {
  return `
    <div class="login-wrap"><div class="login-card">
      <h1>ITC Platform</h1>
      <p class="subtitle">Sign in, or seed demo accounts for every role.</p>
      <div class="field"><label>Email</label><input id="email" value="tcc@demo.itc.org.pk"></div>
      <div class="field"><label>Password</label><input id="password" type="password" value="demo1234"></div>
      <button class="btn btn-primary" id="login-btn" style="width:100%;">Sign in</button>
      <button class="btn btn-ghost" id="seed-btn" style="width:100%;margin-top:8px;">Seed demo tenant + accounts</button>
      <div id="demo-accounts"></div>
    </div></div>`;
}

function bindLogin() {
  document.getElementById('login-btn').onclick = async () => {
    try {
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      const data = await API.post('/auth/login', { email, password });
      API.token = data.token; API.user = data.user;
      state.view = 'dashboard'; render();
    } catch (e) { toast(e.message); }
  };
  document.getElementById('seed-btn').onclick = async () => {
    try {
      const data = await API.post('/auth/seed-demo', {});
      document.getElementById('demo-accounts').innerHTML =
        '<div class="demo-list">' + data.accounts.map(a => `${a.role.padEnd(15)} ${a.email}  /  ${a.password}`).join('<br>') + '</div>';
      toast('Demo accounts ready — pick one above and sign in.');
    } catch (e) { toast(e.message); }
  };
}

// ---------------- DASHBOARD ----------------
async function viewDashboard() {
  const main = document.getElementById('main');
  main.innerHTML = `<h1>Dashboard</h1><div class="subtitle">Signed in as ${API.user.role}.</div><div id="dash-body">Loading…</div>`;
  const [classes, complaints] = await Promise.all([
    API.get('/classes').catch(() => []),
    API.get('/complaints').catch(() => []),
  ]);
  document.getElementById('dash-body').innerHTML = `
    <div class="card"><h2>Classes</h2><div>${classes.length} visible to your role</div></div>
    <div class="card"><h2>Complaints</h2><div>${complaints.filter(c => c.status === 'open').length} open of ${complaints.length}</div></div>
  `;
}

// ---------------- TENANTS ----------------
async function viewTenants() {
  const main = document.getElementById('main');
  const tenants = await API.get('/tenants');
  main.innerHTML = `
    <h1>Tenants</h1><div class="subtitle">Platform administration — each row is an isolated ITC.</div>
    <div class="card">
      <div class="field"><label>New tenant name</label><input id="tenant-name" placeholder="e.g. Lifesaver CPR, Karachi"></div>
      <button class="btn btn-primary" id="create-tenant">Create tenant</button>
    </div>
    <table><thead><tr><th>Name</th><th>Status</th><th>Trial ends</th><th>Rate override</th><th></th></tr></thead>
    <tbody>${tenants.map(t => `<tr>
      <td>${t.name}</td>
      <td><span class="pill ${t.status === 'active' ? 'pill-active' : 'pill-nr'}">${t.status}</span></td>
      <td>${new Date(t.subscription.trialEndsAt).toLocaleDateString()}</td>
      <td>${t.subscription.rateOverride ?? '—'}</td>
      <td><button class="btn btn-ghost" data-suspend="${t.id}">${t.status === 'active' ? 'Suspend' : 'Reactivate'}</button></td>
    </tr>`).join('')}</tbody></table>`;
  document.getElementById('create-tenant').onclick = async () => {
    const name = document.getElementById('tenant-name').value;
    if (!name) return toast('Enter a name');
    await API.post('/tenants', { name });
    toast('Tenant created (30-day trial started)'); viewTenants();
  };
  document.querySelectorAll('[data-suspend]').forEach(b => b.onclick = async () => {
    const t = tenants.find(x => x.id === b.dataset.suspend);
    const path = t.status === 'active' ? 'suspend' : 'reactivate';
    await API.patch(`/tenants/${t.id}/${path}`);
    viewTenants();
  });
}

// ---------------- CLASSES ----------------
async function viewClasses() {
  const main = document.getElementById('main');
  const canCreate = ['super_admin', 'admin', 'tcc', 'tca'].includes(API.user.role);
  const canReschedule = ['super_admin', 'admin', 'tcc', 'tca', 'tsc', 'tsa', 'helpline_agent', 'agentic_ai'].includes(API.user.role);
  const classes = await API.get('/classes');

  main.innerHTML = `
    <h1>Classes</h1><div class="subtitle">Bound to the fixed checklist for each course.</div>
    ${canCreate ? `
    <div class="card">
      <h2>New class</h2>
      <div class="field"><label>Course</label>
        <select id="new-course"><option>Adult CPR and AED</option><option>Infant CPR</option></select></div>
      <div class="field"><label>Date</label><input id="new-date" type="date"></div>
      <button class="btn btn-primary" id="create-class">Create class</button>
    </div>` : ''}
    <table><thead><tr><th>Course</th><th>Date</th><th>Status</th><th></th></tr></thead>
    <tbody>${classes.map(c => `<tr>
      <td>${c.course}</td><td>${c.date}${c.time ? ' · ' + c.time : ''}</td><td>${c.status}</td>
      <td>
        <button class="btn btn-ghost" data-open="${c.id}">Roster</button>
        ${canReschedule ? `<button class="btn btn-ghost" data-reschedule="${c.id}">Reschedule</button>` : ''}
      </td>
    </tr>`).join('')}</tbody></table>
    <div id="roster-panel"></div>`;

  const createBtn = document.getElementById('create-class');
  if (createBtn) createBtn.onclick = async () => {
    try {
      await API.post('/classes', { course: document.getElementById('new-course').value, date: document.getElementById('new-date').value });
      toast('Class created'); viewClasses();
    } catch (e) { toast(e.message); }
  };
  document.querySelectorAll('[data-reschedule]').forEach(b => b.onclick = async () => {
    const date = prompt('New date (YYYY-MM-DD):');
    if (!date) return;
    await API.patch(`/classes/${b.dataset.reschedule}/reschedule`, { date });
    toast('Rescheduled'); viewClasses();
  });
  document.querySelectorAll('[data-open]').forEach(b => b.onclick = () => openRoster(b.dataset.open));
}

async function openRoster(classId) {
  const panel = document.getElementById('roster-panel');
  const { class: cls, roster } = await API.get(`/classes/${classId}/roster`);
  const canEnroll = ['super_admin', 'admin', 'tcc', 'tca', 'tsc', 'tsa', 'helpline_agent', 'agentic_ai'].includes(API.user.role);
  panel.innerHTML = `
    <div class="card">
      <h2>${cls.course} — roster</h2>
      ${canEnroll ? `
        <div class="field"><label>Enrol student</label>
          <input id="stu-name" placeholder="Name" style="margin-bottom:6px;">
          <input id="stu-contact" placeholder="Phone or email">
        </div>
        <button class="btn btn-primary" id="enrol-btn">Enrol</button>` : ''}
      <table style="margin-top:12px;"><thead><tr><th>Student</th><th>Result</th><th></th></tr></thead>
      <tbody>${roster.map(r => `<tr>
        <td>${r.student.name}</td>
        <td>${r.checklistSubmission ? resultPill(r.checklistSubmission.result) : '<span class="pill pill-pending">Not started</span>'}</td>
        <td><button class="btn btn-ghost" data-test="${r.enrollment.id}">Open checklist</button></td>
      </tr>`).join('')}</tbody></table>
    </div>`;
  const enrolBtn = document.getElementById('enrol-btn');
  if (enrolBtn) enrolBtn.onclick = async () => {
    try {
      await API.post(`/classes/${classId}/enroll`, {
        studentName: document.getElementById('stu-name').value,
        studentContact: document.getElementById('stu-contact').value,
      });
      toast('Enrolled'); openRoster(classId);
    } catch (e) { toast(e.message); }
  };
  document.querySelectorAll('[data-test]').forEach(b => b.onclick = async () => {
    const sub = await API.post('/checklists/submissions', { enrollmentId: b.dataset.test });
    state.activeSubmissionId = sub.id; state.view = 'checklistFill'; render();
  });
}

function resultPill(result) {
  if (result === 'PASS') return '<span class="pill pill-pass">Pass</span>';
  if (result === 'NR') return '<span class="pill pill-nr">Needs remediation</span>';
  return '<span class="pill pill-pending">In progress</span>';
}

// ---------------- CHECKLIST FILL / SIGN ----------------
async function viewChecklistFill() {
  const main = document.getElementById('main');
  const sub = await API.get(`/checklists/submissions/${state.activeSubmissionId}`);
  const templates = await API.get('/checklists/templates');
  const template = templates.find(t => t.id === sub.templateId);
  const canMark = ['instructor', 'faculty', 'irf'].includes(API.user.role);

  main.innerHTML = `
    <button class="btn btn-ghost" id="back-btn">← Back to classes</button>
    <h1>${template.course}</h1>
    <div class="subtitle">Template ${template.versionLabel} · ${sub.locked ? 'Signed and locked' : 'In progress'}</div>
    <div class="card">
      ${template.sections.map(sec => `
        <h2>${sec.title}</h2>
        ${sec.items.map(item => `
          <label class="check-item">
            <input type="checkbox" data-item="${item.id}" ${sub.marks[item.id] ? 'checked' : ''} ${sub.locked || !canMark ? 'disabled' : ''}>
            ${item.main}
          </label>`).join('')}
      `).join('')}
      <div class="field" style="margin-top:14px;"><label>Notes</label>
        <textarea id="notes" ${sub.locked ? 'disabled' : ''}>${sub.notes || ''}</textarea></div>
      <div class="field"><label>Result</label>
        <select id="result" ${sub.locked ? 'disabled' : ''}>
          <option value="">Select…</option>
          <option value="PASS" ${sub.result === 'PASS' ? 'selected' : ''}>PASS</option>
          <option value="NR" ${sub.result === 'NR' ? 'selected' : ''}>Needs remediation</option>
        </select></div>
      ${!sub.locked && canMark ? '<button class="btn btn-ghost" id="save-marks">Save progress</button>' : ''}
      ${!sub.locked && canMark ? signaturePanel() : ''}
      ${sub.locked ? `<p><a href="${sub.pdfPath}" target="_blank">View signed PDF record</a></p>` : ''}
    </div>`;

  document.getElementById('back-btn').onclick = () => { state.view = 'classes'; render(); };

  if (!sub.locked && canMark) {
    document.getElementById('save-marks').onclick = async () => {
      const marks = {};
      document.querySelectorAll('[data-item]').forEach(cb => marks[cb.dataset.item] = cb.checked);
      await API.patch(`/checklists/submissions/${sub.id}`, {
        marks, notes: document.getElementById('notes').value, result: document.getElementById('result').value || null,
      });
      toast('Saved');
    };
    setupSignaturePad();
    document.getElementById('sign-submit').onclick = async () => {
      const marks = {};
      document.querySelectorAll('[data-item]').forEach(cb => marks[cb.dataset.item] = cb.checked);
      const result = document.getElementById('result').value;
      if (!result) return toast('Select a result before signing');
      await API.patch(`/checklists/submissions/${sub.id}`, { marks, notes: document.getElementById('notes').value, result });
      try {
        const canvas = document.getElementById('sig-canvas');
        await API.post(`/checklists/submissions/${sub.id}/sign`, {
          instructorId: document.getElementById('instructor-id').value,
          signatureDataUrl: canvas.toDataURL(),
        });
        toast('Signed and locked'); viewChecklistFill();
      } catch (e) { toast(e.message); }
    };
  }
}

function signaturePanel() {
  return `
    <h2>Sign to submit</h2>
    <div class="field"><label>Instructor ID</label><input id="instructor-id" placeholder="e.g. INS-00231"></div>
    <label>Signature</label>
    <canvas id="sig-canvas" class="sig" width="400" height="120"></canvas><br>
    <button class="btn btn-ghost" id="clear-sig" style="margin-top:6px;">Clear</button>
    <button class="btn btn-primary" id="sign-submit" style="margin-top:6px;">Submit & sign</button>`;
}

function setupSignaturePad() {
  const canvas = document.getElementById('sig-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let drawing = false;
  const pos = e => { const r = canvas.getBoundingClientRect(); const p = e.touches ? e.touches[0] : e; return [p.clientX - r.left, p.clientY - r.top]; };
  canvas.addEventListener('pointerdown', e => { drawing = true; const [x, y] = pos(e); ctx.beginPath(); ctx.moveTo(x, y); });
  canvas.addEventListener('pointermove', e => { if (!drawing) return; const [x, y] = pos(e); ctx.lineTo(x, y); ctx.stroke(); });
  window.addEventListener('pointerup', () => drawing = false);
  document.getElementById('clear-sig').onclick = () => ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// ---------------- CHECKLIST LIBRARY ----------------
async function viewChecklistLibrary() {
  const main = document.getElementById('main');
  const templates = await API.get('/checklists/templates');
  main.innerHTML = `
    <h1>Checklist library</h1><div class="subtitle">One active version per course. Retiring one alerts you to replace it.</div>
    <table><thead><tr><th>Course</th><th>Version</th><th>Status</th><th></th></tr></thead>
    <tbody>${templates.map(t => `<tr>
      <td>${t.course}</td><td>${t.versionLabel}</td>
      <td><span class="pill ${t.status === 'active' ? 'pill-active' : 'pill-nr'}">${t.status}</span></td>
      <td>${t.status === 'active' ? `<button class="btn btn-ghost" data-retire="${t.id}">Retire</button>` : ''}</td>
    </tr>`).join('')}</tbody></table>`;
  document.querySelectorAll('[data-retire]').forEach(b => b.onclick = async () => {
    const res = await API.post(`/checklists/templates/${b.dataset.retire}/retire`);
    toast(res.alert); viewChecklistLibrary();
  });
}

// ---------------- COMPLAINTS ----------------
async function viewComplaints() {
  const main = document.getElementById('main');
  const canLog = true;
  const complaints = await API.get('/complaints');
  main.innerHTML = `
    <h1>Complaints</h1>
    ${canLog ? `
    <div class="card">
      <h2>Log a complaint</h2>
      <div class="field"><label>Student name</label><input id="c-name"></div>
      <div class="field"><label>Channel</label>
        <select id="c-channel"><option>WhatsApp</option><option>Website chat</option><option>Phone</option></select></div>
      <div class="field"><label>Scope</label><select id="c-scope"><option value="itc">Centre-level (TCC)</option><option value="site">Site-level (TSC/TSA)</option></select></div>
      <div class="field"><label>Description</label><textarea id="c-desc"></textarea></div>
      <button class="btn btn-primary" id="log-btn">Log complaint</button>
    </div>` : ''}
    <table><thead><tr><th>Student</th><th>Channel</th><th>Handler</th><th>Status</th><th></th></tr></thead>
    <tbody>${complaints.map(c => `<tr>
      <td>${c.studentName}</td><td>${c.channel}</td>
      <td><span class="badge-source">${c.handlerType === 'ai' ? 'Agentic AI' : c.handlerType}</span></td>
      <td><span class="pill ${c.status === 'open' ? 'pill-nr' : 'pill-pass'}">${c.status}</span></td>
      <td>${c.status === 'open' ? `<button class="btn btn-ghost" data-resolve="${c.id}">Resolve</button>` : ''}</td>
    </tr>`).join('')}</tbody></table>`;
  const logBtn = document.getElementById('log-btn');
  if (logBtn) logBtn.onclick = async () => {
    await API.post('/complaints', {
      studentName: document.getElementById('c-name').value,
      channel: document.getElementById('c-channel').value,
      scope: document.getElementById('c-scope').value,
      description: document.getElementById('c-desc').value,
    });
    toast('Complaint logged and routed'); viewComplaints();
  };
  document.querySelectorAll('[data-resolve]').forEach(b => b.onclick = async () => {
    const resolution = prompt('Resolution notes:');
    if (!resolution) return;
    try { await API.patch(`/complaints/${b.dataset.resolve}/resolve`, { resolution }); toast('Resolved'); viewComplaints(); }
    catch (e) { toast(e.message); }
  });
}

// ---------------- DELEGATIONS ----------------
async function viewDelegations() {
  const main = document.getElementById('main');
  const list = await API.get('/delegations');
  main.innerHTML = `
    <h1>Temporary authority delegation</h1>
    <div class="subtitle">Admin/Super Admin only. Non-delegable: create_admin, manage_tenants.</div>
    <table><thead><tr><th>Recipient</th><th>Permission</th><th>Ends</th><th>Status</th><th></th></tr></thead>
    <tbody>${list.map(d => `<tr>
      <td>${d.recipientId}</td><td>${d.permission}</td><td>${new Date(d.endTime).toLocaleString()}</td>
      <td>${d.status}</td>
      <td>${d.status === 'active' ? `<button class="btn btn-danger" data-revoke="${d.id}">Revoke</button>` : ''}</td>
    </tr>`).join('')}</tbody></table>`;
  document.querySelectorAll('[data-revoke]').forEach(b => b.onclick = async () => {
    await API.post(`/delegations/${b.dataset.revoke}/revoke`); toast('Revoked early'); viewDelegations();
  });
}

// ---------------- BILLING ----------------
async function viewBilling() {
  const main = document.getElementById('main');
  const fees = await API.get('/billing/course-fees').catch(() => []);
  main.innerHTML = `
    <h1>Billing</h1>
    <h2>Course fee ledger</h2>
    <table><thead><tr><th>Amount</th><th>Gateway</th><th>Status</th></tr></thead>
    <tbody>${fees.map(f => `<tr><td>${f.amount} ${f.currency}</td><td>${f.gateway}</td><td>${f.status}</td></tr>`).join('') || '<tr><td colspan="3">No entries yet.</td></tr>'}</tbody></table>`;
}

// ---------------- SYNC ----------------
async function viewSync() {
  const main = document.getElementById('main');
  const pending = await API.get('/sync/inbound/pending').catch(() => []);
  main.innerHTML = `
    <h1>Legacy site sync</h1>
    <div class="subtitle">Registrations posted from enroll.itc.org.pk awaiting a matching class.</div>
    <table><thead><tr><th>Course</th><th>Name</th><th>Contact</th><th>Received</th></tr></thead>
    <tbody>${pending.map(p => `<tr><td>${p.course}</td><td>${p.name}</td><td>${p.phone || p.email}</td><td>${new Date(p.receivedAt).toLocaleString()}</td></tr>`).join('') || '<tr><td colspan="4">None pending.</td></tr>'}</tbody></table>`;
}

render();
