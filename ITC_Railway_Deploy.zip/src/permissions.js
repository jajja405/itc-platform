/**
 * ITC Platform — Permission Check Function
 * Server-side enforcement layer — called by every API route handler.
 * UI never solely enforces permissions (spec section 6.3).
 *
 * Returns: Promise<boolean> — true = permitted, false = denied
 * Throws:  PermissionError  — hard block (agentic_ai prohibited actions)
 */

class PermissionError extends Error {
  constructor(role, action) {
    super(`Hard block: ${role} cannot perform ${action}`);
    this.role = role; this.action = action;
  }
}

const CLASS_CREATORS       = new Set(['super_admin','admin','tcc','tca']);
const RESCHEDULE_ALL       = new Set(['super_admin','admin','tcc','tca','tsc','tsa','helpline_agent','agentic_ai']);
const ENROL_ALL            = new Set(['super_admin','admin','tcc','tca','tsc','tsa','helpline_agent','agentic_ai']);
const CARD_ISSUERS         = new Set(['super_admin','admin','tcc','tca']);
const FEE_VIEWERS          = new Set(['super_admin','admin','tcc','tca','accountant','helpline_agent','agentic_ai']);
const BILLING_MANAGERS     = new Set(['super_admin','admin','accountant']);
const DELEGATION_GRANTORS  = new Set(['super_admin','admin']);
const NON_DELEGABLE        = new Set(['create_admin','audit_log_config','ai_action_boundaries']);
const NON_DELEGABLE_RECIPS = new Set(['student','agentic_ai']);

const AI_PERMITTED  = new Set(['reschedule','enrol_student','view_fees','log_complaint','view_calendar','view_course_info']);
const AI_PROHIBITED = new Set(['issue_refund','create_class','cancel_class','manage_billing','resolve_complaints','create_admin','change_account_settings','delegate','issue_card','create_user','delete_user','modify_permissions']);

async function checkPermission(ctx, action) {
  const { role } = ctx;

  if (role === 'agentic_ai') {
    if (AI_PROHIBITED.has(action)) throw new PermissionError(role, action);
    if (AI_PERMITTED.has(action)) return true;
    return false;
  }

  switch (action) {
    case 'create_admin': return role === 'super_admin';
    case 'create_class': return CLASS_CREATORS.has(role);

    case 'reschedule':
      if (RESCHEDULE_ALL.has(role)) return true;
      if (role === 'student') return ctx.ownStudentId === ctx.targetStudentId && ctx.withinPolicyWindow;
      return false;

    case 'enrol_student':
      if (ENROL_ALL.has(role)) return true;
      if (role === 'student') return ctx.ownStudentId === ctx.targetStudentId;
      return false;

    case 'teach_and_test':
      if (['tcf','lead_instructor','irf'].includes(role)) return true;
      if (['instructor','tcc','tca'].includes(role)) return ctx.instructorAligned && ctx.instructorCardValid;
      return false;

    case 'issue_card':
      if (CARD_ISSUERS.has(role)) return true;
      if (role === 'instructor') return ctx.cardInventoryAvailable;
      return false;

    case 'view_fees':
      if (FEE_VIEWERS.has(role)) return true;
      if (role === 'student') return ctx.ownStudentId === ctx.targetStudentId;
      return false;

    case 'manage_billing':
      if (BILLING_MANAGERS.has(role)) return true;
      if (['tcc','tca'].includes(role)) return ctx.scope === 'set_fees';
      return false;

    case 'resolve_complaints':
      if (['super_admin','admin'].includes(role)) return true;
      if (['tcc','tca'].includes(role)) return ctx.complaintScope === 'centre';
      if (['tsc','tsa'].includes(role)) return ctx.complaintScope === 'site';
      return false;

    case 'log_complaint':
      return ['super_admin','admin','tcc','tca','tsc','tsa','helpline_agent','agentic_ai','student'].includes(role);

    case 'file_complaint': return role === 'student';

    case 'guest_audit':
      if (['super_admin','admin'].includes(role)) return true;
      if (role === 'irf') return ctx.targetTenantId !== ctx.ownTenantId;
      return false;

    case 'delegate':
      if (!DELEGATION_GRANTORS.has(role)) return false;
      if (ctx.targetPermission && NON_DELEGABLE.has(ctx.targetPermission)) return false;
      if (ctx.recipientRole && NON_DELEGABLE_RECIPS.has(ctx.recipientRole)) return false;
      return true;

    case 'access_tenant_data':
      if (!['super_admin','admin'].includes(role)) return ctx.targetTenantId === ctx.tenantId;
      if (ctx.targetTenantId && ctx.targetTenantId !== ctx.tenantId) return !!(ctx.ticketRef && ctx.reason);
      return true;

    case 'issue_refund':
      return ['super_admin','admin','tcc','tca'].includes(role);

    default: return false;
  }
}

module.exports = { checkPermission, PermissionError };
