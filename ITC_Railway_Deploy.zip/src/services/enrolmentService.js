/**
 * Enrolment service — the register → seat decrement → confirmation flow.
 * Spec: 2.8 (student), 3.5 (candidate contact), 16.1 (capacity and waitlist).
 */
const { checkPermission } = require('../permissions');
const { getSeatCount, audit, ValidationError, ForbiddenError } = require('./classService');

/**
 * Enrol a student into a class.
 * Seat allocation uses SELECT ... FOR UPDATE on the class row so two
 * concurrent bookings for the last seat cannot both succeed.
 *
 * Returns { enrolment, seats, waitlisted }.
 */
async function enrol(client, ctx, { classId, studentId, idempotencyKey }) {
  const permitted = await checkPermission({
    ...ctx,
    ownStudentId: ctx.studentId,
    targetStudentId: studentId,
  }, 'enrol_student');
  if (!permitted) throw new ForbiddenError('Role cannot enrol this student');

  // Idempotency — a retried request returns the original result (section 11.2)
  if (idempotencyKey) {
    const prior = await client.query(
      `SELECT * FROM enrolments WHERE idempotency_key = $1`, [idempotencyKey]
    );
    if (prior.rows.length) {
      const seats = await getSeatCount(client, prior.rows[0].class_id);
      return { enrolment: prior.rows[0], seats, waitlisted: prior.rows[0].status === 'waitlisted', replayed: true };
    }
  }

  // Lock the class row — serialises concurrent bookings on the same class
  const clsRes = await client.query(
    `SELECT * FROM classes WHERE id = $1 FOR UPDATE`, [classId]
  );
  if (!clsRes.rows.length) throw new ValidationError('Class not found', 'class_not_found');
  const cls = clsRes.rows[0];

  // Students may only book published classes (section 2.8 boundaries)
  if (cls.status !== 'published') {
    if (ctx.role === 'student') {
      throw new ValidationError('This class is not open for booking', 'class_not_published');
    }
    if (!['scheduled', 'published'].includes(cls.status)) {
      throw new ValidationError(`Cannot enrol into a ${cls.status} class`, 'class_not_bookable');
    }
  }

  if (new Date(cls.starts_at) < new Date()) {
    throw new ValidationError('This class has already started', 'class_started');
  }

  // Student must exist and belong to this tenant (RLS enforces the tenant part)
  const stu = await client.query(`SELECT * FROM students WHERE id = $1`, [studentId]);
  if (!stu.rows.length) throw new ValidationError('Student not found', 'student_not_found');
  const student = stu.rows[0];

  // Minors need recorded guardian consent (section 9.3)
  if (student.is_minor && !student.guardian_consent) {
    throw new ValidationError('Guardian consent is required for students under 18', 'guardian_consent_required');
  }

  // No duplicate enrolment
  const dupe = await client.query(
    `SELECT id, status FROM enrolments WHERE student_id = $1 AND class_id = $2 AND status <> 'cancelled'`,
    [studentId, classId]
  );
  if (dupe.rows.length) {
    throw new ValidationError('Student is already enrolled in this class', 'already_enrolled');
  }

  const seats = await getSeatCount(client, classId);
  const waitlisted = seats.available <= 0;

  let waitlistPosition = null;
  if (waitlisted) {
    const wl = await client.query(
      `SELECT COALESCE(MAX(waitlist_position), 0) + 1 AS next
       FROM enrolments WHERE class_id = $1 AND status = 'waitlisted'`, [classId]
    );
    waitlistPosition = Number(wl.rows[0].next);
  }

  const ins = await client.query(`
    INSERT INTO enrolments
      (tenant_id, student_id, class_id, status, waitlist_position, idempotency_key)
    VALUES ($1,$2,$3,$4,$5,$6)
    RETURNING *
  `, [cls.tenant_id, studentId, classId, waitlisted ? 'waitlisted' : 'enrolled', waitlistPosition, idempotencyKey || null]);

  const enrolment = ins.rows[0];

  await audit(client, ctx, waitlisted ? 'enrolment.waitlisted' : 'enrolment.created',
    'enrolments', enrolment.id, {
      class_id: classId, student_id: studentId,
      handler: ctx.role, waitlist_position: waitlistPosition,
    });

  // Queue the confirmation notification (section 17.2 — immediate)
  await client.query(`
    INSERT INTO notifications (tenant_id, student_id, event_type, channel, payload)
    VALUES ($1,$2,$3,$4,$5)
  `, [
    cls.tenant_id, studentId,
    waitlisted ? 'enrolment.waitlist_offer' : 'enrolment.confirmed',
    'email',
    JSON.stringify({ class_id: classId, enrolment_id: enrolment.id, waitlist_position: waitlistPosition }),
  ]);

  const after = await getSeatCount(client, classId);
  return { enrolment, seats: after, waitlisted };
}

/**
 * Cancel an enrolment and promote the first waitlisted student, if any.
 * Spec 16.1: a freed seat is offered to the head of the waitlist.
 */
async function cancelEnrolment(client, ctx, { enrolmentId }) {
  const res = await client.query(`SELECT * FROM enrolments WHERE id = $1`, [enrolmentId]);
  if (!res.rows.length) throw new ValidationError('Enrolment not found', 'enrolment_not_found');
  const enr = res.rows[0];

  if (ctx.role === 'student' && enr.student_id !== ctx.studentId) {
    throw new ForbiddenError('Students may only cancel their own bookings');
  }
  if (enr.status === 'cancelled') {
    throw new ValidationError('Enrolment already cancelled', 'already_cancelled');
  }

  const heldSeat = enr.status === 'enrolled';

  await client.query(
    `UPDATE enrolments SET status='cancelled', cancelled_at=NOW(), cancelled_by=$2 WHERE id=$1`,
    [enrolmentId, ctx.userId]
  );
  await audit(client, ctx, 'enrolment.cancelled', 'enrolments', enrolmentId, { class_id: enr.class_id });

  // Promote the head of the waitlist into the freed seat
  let promoted = null;
  if (heldSeat) {
    const next = await client.query(`
      SELECT * FROM enrolments
      WHERE class_id = $1 AND status = 'waitlisted'
      ORDER BY waitlist_position ASC LIMIT 1
    `, [enr.class_id]);

    if (next.rows.length) {
      const p = next.rows[0];
      await client.query(
        `UPDATE enrolments SET status='enrolled', waitlist_position=NULL WHERE id=$1`, [p.id]
      );
      await audit(client, ctx, 'enrolment.promoted_from_waitlist', 'enrolments', p.id,
        { class_id: enr.class_id, from_position: p.waitlist_position });
      await client.query(`
        INSERT INTO notifications (tenant_id, student_id, event_type, channel, payload)
        VALUES ($1,$2,'enrolment.confirmed','email',$3)
      `, [p.tenant_id, p.student_id, JSON.stringify({ class_id: enr.class_id, promoted: true })]);
      promoted = p.id;
    }
  }

  const seats = await getSeatCount(client, enr.class_id);
  return { cancelled: enrolmentId, promoted, seats };
}

module.exports = { enrol, cancelEnrolment };
