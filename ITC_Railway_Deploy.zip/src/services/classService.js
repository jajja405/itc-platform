/**
 * Class service — publish, capacity, and lifecycle.
 * Spec: sections 3.4 (course delivery), 16.1 (capacity), 16.2 (conflicts).
 */
const { checkPermission } = require('../permissions');

class ValidationError extends Error {
  constructor(msg, code) { super(msg); this.code = code; this.status = 400; }
}
class ForbiddenError extends Error {
  constructor(msg) { super(msg); this.status = 403; }
}

/**
 * Publish a class — makes it visible on the public calendar and bookable.
 * Guards (section 16.2): lead instructor assigned, card valid on class date,
 * course director present when the course requires one, ratios not breached.
 */
async function publishClass(client, ctx, classId) {
  if (!(await checkPermission(ctx, 'create_class'))) {
    throw new ForbiddenError('Role cannot publish classes');
  }

  const { rows } = await client.query(`
    SELECT c.*, co.requires_director, co.instructor_ratio, co.title AS course_title
    FROM classes c
    JOIN courses co ON co.id = c.course_id
    WHERE c.id = $1
  `, [classId]);

  if (!rows.length) throw new ValidationError('Class not found', 'class_not_found');
  const cls = rows[0];

  if (cls.status === 'published') {
    throw new ValidationError('Class already published', 'already_published');
  }
  if (cls.status === 'cancelled') {
    throw new ValidationError('Cannot publish a cancelled class', 'class_cancelled');
  }
  if (!cls.lead_instructor_id) {
    throw new ValidationError('Assign a lead instructor before publishing', 'no_lead_instructor');
  }
  if (cls.requires_director && !cls.course_director_id) {
    throw new ValidationError('This course requires a course director', 'no_course_director');
  }

  // Credential validity on the class date — not merely today (section 16.2)
  const cred = await client.query(`
    SELECT card_expiry, alignment_status
    FROM instructors
    WHERE user_id = $1 AND tenant_id = $2
    ORDER BY card_expiry DESC LIMIT 1
  `, [cls.lead_instructor_id, cls.tenant_id]);

  if (!cred.rows.length) {
    throw new ValidationError('Lead instructor has no instructor record', 'no_instructor_record');
  }
  const { card_expiry, alignment_status } = cred.rows[0];
  if (alignment_status !== 'aligned') {
    throw new ValidationError('Lead instructor alignment is not active', 'alignment_lapsed');
  }
  if (new Date(card_expiry) < new Date(cls.starts_at)) {
    throw new ValidationError('Lead instructor card expires before the class date', 'card_expires_before_class');
  }

  // Ratio guard (section 16.1)
  if (cls.capacity > cls.instructor_ratio) {
    throw new ValidationError(
      `Capacity ${cls.capacity} exceeds the ${cls.instructor_ratio}:1 instructor ratio for this course`,
      'ratio_breach'
    );
  }

  const updated = await client.query(
    `UPDATE classes SET status = 'published' WHERE id = $1 RETURNING *`, [classId]
  );

  await audit(client, ctx, 'class.published', 'classes', classId, {
    course: cls.course_title, starts_at: cls.starts_at,
  });

  return updated.rows[0];
}

/** Seats taken = enrolled + attended. Waitlisted and cancelled don't hold a seat. */
async function getSeatCount(client, classId) {
  const { rows } = await client.query(`
    SELECT
      c.capacity,
      COUNT(*) FILTER (WHERE e.status IN ('enrolled','attended')) AS taken,
      COUNT(*) FILTER (WHERE e.status = 'waitlisted')             AS waiting
    FROM classes c
    LEFT JOIN enrolments e ON e.class_id = c.id
    WHERE c.id = $1
    GROUP BY c.capacity
  `, [classId]);

  if (!rows.length) throw new ValidationError('Class not found', 'class_not_found');
  const r = rows[0];
  return {
    capacity: Number(r.capacity),
    taken: Number(r.taken),
    waiting: Number(r.waiting),
    available: Number(r.capacity) - Number(r.taken),
  };
}

async function audit(client, ctx, action, entityType, entityId, diff) {
  await client.query(`
    INSERT INTO audit_log
      (tenant_id, actor_id, actor_role, action, entity_type, entity_id, diff, row_hash)
    VALUES ($1,$2,$3,$4,$5,$6,$7, encode(sha256(($4 || $6::text || now()::text)::bytea),'hex'))
  `, [ctx.tenantId, ctx.userId, ctx.role, action, entityType, entityId, diff ? JSON.stringify(diff) : null]);
}

module.exports = { publishClass, getSeatCount, audit, ValidationError, ForbiddenError };
