/**
 * Database access layer — PostgreSQL with tenant context.
 * Every query runs in a transaction that sets the RLS session variables
 * from schema/009_rls_policies.sql. Application code never filters by
 * tenant_id manually — the database enforces isolation.
 */
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
});

async function withTenant(ctx, fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT set_config($1,$2,true)', ['app.current_tenant_id', ctx.tenantId || '']);
    await client.query('SELECT set_config($1,$2,true)', ['app.current_user_id', ctx.userId || '']);
    await client.query('SELECT set_config($1,$2,true)', ['app.current_role', ctx.role || '']);
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, withTenant };
