# ITC Training Platform

AHA-aligned Training Management Platform — v2.0

## Deploy on Railway

1. Fork or upload this repository to GitHub
2. Go to railway.app and create a new project
3. Select "Deploy from GitHub repo"
4. Add a PostgreSQL database service
5. Set environment variables (see below)
6. Deploy

## Environment Variables

Set these in Railway dashboard:

| Variable | Value |
|---|---|
| `NODE_ENV` | `production` |
| `JWT_SECRET` | Any long random string |
| `JWT_EXPIRES_IN` | `8h` |
| `DATABASE_URL` | Auto-set by Railway PostgreSQL |
| `PORT` | Auto-set by Railway |

## Tech Stack

- Node.js 20 + Express
- PostgreSQL 16
- 488 tests passing
